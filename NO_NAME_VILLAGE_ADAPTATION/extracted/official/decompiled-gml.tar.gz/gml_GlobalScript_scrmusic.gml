function scrmusic(argument0, argument1, argument2, argument3, argument4) //gml_Script_scrmusic
{
    if (!variable_global_exists("music"))
        global.music = 1
    if (!variable_global_exists("sound"))
        global.sound = 1
    if (!audio_is_playing(argument0))
    {
        audio_play_sound(argument0, argument1, 0)
        if (objaudio.firstmusic > 0)
        {
            objaudio.firstmusic = 0
            audio_sound_gain(argument0, 0, 0)
        }
    }
    var asg = audio_sound_get_gain(argument0)
    audio_sound_gain(argument0, (argument2 * global.music), argument4)
    audio_sound_pitch(argument0, argument3)
    asg = audio_sound_get_gain(argument0)
}

