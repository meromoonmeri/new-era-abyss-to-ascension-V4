if instance_exists(creator)
    draw_sprite_ext(sprite_index, image_index, x, y, 1, 1, 0, -1, creator.alpha)
else
    instance_destroy()
