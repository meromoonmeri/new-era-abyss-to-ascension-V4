var mdelay = 500
if (!audio_is_playing(snsmmusic00))
    mdelay = 0
if (mdelay == 0 && objplayerview.lat > 0)
{
}
else if (music != global.music || sound != global.sound)
{
    music = global.music
    sound = global.sound
    if (scrlocation(room) < 4 && objplayer.stage > 0 && pausenoise == false)
        scrsoundgain(snbgnoise, 50, (1 * global.sound), 500)
    else
        scrsoundgain(snbgnoise, 50, 0, 500)
    if (boss == false)
    {
        scrsoundgain(snsmmusic10, 50, 0, 10)
        if (!instance_exists(objgameover))
        {
            if (global.season == 1)
            {
                if (scrlocation(room) <= 1 && room != rm82 && (!layer_exists("blueforest")))
                {
                    scrsoundgain(snsmmusic00, 50, (1 * global.music), mdelay)
                    scrsoundgain(snsmmusic01, 50, (0.3 * global.music), mdelay)
                    audio_sound_gain(snsmmusic01, 0, 2000)
                }
                else if ((scrlocation(room) == 3 && (objplayer.stage < 2 || objplayer.stage > 2.05)) || layer_exists("blueforest"))
                {
                    scrsoundgain(snsmmusic00, 50, (0 * global.music), mdelay)
                    scrsoundgain(snsmmusic01, 50, (1 * global.music), mdelay)
                }
                else
                {
                    scrsoundgain(snsmmusic00, 50, (0 * global.music), mdelay)
                    scrsoundgain(snsmmusic01, 50, (0 * global.music), mdelay)
                }
            }
        }
        else
        {
            scrsoundgain(snsmmusic00, 50, 0, mdelay)
            scrsoundgain(snsmmusic01, 50, 0, mdelay)
        }
    }
    else
    {
        scrsoundgain(snsmmusic10, 50, (1 * global.music), 10)
        scrsoundgain(snsmmusic00, 50, 0, mdelay)
        scrsoundgain(snsmmusic01, 50, 0, mdelay)
    }
    if (scrlocation(room) <= 1)
    {
        if instance_exists(objtree)
            scrsoundgain(snbgtree, 50, (0.75 * global.sound), 2000)
        else
            audio_sound_gain(snbgtree, 0, 500)
        if (global.season == 1)
            scrsoundgain(snsummer, 50, (1 * global.sound), 2000)
        else if (global.season == 3)
            scrsoundgain(snwinter, 50, (0.25 * global.sound), 2000)
        else
            audio_sound_gain(snsummer, 0, 500)
    }
    else
    {
        audio_sound_gain(snbgtree, 0, 500)
        audio_sound_gain(snsummer, 0, 500)
        audio_sound_gain(snwinter, 0, 500)
    }
    if (scrrivermap(room) && global.season < 3)
        scrsoundgain(snbgriver, 40, (0.75 * global.sound), 2000)
    else
        audio_sound_gain(snbgriver, 0, 500)
    if layer_exists("blueforest")
        scrsoundgain(snwater0, 40, (1 * global.sound), 2000)
    else
        audio_sound_gain(snwater0, 0, 500)
}
