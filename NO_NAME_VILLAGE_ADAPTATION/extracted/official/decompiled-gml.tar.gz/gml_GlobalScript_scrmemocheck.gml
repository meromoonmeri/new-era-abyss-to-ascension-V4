function scrmemocheck() //gml_Script_scrmemocheck
{
    if (timertt < 1)
    {
        var menu = instance_create_depth(x, y, 0, objmenu)
        menu.caninput = false
        menu.page = 3
        timertt = 1
    }
    else if (timertt < 2)
        timertt += (1/120)
    else if (timertt < 3)
    {
        with (objmenu)
            state = 5
        timertt = 3
    }
    else
        return 1;
}

