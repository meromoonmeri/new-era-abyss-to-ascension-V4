function scrmemo(argument0, argument1, argument2) //gml_Script_scrmemo
{
    draw_set_halign(fa_left)
    draw_set_colour(make_color_rgb(71, 48, 58))
    draw_set_font(fnt0)
    var tx = 264 + argument0
    var ty = 208 + menuy
    var stx = tx - 20
    var sty = ty + 14
    var stage = objplayer.stage
    if (stage >= 0 && stage < 2)
    {
        if (stage > 0.03)
        {
            draw_text_transformed(tx, (ty + 0), "Fetch a bucket of water\nfrom the river", argument2, 1, 0)
            if (stage > 0.11)
            {
                draw_sprite_ext(sm3st, 0, stx, (sty + 0), (argument2 * 0.95), -1, 0, -1, 1)
                draw_sprite_ext(sm3st, 0, stx, (sty + 46), (argument2 * 0.58), 1, 0, -1, 1)
            }
        }
        if (stage > 0.11)
        {
            draw_text_transformed(tx, (ty + 138), "Look for Reg", argument2, 1, 0)
            if (stage > 0.14)
                draw_sprite_ext(sm3st, 0, stx, (sty + 138), (argument2 * 0.52), -1, 0, -1, 1)
        }
        if (stage > 0.14)
        {
            draw_text_transformed(tx, (ty + 230), "Find Ruben", argument2, 1, 0)
            if (stage > 0.17)
                draw_sprite_ext(sm3st, 0, stx, (sty + 230), (argument2 * 0.45), 1, 0, -1, 1)
        }
        if (stage > 0.38)
        {
            draw_text_transformed(tx, (ty + 322), "Rescue Reg", argument2, 1, 0)
            if (stage > 0.52)
                draw_sprite_ext(sm3st, 0, stx, (sty + 322), (argument2 * 0.46), -1, 0, -1, 1)
        }
        if (stage > 1.01)
        {
            draw_text_transformed((tx + 692), (ty + 0), "Find Reg", argument2, 1, 0)
            if (stage > 1.14)
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 0), (argument2 * 0.4), 1, 0, -1, 1)
        }
        if (stage > 1.14)
        {
            draw_text_transformed((tx + 692), (ty + 92), "Escape the cave", argument2, 1, 0)
            if (stage > 1.23)
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 92), (argument2 * 0.6), -1, 0, -1, 1)
        }
        if (stage > 1.23)
        {
            draw_text_transformed((tx + 692), (ty + 184), "Leave the Blue Forest", argument2, 1, 0)
            if (stage > 1.37)
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 184), (argument2 * 0.9), 1, 0, -1, 1)
        }
    }
    else if (stage >= 2 && stage < 4)
    {
        if (stage > 2)
        {
            draw_text_transformed(tx, (ty + 0), "Find the frog's nest", argument2, 1, 0)
            if (stage > 2.25)
                draw_sprite_ext(sm3st, 0, stx, (sty + 0), (argument2 * 0.8), -1, 0, -1, 1)
        }
        if (stage > 2.26)
        {
            draw_text_transformed(tx, (ty + 92), "Search for something tasty", argument2, 1, 0)
            if (scritemcheck(18) || scritemcheck(20) || stage > 2.29)
                draw_sprite_ext(sm3st, 0, stx, (sty + 92), (argument2 * 1.02), 1, 0, -1, 1)
            draw_text_transformed(tx, (ty + 184), "Search for something small\nand sharp", argument2, 1, 0)
            if (scritemcheck(17) || scritemcheck(20) || stage > 2.29)
            {
                draw_sprite_ext(sm3st, 0, stx, (sty + 184), (argument2 * 1), -1, 0, -1, 1)
                draw_sprite_ext(sm3st, 0, stx, (sty + 230), (argument2 * 0.4), 1, 0, -1, 1)
            }
            draw_text_transformed(tx, (ty + 322), "Search for a small basket", argument2, 1, 0)
            if (scritemcheck(16) || scritemcheck(20) || stage > 2.29)
                draw_sprite_ext(sm3st, 0, stx, (sty + 322), (argument2 * 0.97), -1, 0, -1, 1)
        }
        if (stage > 2.29)
        {
            draw_text_transformed(tx, (ty + 414), "Hunt the big frog!", argument2, 1, 0)
            if (stage > 2.36)
                draw_sprite_ext(sm3st, 0, stx, (sty + 414), (argument2 * 0.72), 1, 0, -1, 1)
        }
        if (stage > 3.01)
        {
            draw_text_transformed((tx + 692), (ty + 0), "Find a spot with a lack of\nplants in the Blue Forest", argument2, 1, 0)
            if (stage >= 3.21)
            {
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 0), (argument2 * 1.03), 1, 0, -1, 1)
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 46), (argument2 * 0.98), -1, 0, -1, 1)
            }
        }
        if (stage > 3.09 || global.mapgrid[3][3] == 1)
        {
            draw_text_transformed((tx + 692), (ty + 138), "Remove the blockade", argument2, 1, 0)
            if (stage > 3.09)
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 138), (argument2 * 0.9), 1, 0, -1, 1)
            draw_text_transformed((tx + 692), (ty + 230), "Search for something\nexplosive", argument2, 1, 0)
            if (scritemcheck(22) || stage > 3.09)
            {
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 230), (argument2 * 0.83), -1, 0, -1, 1)
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 276), (argument2 * 0.4), 1, 0, -1, 1)
            }
            draw_text_transformed((tx + 692), (ty + 368), "Search for something\nignitive", argument2, 1, 0)
            if (scritemcheck(23) || stage >= 3.1)
            {
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 368), (argument2 * 0.81), -1, 0, -1, 1)
                draw_sprite_ext(sm3st, 0, (stx + 692), (sty + 414), (argument2 * 0.35), 1, 0, -1, 1)
            }
        }
    }
    else if (stage >= 4)
    {
        if (stage > 4.04)
        {
            draw_text_transformed(tx, (ty + 0), "Meet Reg", argument2, 1, 0)
            if (stage > 4.07)
                draw_sprite_ext(sm3st, 0, stx, (sty + 0), (argument2 * 0.4), 1, 0, -1, 1)
        }
        if (stage > 4.07)
        {
            draw_text_transformed(tx, (ty + 92), "Find the gravesite", argument2, 1, 0)
            if (stage > 4.09)
                draw_sprite_ext(sm3st, 0, stx, (sty + 92), (argument2 * 0.7), -1, 0, -1, 1)
        }
        if (stage > 5)
        {
            draw_text_transformed(tx, (ty + 184), "Find the Old Man", argument2, 1, 0)
            if (stage > 5.12)
                draw_sprite_ext(sm3st, 0, stx, (sty + 184), (argument2 * 0.6), 1, 0, -1, 1)
        }
    }
}

