if instance_exists(objbmobau)
{
    image_index = objbmobau.dip
    sprite_index = objbmobau.undersprite
    x = objbmobau.x
    y = objbmobau.y
    with (objbmobau)
    {
        if (state == -1 || state == 0 || state == 1 || state == 2 || state == 3 || state == 4)
            other.alpha = 0.75
        else
            other.alpha = 0
    }
}
else
    instance_destroy()
