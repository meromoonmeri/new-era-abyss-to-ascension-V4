if part_system_exists(part_system)
{
    part_particles_clear(part_system)
    part_system_destroy(part_system)
}
