if (largen >= 0)
    size0 += ((1 - size0) / 48)
if (largen >= 1)
    size1 += ((1 - size1) / 24)
if (delay > 0)
    delay -= 1
else if (alpha < 0)
{
    alpha += 0.016666666666666666
    largen = 0
}
else if (alpha < 0.5)
{
    alpha += 0.004166666666666667
    largen = 1
}
else if (alpha >= 1)
{
    part_type_destroy(pt)
    part_system_destroy(ps)
    instance_destroy()
}
else
{
    objplayerview.shaket = 5
    scrsplash(x, y, smobau2splash, 1)
    if (objbmobau.hp > 0)
    {
        if (position_meeting(objplayerview.player.x, objplayerview.player.y, self) && pcatch == false)
        {
            objplayerview.shaket = 12
            objbmobau.image_index = 0
            objbmobau.state = 2
            objbmobau0c.pcatch = true
            objbmobau0c.delay = 30
            objplayer.alpha = 0
            objfollower.alpha = 0
            objplayer.caninput = false
            objfollower.caninput = false
            objbmobauview.pcatch = true
        }
        if (pcatch == true)
        {
            objbmobauview.x = x
            objbmobauview.y = y
            objplayerview.player.x = x
            objplayerview.player.y = y
        }
    }
    else if instance_exists(objhunter)
    {
        if (scrdist(self, objhunter) < 256)
        {
            with (objhunter)
                alpha = 0
            with (objfollower)
                alpha = 0
            with (objreg)
                alpha = 0
            with (objplayer)
                follower = 0
        }
    }
    var hitlist = ds_list_create()
    var hitnumber = (instance_place_list(x, y, 153, hitlist, false)) + (instance_place_list(x, y, 515, hitlist, false))
    if (hitnumber > 0)
    {
        for (var i = 0; i < hitnumber; i++)
        {
            with (ds_list_find_value(hitlist, i))
            {
                if (image_index < 1)
                {
                    if (object_index == objbf00 || object_index == objbf01 || object_index == objbf02)
                    {
                        repeat (8)
                        {
                            var rdist = random(64)
                            var rdir = random(360)
                            part_particles_create(other.pps, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), other.pt012, 1)
                        }
                    }
                    else if (object_index == objbf03 || object_index == objbf04 || object_index == objbf05)
                    {
                        repeat (8)
                        {
                            rdist = random(16)
                            rdir = random(360)
                            part_particles_create(other.pps, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), other.pt345, 1)
                        }
                    }
                    else if (object_index == objbf06 || object_index == objbf07 || object_index == objbf08)
                    {
                        repeat (8)
                        {
                            rdist = random(32)
                            rdir = random(360)
                            part_particles_create(other.pps, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), other.pt678, 1)
                        }
                    }
                    else
                        sprite_index = sempty
                    if variable_instance_exists(id, "sbreak")
                    {
                        var plant = instance_create_layer(x, y, "shadows", objempty)
                        plant.sprite_index = sbreak
                    }
                    instance_destroy()
                }
            }
        }
    }
    alpha = 3
}
var range = 16 * alpha
shakex1 = random_range((-range), range)
shakey1 = random_range((-range), range)
shakex2 = random_range((-range), range)
shakey2 = random_range((-range), range)
shakex3 = random_range((-range), range)
shakey3 = random_range((-range), range)
