function scrsplash2(argument0, argument1, argument2, argument3, argument4, argument5, argument6) //gml_Script_scrsplash2
{
    if (objplayerview.at <= 0.1)
    {
        var splash = instance_create_depth(argument0, argument1, argument6, objsplash)
        splash.splash = argument2
        splash.sprite_index = argument2
        splash.image_index = argument3
        splash.creator = self
        splash.xscale = argument4
        splash.yscale = argument4
        splash.image_speed = argument5 * image_speed
    }
}

