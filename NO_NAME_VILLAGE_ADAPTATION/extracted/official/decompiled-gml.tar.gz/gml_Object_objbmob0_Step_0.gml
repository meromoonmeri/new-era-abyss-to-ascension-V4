event_inherited()
depth = (-y) - 40
idir = scrdir(self, target)
if (oldstate != state)
{
    oldstate = state
    sound = 0
}
if (hp > (maxhp * 0.66))
    hpthreshold = 0
else if (hp > (maxhp * 0.33))
    hpthreshold = 1
else
    hpthreshold = 2
if (place_meeting(x, y, objplayer) && objplayer.iframe <= 0 && alpha == 1)
{
    if (state != 4 && state != 5)
    {
        with (objplayer)
            scrmovcol(4, scrdir(other, self))
    }
}
if (sptrb > 0)
{
    if (sptrb < 1)
    {
        if ((global.time % (1 / sptrb)) == 0)
            sptrb = 1
        else
            sptrb = 0
    }
    repeat sptrb
    {
        var rdist = irandom_range(64, 128)
        var rdir = dir + (random_range(-45, 45)) + (random_range(-45, 45)) + (random_range(-45, 45)) + (random_range(-45, 45))
        var ptx = x + (lengthdir_x(rdist, rdir))
        var pty = y + (lengthdir_y(rdist, rdir))
        part_system_depth(ps, ((-y) - 45))
        part_particles_create(ps, ptx, pty, ptrb, 1)
    }
    sptrb = 0
}
if (state == 0)
{
    image_speed = 0.1
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmob0i3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmob0i4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmob0i3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmob0i2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmob0i1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmob0i0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmob0i1
    else
        sprite_index = sbmob0i2
    if (timer0 < 2)
        timer0 += (1/30)
    else
    {
        spd = 0
        image_index = 0
        if (hp > (maxhp * 0.33))
            state = 3
        else
            state = choose(3, 2)
    }
}
else
    timer0 = 0
if (state == 1)
{
    image_speed = 0.05 + spd / 100
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmob0m3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmob0m4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmob0m3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmob0m2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmob0m1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmob0m0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmob0m1
    else
        sprite_index = sbmob0m2
    scrmovcol(spd, dir)
    if (position_meeting((x + (lengthdir_x((spd * 40), dir))), (y + (lengthdir_y((spd * 40), dir))), objallcol) && timer1 != 180 && spd > 6)
        timer1 = 180
    else if (timer1 < 180)
    {
        timer1 += 1
        if (!audio_is_playing(snbmob0drag1))
            scrsound(snbmob0drag1, 50, 1, random_range(0.8, 1.2))
        if (sound == 0)
        {
            sound = 1
            scrsoundgain(snbmob0digging0, 50, 0.5, 500)
        }
        sptrb = 0.25
        if ((timer1 % 6) == 0)
        {
            part_particles_create(part_system0, x, y, rock0, 1)
            part_particles_create(part_system1, x, y, rock1, 1)
            part_particles_create(part_system2, x, y, rock2, 1)
        }
        if (image_index < 1)
            maxspd = 1
        else if (image_index < 2)
        {
            if (maxspd < 8)
            {
                maxspd = 8
                sptrb = 5
            }
        }
        else if (image_index < 3)
            maxspd = 1
        else if (image_index < 4)
        {
            if (maxspd < 8)
            {
                maxspd = 8
                sptrb = 5
            }
        }
        if (spd < maxspd)
            spd += 1
        else if (spd > maxspd)
            spd -= 0.2
        if (spd > 6)
            chit = 2
        if (image_index <= image_speed)
            scrsound(snbmob0slam10, 100, 0.7, 1)
        else if (image_index < 2)
        {
        }
        else if (image_index <= (2 + image_speed))
            scrsound(snbmob0slam10, 100, 0.7, 0.9)
    }
    else if (spd > 1)
    {
        spd -= (spd / 10)
        if (sound == 1)
        {
            sound = 2
            scrsoundgain(snbmob0digging0, 50, 0, 1000)
        }
    }
    else
    {
        if audio_is_playing(snbmob0drag1)
            audio_stop_sound(snbmob0drag1)
        chit = 0
        if (hp > (maxhp * 0.66))
            state = 0
        else
            state = 2
    }
}
else
{
    timer1 = 0
    trail1 = 0
}
if (state == 2)
{
    if (dir >= 0 && dir < 90)
        sprite_index = sbmob0d3
    else if (dir >= 90 && dir < 180)
    {
        sprite_index = sbmob0d3
        facing = -1
    }
    else if (dir >= 180 && dir < 270)
    {
        sprite_index = sbmob0d1
        facing = -1
    }
    else
        sprite_index = sbmob0d1
    if (image_index < 10)
    {
        image_speed = 0.2
        sptrb = 0.5
        if (image_index > 1 && timer2 == 0)
        {
            timer2 = 1
            sptrb = 10
            scrsound(snbmob0dig1, 50, 1, random_range(0.7, 1))
        }
        else if (image_index > 3 && timer2 == 1)
        {
            timer2 = 2
            sptrb = 10
            scrsound(snbmob0dig1, 50, 1, random_range(0.7, 1))
        }
        else if (image_index > 5 && timer2 == 2)
        {
            timer2 = 3
            sptrb = 10
            scrsound(snbmob0dig1, 50, 1, random_range(0.7, 1))
        }
        else if (image_index > 7 && timer2 == 4)
        {
            timer2 = 5
            sptrb = 10
            scrsound(snbmob0slam10, 50, 1, random_range(0.5, 0.7))
        }
        else if (image_index > 9 && timer2 == 5)
        {
            timer2 = 6
            sptrb = 10
            scrsound(snbmob0slam10, 50, 1, random_range(0.4, 0.5))
        }
    }
    else if (image_index < 10.2)
    {
        image_speed = 0.0033333333333333335
        if (image_index > 10.05 && timer2 < 7)
        {
            timer2 = 7
            part_particles_create(part_system0, x, y, rock0, 1)
            part_particles_create(part_system1, x, y, rock1, 1)
            part_particles_create(part_system2, x, y, rock2, 1)
        }
        var d = scrdist(self, objplayer)
        d = d / 64
        d = d - 3
        d = d / 7
        d = 1 - d
        d = d * 3
        d = d + 1
        spd = d
        prevx = 0
        prevy = 0
        dir = (scrdir(self, player)) + (choose(-30, 30))
    }
    else if (image_index < 10.5)
    {
        image_speed = 0.004166666666666667
        alpha = 0
        spd = clamp((spd * 1.05), 1, 12)
        var ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 10)) * sign(ad))
        scrmovcol(spd, dir)
        if (point_distance(x, y, prevx, prevy) > 32)
        {
            sptrb = 3
            prevx = x
            prevy = y
            part_particles_create(part_system0, x, y, ptdt0, 1)
            part_particles_create(part_system1, x, y, ptdt1, 1)
            part_particles_create(part_system2, x, y, ptdt2, 1)
        }
        if (scrdist(self, player) < 64)
            image_index = 10.5
        if (sound == 0)
        {
            sound = 1
            scrsoundgain(snbmob0digging0, 50, 1, 500)
        }
    }
    else if (image_index < 10.6)
    {
        image_speed = 0.05
        if (sound == 1)
        {
            sound = 2
            scrsoundgain(snbmob0digging0, 50, 0, 500)
        }
    }
    else
    {
        state = 5
        spd = 0
        image_index = 0
        scrsound(snbmob0slam10, 50, 1, 1)
        timer2 = 0
        alpha = 1
        x += lengthdir_x((spd * 4), dir)
        y += lengthdir_y((spd * 4), dir)
        dir = scrdir(self, player)
        dist = scrdist(self, player)
    }
}
if (state == 3)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmob0t3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmob0t4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmob0t3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmob0t2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmob0t1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmob0t0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmob0t1
    else
        sprite_index = sbmob0t2
    if (image_index < 1)
        image_speed = 0.2
    else if (image_index < 2)
    {
        image_speed = 0.05
        if (timer3 == 0)
        {
            objplayerview.shaket = 6
            scrsound(snbmob0slam10, 100, 1, 1)
            timer3 = 1
        }
        ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 10)) * sign(ad))
    }
    else if (image_index < (image_number - 0.5))
    {
        chit = 2
        mask_index = ssplash1
        if (timer3 < 2)
        {
            timer3 = 2
            part_type_size(ptw, 1.2, 1.2, 0.02, 0)
            part_particles_create(part_system2, x, y, ptw, 1)
            part_type_size(ptw, 1.1, 1.2, 0.015, 0)
            objplayerview.shaket = 12
            scrsplash(x, y, ssplash1, 1)
            scrsound(snbmob0slam11, 100, 1, 1)
            scrsound(snbmob0slam12, 100, 1, 1)
        }
        else if (timer3 < 3)
        {
            timer3 += 0.1
            sptrb = 3
        }
        image_speed = 0.1
    }
    else
    {
        chit = 0
        mask_index = sbmob0shad
        state = 1
        timer3 = 0
        image_index = 0
    }
}
else
    timer3 = 0
if (state == 5)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmob0u3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmob0u3
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmob0u3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmob0u3
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmob0u1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmob0u1
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmob0u1
    else
        sprite_index = sbmob0u1
    if (timer5 == 0 && image_index > 2.5)
    {
        repeat (7)
        {
            var proj = instance_create_depth(x, y, depth, objbmob0spit0)
            proj.dir = irandom_range(-180, 180)
        }
        if (hit4 == 0)
            chit = 2
        scrsound(snbmob0slam11, 100, 1, 1)
        scrsound(snmobau32, 100, 0.9, 0.9)
        scrsound(snmobau2rock2, 100, 1, 0.7)
        mask_index = ssplash1
        objplayerview.shaket = 10
        part_type_size(ptw, 1.2, 1.2, 0.02, 0)
        part_particles_create(part_system2, x, y, ptw, 1)
        part_type_size(ptw, 1.1, 1.2, 0.015, 0)
        scrsplash(x, y, ssplash1, 0)
        part_particles_create(part_system0, x, y, rock0, 1)
        part_particles_create(part_system1, x, y, rock1, 1)
        part_particles_create(part_system2, x, y, rock2, 1)
        sptrb = 30
        timer5 += 1
    }
    if (image_index < (image_number - 1))
    {
        image_speed = 0.2
        if (timer5 < 0)
        {
            timer5 = 0
            scrsound(snbmob0slam10, 100, 1, 1)
        }
    }
    else if (image_index < (image_number - 0.2))
    {
        hit4 = 0
        chit = 0
        mask_index = sbmob0shad
        image_speed = 0.05
    }
    else
    {
        if (objplayer.stage != 0.47)
        {
            if (hpthreshold == 0)
                state = 0
            else
                state = 6
            if (start == 0)
            {
                start = 1
                state = 3
            }
            image_index = 0
        }
        image_speed = 0
    }
}
else
    timer5 = 0
if (state == 6)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmob0s3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmob0s4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmob0s3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmob0s2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmob0s1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmob0s0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmob0s1
    else
        sprite_index = sbmob0s2
    if (image_index < 2)
    {
        scrsoundgain(snbmob0spit0, 50, 1, 100)
        scrsound(snbmobsm1, 50, 0.5, 1)
        image_speed = 0.4
    }
    else if (image_index < 3)
    {
        image_speed = 0.05
        if (image_index < 2.5)
        {
            ad = angle_difference(dir, idir)
            dir -= ((min(abs(ad / 10), 10)) * sign(ad))
        }
    }
    else if (image_index < (image_number - 0.2))
    {
        if audio_is_playing(snbmob0spit0)
        {
            audio_stop_sound(snbmob0spit0)
            scrsound(snbmob0slam11, 50, 1, 1)
            scrsound(snmobau32, 50, 0.4, 1)
            scrsound(snrm25fencesplash, 50, 0.7, 1)
        }
        if (image_speed != 0.2)
        {
            var proj1 = instance_create_depth((x + (lengthdir_x(108, dir))), (y + (lengthdir_y(60, dir))), 0, objbmob0spit)
            proj1.dir = dir
            proj1.vvel = irandom_range(6, 10)
            var proj2 = instance_create_depth((x + (lengthdir_x(108, (dir + 30)))), (y + (lengthdir_y(60, (dir + 30)))), 0, objbmob0spit)
            proj2.dir = dir + 30
            proj2.vvel = irandom_range(6, 10)
            var proj3 = instance_create_depth((x + (lengthdir_x(108, (dir - 30)))), (y + (lengthdir_y(60, (dir - 30)))), 0, objbmob0spit)
            proj3.dir = dir - 30
            proj3.vvel = irandom_range(6, 10)
            var proj4 = instance_create_depth((x + (lengthdir_x(108, (dir - 30)))), (y + (lengthdir_y(60, (dir - 30)))), 0, objbmob0spit)
            proj4.dir = dir - 10
            proj4.vvel = irandom_range(6, 10)
            var proj5 = instance_create_depth((x + (lengthdir_x(108, (dir - 30)))), (y + (lengthdir_y(60, (dir - 30)))), 0, objbmob0spit)
            proj5.dir = dir + 10
            proj5.vvel = irandom_range(6, 10)
            sptrb = 10
            image_speed = 0.2
        }
    }
    else if (hpthreshold < 2)
        state = 0
    else if (timer6 == 0)
        timer6 = choose(1, 2)
    else if (timer6 == 1)
        state = 0
    else if (timer6 == 2)
    {
        state = 6
        timer6 = 1
    }
}
else
    timer6 = 0
if (state == 2 && image_index >= 8)
    hit = -2
else if (hit < 0)
    hit = 0
if (hit > 0 && state != 7)
    scrmobhurt(-1, 7, 1)
if (state == 7)
{
    if audio_is_playing(snbmob0spit0)
        audio_stop_sound(snbmob0spit0)
    alpha = 1
    sprite_index = sbmob0dead
    if (image_index < (image_number - 1))
        image_speed = 0.1
    else if (image_speed != 0)
    {
        image_speed = 0
        if (dead == 0)
            dead = 1
        objplayerview.shaket = 6
        scrsound(snbmob0slam11, 50, 1, 1)
        scrsound(snbmob0slam12, 50, 1, 0.8)
        scrsplash(x, y, ssplash1, 0)
        image_index = image_number - 0.5
    }
    if (sound == 0)
    {
        sound = 1
        scrsound(snbmob0dying0, 50, 1, 1)
    }
}
