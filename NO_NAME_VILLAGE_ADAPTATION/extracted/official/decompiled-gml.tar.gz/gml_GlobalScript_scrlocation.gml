function scrlocation(argument0) //gml_Script_scrlocation
{
    if (argument0 == 26 || argument0 == 0 || argument0 == 70)
        return 10;
    else if (argument0 == 60)
        return 4;
    else if (argument0 == 10 || argument0 == 52 || argument0 == 43 || argument0 == 55 || argument0 == 68 || argument0 == 45)
        return 3;
    else if (argument0 == 84)
        return 2.5;
    else if (argument0 == 51 || argument0 == 9 || argument0 == 39 || argument0 == 61 || argument0 == 18 || argument0 == 20)
        return 2;
    else if (argument0 == 7 || argument0 == 33)
        return 1;
    else if (argument0 == 27 || argument0 == 82 || argument0 == 32 || argument0 == 25 || argument0 == 47 || argument0 == 17 || argument0 == 15 || argument0 == 34 || argument0 == 50 || argument0 == 40 || argument0 == 3 || argument0 == 49 || argument0 == 23 || argument0 == 28)
        return 0.5;
    else
        return 0;
}

