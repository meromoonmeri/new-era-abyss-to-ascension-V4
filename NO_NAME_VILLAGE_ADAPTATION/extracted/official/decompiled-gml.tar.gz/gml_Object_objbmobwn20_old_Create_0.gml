fl = 0
dir = 0
spd = 4
