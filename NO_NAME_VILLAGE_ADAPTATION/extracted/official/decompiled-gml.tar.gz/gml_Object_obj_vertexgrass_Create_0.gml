grass_mode = 0
grass_radius = 320
grass_rect_hor = 96
grass_rect_ver = 48
if (grass_mode == 0)
    grass_number = room_width * room_height / 5000
else
    grass_number = grass_radius * 5
grass_sprite = sleaf
grass_random_image = true
grass_animate = false
grass_pattern = false
grass_wind = 1
grass_speed = 1
wind_hsp = 0
pattern_size = 5
bugfix = false
if grass_animate
{
    uni_time = shader_get_uniform(sh_grass, "time")
    uni_dist = shader_get_uniform(sh_grass, "wave_dist")
    uni_slow = shader_get_uniform(sh_grass, "slow")
    uni_spd = shader_get_uniform(sh_grass, "wind_spd")
    uni_patbool = shader_get_uniform(sh_grass, "patbool")
    uni_pattern = shader_get_uniform(sh_grass, "pattern")
}
gpu_set_ztestenable(true)
vertex_format_begin()
vertex_format_add_position_3d()
vertex_format_add_texcoord()
vertex_format_add_custom(2, 4)
vertex_format_add_custom(2, 4)
vertex_format_add_custom(2, 4)
vertex_format_add_color()
var format = vertex_format_end()
vbuff = vertex_create_buffer()
vertex_begin(vbuff, format)
repeat grass_number
{
    var im_ind = 0
    if grass_random_image
        im_ind = irandom(sprite_get_number(grass_sprite) - 1)
    tex = sprite_get_texture(grass_sprite, im_ind)
    var uvs = sprite_get_uvs(grass_sprite, im_ind)
    var uv_left = uvs[0]
    var uv_top = uvs[1]
    var uv_right = uvs[2]
    var uv_bottom = uvs[3]
    var spr_w = sprite_get_width(grass_sprite)
    var spr_h = sprite_get_height(grass_sprite)
    if (grass_mode == 0)
    {
        var left = random_range((-spr_w), room_width)
        var top = random_range((-spr_h), room_height)
    }
    else if (grass_mode == 1)
    {
        var rand_dist = random(grass_radius)
        var rand_dir = random(360)
        left = x + (lengthdir_x(rand_dist, rand_dir))
        top = y + (lengthdir_y(rand_dist, rand_dir))
    }
    else if (grass_mode == 2)
    {
        left = random_range(x, (x + grass_rect_hor))
        top = random_range(y, (y + grass_rect_ver))
    }
    var right = left + spr_w
    var bottom = top + spr_h
    var xx = left + spr_w / 2
    var yy = top + spr_h / 2
    var dep = layer_get_depth("shadows")
    vertex_position_3d(vbuff, left, top, dep)
    vertex_texcoord(vbuff, uv_left, uv_top)
    vertex_texcoord(vbuff, uv_left, uv_top)
    vertex_texcoord(vbuff, (uv_right - uv_left), (uv_bottom - uv_top))
    vertex_texcoord(vbuff, xx, yy)
    vertex_colour(vbuff, 16777215, 1)
    vertex_position_3d(vbuff, right, top, dep)
    vertex_texcoord(vbuff, uv_right, uv_top)
    vertex_texcoord(vbuff, uv_left, uv_top)
    vertex_texcoord(vbuff, (uv_right - uv_left), (uv_bottom - uv_top))
    vertex_texcoord(vbuff, xx, yy)
    vertex_colour(vbuff, 16777215, 1)
    vertex_position_3d(vbuff, left, bottom, dep)
    vertex_texcoord(vbuff, uv_left, uv_bottom)
    vertex_texcoord(vbuff, uv_left, uv_top)
    vertex_texcoord(vbuff, (uv_right - uv_left), (uv_bottom - uv_top))
    vertex_texcoord(vbuff, xx, yy)
    vertex_colour(vbuff, 16777215, 1)
    vertex_position_3d(vbuff, right, top, dep)
    vertex_texcoord(vbuff, uv_right, uv_top)
    vertex_texcoord(vbuff, uv_left, uv_top)
    vertex_texcoord(vbuff, (uv_right - uv_left), (uv_bottom - uv_top))
    vertex_texcoord(vbuff, xx, yy)
    vertex_colour(vbuff, 16777215, 1)
    vertex_position_3d(vbuff, right, bottom, dep)
    vertex_texcoord(vbuff, uv_right, uv_bottom)
    vertex_texcoord(vbuff, uv_left, uv_top)
    vertex_texcoord(vbuff, (uv_right - uv_left), (uv_bottom - uv_top))
    vertex_texcoord(vbuff, xx, yy)
    vertex_colour(vbuff, 16777215, 1)
    vertex_position_3d(vbuff, left, bottom, dep)
    vertex_texcoord(vbuff, uv_left, uv_bottom)
    vertex_texcoord(vbuff, uv_left, uv_top)
    vertex_texcoord(vbuff, (uv_right - uv_left), (uv_bottom - uv_top))
    vertex_texcoord(vbuff, xx, yy)
    vertex_colour(vbuff, 16777215, 1)
}
vertex_end(vbuff)
vertex_freeze(vbuff)
if bugfix
    gpu_set_ztestenable(false)
