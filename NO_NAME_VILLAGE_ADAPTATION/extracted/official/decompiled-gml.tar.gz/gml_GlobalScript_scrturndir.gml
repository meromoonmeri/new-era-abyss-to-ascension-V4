function scrturndir(argument0, argument1, argument2, argument3) //gml_Script_scrturndir
{
    var ad = (angle_difference(argument0, argument1)) * argument2
    argument3 -= ((min(abs(ad), argument3)) * sign(ad))
}

