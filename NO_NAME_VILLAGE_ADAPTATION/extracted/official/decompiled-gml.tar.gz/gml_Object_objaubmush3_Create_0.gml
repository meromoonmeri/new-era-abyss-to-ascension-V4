event_inherited()
sprite = 683
watershad = 2137
shadshad = 481
