if (update == true)
{
    if (blockcount < (array_length_1d(block) - 1))
    {
        if (objplayer.stage > block[blockcount][1])
            blockcount += 1
        else
            update = false
    }
    else
        update = false
    if (objplayer.stage <= block[blockcount][1])
    {
        if (objplayer.stage >= block[blockcount][0])
            noenter = true
        else
            noenter = false
    }
    else
        noenter = false
}
