with (objplayerview)
    target = other
if mouse_check_button(mb_left)
{
    if keyboard_check(ord("0"))
        dir = point_direction(x, y, mouse_x, mouse_y)
    if keyboard_check(ord("1"))
    {
        if (state == 0)
        {
            state = 1
            image_index = 0
        }
    }
    if keyboard_check(ord("2"))
    {
        if (state == 0)
        {
            state = 2
            image_index = 0
        }
    }
}
if keyboard_check_pressed(ord("3"))
    image_alpha = 1 - image_alpha
if (dir < 0)
    dir += 360
else if (dir > 360)
    dir -= 360
if (dir > 90 && dir <= 270)
    image_xscale = -1
else
    image_xscale = 1
var idir = point_direction(x, y, objplayer.x, objplayer.y)
if (state == 0)
{
    depth = layer_get_depth("shadows") + 4
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = smob0i3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = smob0i4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = smob0i3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = smob0i2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = smob0i1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = smob0i0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = smob0i1
    else
        sprite_index = smob0i2
    if (image_index < 1)
        image_speed = 0.02
    else
        image_speed = 0.1
    if (aggro == 0)
    {
        if (scrdist(self, player) < 300)
            aggro = 1
        if (timer0 < 1)
            timer0 += 0.0033333333333333335
        else
        {
            state = 1
            timer0 = 0
            dir = irandom(360)
            image_index = 0
        }
    }
    else
    {
        if (scrdist(self, player) > 1000)
            aggro = 0
        image_index = 0
        if (scrdist(self, player) > 180 || timer0 > 0)
        {
            state = 1
            timer0 = 0
        }
        else
        {
            state = 2
            timer0 = 1
        }
    }
}
if (state == 1)
{
    depth = layer_get_depth("shadows") + 4
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = smob0s3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = smob0s4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = smob0s3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = smob0s2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = smob0s1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = smob0s0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = smob0s1
    else
        sprite_index = smob0s2
    var dccl = clamp((((scrdist(self, player)) - 30) / 170), 0, 1)
    if (image_index < 1)
    {
        image_speed = 0.2
        spd += (((4 + aggro * 2) * dccl - spd) / 12)
        var ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 20)) * sign(ad))
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.1
        spd += ((aggro * 2 * dccl - spd) / 24)
    }
    else
    {
        state = 0
        image_index = 0
    }
    x += lengthdir_x(spd, dir)
    y += lengthdir_y(spd, dir)
}
if (state == 2)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = smob0j3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = smob0j4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = smob0j3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = smob0j2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = smob0j1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = smob0j0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = smob0j1
    else
        sprite_index = smob0j2
    if (image_index < 1)
    {
        depth = layer_get_depth("shadows") + 4
        image_speed = 0.075
        spd += ((-spd) / 8)
        ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 3)) * sign(ad))
    }
    else if (image_index < 4)
    {
        image_speed = 0.2
        spd = 3
        if (place_meeting(x, y, objplayer) && objplayer.iframe <= 0)
        {
            with (objplayer)
            {
                iframe = 1
                hp -= 1
                state = 6
                dir = scrdir(self, other)
                caninput = false
                image_index = 0
                objplayerview.shaket = 16
            }
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        depth = layer_get_depth("shadows") + 4
        image_speed = 0.05
        spd += ((-spd) / 12)
    }
    else
    {
        state = 0
        image_index = 0
    }
    x += lengthdir_x(spd, dir)
    y += lengthdir_y(spd, dir)
}
