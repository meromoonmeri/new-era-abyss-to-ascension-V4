event_inherited()
objplayer.boss = self
mobname = "Parasite"
mob = 3
givexp = 0
dir = 270
level = 7
maxhp = 30
hp = maxhp
pattern = -1
ptimer = 0
startroar = 1
state = -1
dir = 271
sound = 0
rise = 0
swipe = 0
dshspd = 0
prevface = 1
jump = 0
z = 0
vel = 0
zaccl = 0.6
jx = 0
jy = 0
splash = 0
hitsplash = 0
splat = 0
sptx = 0
spty = 0
spx = 0
spy = 0
spspd = 0
spdir = 0
prevspx = 0
prevspy = 0
pdx = 0
pdy = 0
stomp = 0
stomptype = 0
stompcount = 0
timer1 = 0
timer2 = 0
timer3 = 0
timer4 = 0
timer5 = 0
timer6 = 0
timer7 = 0
ttcx = 0
ttcy = 0
ttcprevx = 0
ttcprevy = 0
tthoriz = 0
ttvert = 0
ttangle = 0
tt0c = 30
tt0ct = tt0c
tt1c = -20
tt1ct = tt1c
tt2c = 40
tt2ct = tt2c
tt3c = -80
tt3ct = tt3c
tt4c = 100
tt4ct = tt4c
tt5c = -100
tt5ct = tt5c
bvy = 0
if (room == rmcave2)
{
    var layer_above_id = layer_get_id("above")
    layer_set_visible(layer_above_id, 0)
    var lay_id = layer_get_id("bg2")
    var back_id = layer_sprite_get_id(lay_id, "graphic_49C004C8")
    layer_sprite_change(back_id, srmcave2bg21)
    with (objcave204)
    {
        image_index = 1
        var s = instance_create_depth(x, y, (layer_get_depth("shadows") + 1), objempty)
        s.sprite_index = srmcave204
        s.image_index = 2
        s.image_xscale = 4
        s.image_yscale = 4
    }
    with (objcave200)
        ibreak = 1
    with (objcave205)
        ibreak = 1
    with (objcave20)
        sprite_index = scave201
}
pssw = part_system_create()
part_system_depth(pssw, (-y))
psrr = part_system_create()
part_system_depth(psrr, (-room_height))
ptsw = part_type_create()
part_type_sprite(ptsw, 1041, 0, 0, 0)
part_type_scale(ptsw, 4, 4)
part_type_size(ptsw, 0.2, 0.3, 0.07, 0.1)
part_type_alpha3(ptsw, 0, 0.9, 0)
part_type_blend(ptsw, 1)
part_type_life(ptsw, 30, 30)
ptsp = part_type_create()
part_type_sprite(ptsp, 1445, 1, 1, 0)
part_type_size(ptsp, 0.5, 0.5, 0.06, 0)
part_type_alpha3(ptsp, 0.2, 0.9, 0)
part_type_life(ptsp, 12, 12)
ptslj = part_type_create()
part_type_sprite(ptslj, 588, 1, 1, 0)
part_type_alpha3(ptslj, 1, 1, 0)
part_type_life(ptslj, 30, 30)
