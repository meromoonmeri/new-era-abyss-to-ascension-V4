draw_sprite_ext(sbirdshad, 0, x, y, 4, 4, 0, -1, alpha)
draw_sprite_ext(sprite_index, image_index, x, (y - z), (4 * facing), 4, 0, -1, alpha)
