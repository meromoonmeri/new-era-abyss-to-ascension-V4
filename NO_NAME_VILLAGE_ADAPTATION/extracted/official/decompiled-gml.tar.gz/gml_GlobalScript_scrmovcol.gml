function scrmovcol(argument0, argument1) //gml_Script_scrmovcol
{
    var vfl = 0
    if variable_instance_exists(id, "fl")
        vfl = fl
    scrcollisions = ds_list_create()
    ds_list_add(scrcollisions, 435)
    if (vfl == 0)
        ds_list_add(scrcollisions, 447)
    else
        ds_list_add(scrcollisions, 39)
    if variable_instance_exists(id, "mob")
    {
        if (mob > 0)
            ds_list_add(scrcollisions, 305)
    }
    hspd = lengthdir_x(argument0, argument1)
    vspd = lengthdir_y(argument0, argument1)
    for (var cx = 0; cx < 2; cx += 1)
    {
        if place_meeting((x + (lengthdir_x(argument0, argument1))), y, ds_list_find_value(scrcollisions, cx))
        {
            hspd = 0
            return 1;
        }
    }
    x += hspd
    for (var cy = 0; cy < 2; cy += 1)
    {
        if place_meeting(x, (y + (lengthdir_y(argument0, argument1))), ds_list_find_value(scrcollisions, cy))
        {
            vspd = 0
            return 1;
        }
    }
    y += vspd
    ds_list_delete(scrcollisions, 1)
}

