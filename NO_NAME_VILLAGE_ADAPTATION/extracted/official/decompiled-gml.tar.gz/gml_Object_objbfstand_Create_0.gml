dir = -1
checkx = -1
checky = -1
startmap = -1
if (room == rm38)
    dir = 225
if (room == rm39)
    dir = 225
if (room == rm49)
{
    checkx = 1120
    checky = 4352
}
if (room == rm410)
{
    checkx = 2720
    checky = 864
}
if (room == rm77)
{
    checkx = 2784
    checky = 1888
}
