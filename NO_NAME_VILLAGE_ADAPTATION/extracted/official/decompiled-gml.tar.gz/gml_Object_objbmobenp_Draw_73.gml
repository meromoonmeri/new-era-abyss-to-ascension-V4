draw_sprite_ext(sbmobenpesh, explode, x, y, 1, 1, 0, -1, alpha)
if (shoot < 3)
    draw_sprite_ext(sbmobenpe, explode, x, y, 1, 1, 0, -1, 1)
if (shoot == 0)
{
    if (pz != 0)
        draw_sprite(sbmobenpt, pindex, px, (py - pz))
}
else if (shoot == 1 && notrail == false)
{
    draw_sprite(sbmobwn2shp, 2.5, px, (py - pz))
    for (var i = 0; i < trail; i += 1)
    {
        var pdir = point_direction(px, (py - pz), startx, (starty - startz))
        draw_sprite(sbmobwn2shp, 0, (px + (lengthdir_x(power(i, 1.5), pdir))), (py - pz + (lengthdir_y(power(i, 1.5), pdir))))
    }
}
