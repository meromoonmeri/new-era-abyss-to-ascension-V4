function scrobjview(argument0, argument1, argument2) //gml_Script_scrobjview
{
    if (instance_exists(argument0) && instance_exists(argument1))
    {
        var scrpdist = point_distance(argument0.x, argument0.y, argument1.x, argument1.y)
        var scrpdir = point_direction(argument0.x, argument0.y, argument1.x, argument1.y)
        var scrpdiff = (point_distance(argument0.x, argument0.y, argument1.x, argument1.y)) * (argument2 / 100)
        objplayerview.target = -4
        objplayerview.targetx = argument0.x + (lengthdir_x(min(scrpdiff, scrpdist), scrpdir))
        objplayerview.targety = argument0.y + (lengthdir_y(min(scrpdiff, scrpdist), scrpdir))
        return point_distance(objplayerview.x, objplayerview.y, objplayerview.targetx, objplayerview.targety);
    }
}

