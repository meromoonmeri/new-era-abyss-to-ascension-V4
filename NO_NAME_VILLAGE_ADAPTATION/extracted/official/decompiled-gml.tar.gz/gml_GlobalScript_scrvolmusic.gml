function scrvolmusic(argument0, argument1) //gml_Script_scrvolmusic
{
    with (objaudio)
    {
    }
}

