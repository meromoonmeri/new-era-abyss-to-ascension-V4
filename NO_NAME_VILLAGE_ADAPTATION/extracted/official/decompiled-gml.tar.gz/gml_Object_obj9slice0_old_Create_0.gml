controls()
scrsound(snclick1, 50, 0.5, 1)
objplayer.caninput = false
text = 0
font = 2
state = 1
xscale = 0
yscale = 0
yscalemax = 0
bar = 0
bxscale = 0
by = 0
