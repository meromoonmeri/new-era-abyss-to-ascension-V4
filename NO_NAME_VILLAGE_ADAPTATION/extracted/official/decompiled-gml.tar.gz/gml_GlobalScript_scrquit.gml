function scrquit() //gml_Script_scrquit
{
    with (objstage)
        ds_list_destroy(persistentrooms)
    ds_map_clear(global.svrm)
    room_goto(mainmenu)
    with (all)
        instance_destroy()
    audio_stop_all()
}

