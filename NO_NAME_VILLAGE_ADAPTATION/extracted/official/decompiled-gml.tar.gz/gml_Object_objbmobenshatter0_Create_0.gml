depth = layer_get_depth("shadows")
timer = 0
shatter = 0
sprite = 2669
scale = 0.5
image_alpha = 0
