function scrthrowarc(argument0, argument1, argument2, argument3, argument4, argument5, argument6, argument7) //gml_Script_scrthrowarc
{
    var z = argument5
    var zvel = argument6
    var zaccl = argument7
    var dist = point_distance(argument1, argument2, argument3, argument4)
    var dir = point_direction(argument1, argument2, argument3, argument4)
    var spd = 0
    spd = dist / (zvel / zaccl + (sqrt(2 * z / zaccl)))
    var vobj = instance_create_layer(argument1, argument2, "instances", argument0)
    vobj.z = z
    vobj.zvel = zvel
    vobj.zaccl = zaccl
    vobj.dir = dir
    vobj.spd = spd
}

