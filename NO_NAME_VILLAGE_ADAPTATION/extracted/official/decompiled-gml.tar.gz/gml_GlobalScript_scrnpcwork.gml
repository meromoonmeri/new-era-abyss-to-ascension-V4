function scrnpcwork(argument0, argument1, argument2, argument3, argument4) //gml_Script_scrnpcwork
{
    if (!instance_exists(argument2))
    {
        var npc = instance_create_layer(argument0, argument1, "instances", argument2)
        npc.state = argument3
        npc.alpha = argument4
    }
    else
    {
        if (x != -1)
            argument2.x = argument0
        if (y != -1)
            argument2.y = argument1
        argument2.state = argument3
        argument2.alpha = argument4
    }
}

