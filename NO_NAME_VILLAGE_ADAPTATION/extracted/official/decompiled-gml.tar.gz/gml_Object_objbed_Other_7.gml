if (state == 3)
{
    if (timer3 == 0)
    {
        timer3 = 1
        image_index = 4
    }
    else
        timer3 = 2
}
else if (state == 2)
{
    state = 3
    image_index = 0
    sprite_index = sbedtidy
}
else if (state == 1)
{
    state = 2
    image_index = 0
    sprite_index = sbedoff
}
