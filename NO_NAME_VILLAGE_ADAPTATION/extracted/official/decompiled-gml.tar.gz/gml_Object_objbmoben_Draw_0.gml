if (evpii >= 0)
    draw_sprite_ext(sbmobenend01, evpii, x, y, 1, 1, 0, -1, 1)
if (z > 0)
{
    var zscale = clamp((1 - z / 320), 0.2, 1)
    draw_sprite_ext(sbmobenshad, 0, x, y, zscale, zscale, 0, -1, ashad)
    draw_sprite_ext(sprite_index, image_index, x, (y - z), (facing * 1), 1, 0, -1, 1)
}
else
{
    draw_sprite(spshad0, (global.time / 20), x, y)
    if (facing == 1)
        draw_sprite_part_ext(sprite_index, image_index, 0, 0, sprite_width, (sprite_yoffset - 12), (x - sprite_xoffset), (y - sprite_yoffset + 12), 1, 1, c_white, alpha)
    else
        draw_sprite_part_ext(sprite_index, image_index, 0, 0, sprite_width, (sprite_yoffset - 12), (x - sprite_xoffset + sprite_width), (y - sprite_yoffset + 12), -1, 1, c_white, alpha)
}
if (flash > 0)
{
    shader_set(shblacken)
    draw_sprite_ext(sprite_index, image_index, x, (y - z), (facing * image_xscale), image_yscale, 0, -1, flash)
    shader_reset()
}
if (evsy >= 0)
{
    evsy += 1
    evsy += ((32 - evsy) / 60)
    draw_sprite_ext(sbmobenend11, 0, x, (y + 20 - evsy / 0.6), 4, 4, 0, -1, 1)
    draw_sprite_ext(sbmobenend11, 1, x, (y + 20 - evsy / 1), 4, 4, 0, -1, 1)
    draw_sprite_ext(sbmobenend11, 2, x, (y + 20 - evsy / 1.4), 4, 4, 0, -1, 1)
    draw_sprite_ext(sbmobenend11, 3, x, (y + 20 - evsy / 1.8), 4, 4, 0, -1, 1)
    draw_sprite_ext(sbmobenend11, 4, x, (y + 20 - evsy / 2), 4, 4, 0, -1, 1)
    draw_sprite_ext(sbmobenend11, 5, x, (y + 20 - evsy / 1.6), 4, 4, 0, -1, 1)
    draw_sprite_ext(sbmobenend11, 6, x, (y + 20 - evsy / 1.2), 4, 4, 0, -1, 1)
    draw_sprite_ext(sbmobenend11, 7, x, (y + 20 - evsy / 0.8), 4, 4, 0, -1, 1)
}
