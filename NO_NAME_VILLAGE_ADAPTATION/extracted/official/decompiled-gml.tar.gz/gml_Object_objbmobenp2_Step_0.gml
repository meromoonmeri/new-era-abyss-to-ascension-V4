depth = (-room_height) * 4
if (shoot == 0)
{
    height += velheight
    x = objbmoben1.x + (lengthdir_x(16, objbmoben1.dir))
    y = objbmoben1.y + (lengthdir_y(16, objbmoben1.dir))
    if (velheight > 0)
        velheight -= (1/15)
}
else if (stack < 6)
{
    image_speed = 0
    if (stack == 0)
    {
        with (objplayer)
        {
            var p = instance_create_layer((x + (lengthdir_x(spd, dir))), (y + (lengthdir_y(spd, dir))), "instances", objbmobenp)
            p.startx = other.x
            p.starty = other.y
            p.startz = other.height
        }
    }
    if (timer < 1)
        timer += 1
    else
    {
        timer = 0
        stack += 1
        repeat (2)
        {
            var rdir = (scrdir(self, objplayer)) + (irandom_range((-10 * stack), (10 * stack)))
            var rdist = irandom_range(((scrdist(self, objplayer)) * 0.1), ((scrdist(self, objplayer)) * 1.5))
            p = instance_create_layer((x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y(rdist, rdir))), "instances", objbmobenp)
            p.startx = x + (choose(((-stack) * 2), (stack * 2)))
            p.starty = y + (choose(((-stack) * 2), (stack * 2)))
            p.startz = height + (choose(((-stack) * 2), (stack * 2)))
        }
    }
}
else
    instance_destroy()
