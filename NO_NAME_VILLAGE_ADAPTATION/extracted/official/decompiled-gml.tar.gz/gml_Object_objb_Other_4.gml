if instance_exists(objplayer)
    update = true
