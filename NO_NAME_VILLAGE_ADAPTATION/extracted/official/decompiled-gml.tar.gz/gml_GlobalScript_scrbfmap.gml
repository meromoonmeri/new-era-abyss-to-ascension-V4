function scrbfmap(argument0) //gml_Script_scrbfmap
{
    if (argument0 == 72 || argument0 == 73 || argument0 == 78 || argument0 == 76 || argument0 == 75 || argument0 == 53 || argument0 == 77 || argument0 == 81 || argument0 == 80 || argument0 == 82 || argument0 == 79 || argument0 == 48 || argument0 == 35 || argument0 == 74 || argument0 == 86 || argument0 == 38 || argument0 == 58 || argument0 == 13 || argument0 == 37 || argument0 == 83 || argument0 == 85)
        return 1;
    if (argument0 == 60)
    {
    }
    return -1;
}

