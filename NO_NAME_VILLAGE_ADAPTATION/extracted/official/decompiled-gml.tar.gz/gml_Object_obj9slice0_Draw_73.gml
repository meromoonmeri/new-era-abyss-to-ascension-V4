draw_sprite_ext(s9slice0, 0, x, y, xscale, yscale, 0, c_white, 1)
if (state == 0)
{
    draw_sprite_ext(s9slice1, select, (x + 8), (y + 8 + by), bxscale, 2.2, 0, c_white, 1)
    for (var i = 0; i < array_length_1d(text); i++)
    {
        if (text[i][0] == "Interact" && canblink == 1)
        {
            blinking = power(sin(global.time / 15), 4)
            if (bar == i)
                blinking /= 2
            draw_sprite_ext(s9slice2, 0, (x + 8), (y + 8 + 48 * i), bxscale, 2.2, 0, c_white, blinking)
        }
        draw_set_halign(fa_center)
        draw_set_font(font)
        draw_set_color(c_black)
        draw_text((x + sprite_get_width(s9slice0) * xscale / 2), (y + 16 + 48 * i), text[i][0])
        if (text[i][0] == "Interact" && canblink == 1)
        {
            draw_set_alpha(blinking / 4)
            draw_set_color(c_white)
            draw_text((x + sprite_get_width(s9slice0) * xscale / 2), (y + 16 + 48 * i), text[i][0])
            draw_set_alpha(1)
        }
    }
}
