function scrdeleteitem(argument0) //gml_Script_scrdeleteitem
{
    if (scritemcheck(argument0) == 1)
    {
        for (var k = 0; k <= 3; k++)
        {
            for (var l = 0; l <= 2; l++)
            {
                if (global.invitem[k][l] == argument0)
                {
                    global.invitem[k][l] = 0
                    return;
                }
            }
        }
    }
}

