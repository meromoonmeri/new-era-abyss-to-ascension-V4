event_inherited()
if (z > 0)
{
    z += vvel
    vvel -= vaccl
    x += lengthdir_x(spd, dir)
    y += lengthdir_y(spd, dir)
}
else
    instance_destroy()
