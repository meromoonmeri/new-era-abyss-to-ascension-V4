function scrsnowtrail(argument0, argument1, argument2) //gml_Script_scrsnowtrail
{
    with (objwinter)
    {
        if (surface_exists(wintertrail) && fade == 1)
        {
            surface_set_target(wintertrail)
            draw_sprite(argument2, 0, argument0, argument1)
            surface_reset_target()
        }
        with (objwtrails)
        {
            if (creator == other.id && surface_exists(wintertrail))
            {
                surface_set_target(wintertrail)
                draw_sprite(argument2, 1, argument0, argument1)
                surface_reset_target()
            }
        }
        with (objwtrailsb)
        {
            if (creator == other.id && surface_exists(wintertrail))
            {
                surface_set_target(wintertrail)
                draw_sprite(argument2, 2, argument0, argument1)
                surface_reset_target()
            }
        }
    }
}

