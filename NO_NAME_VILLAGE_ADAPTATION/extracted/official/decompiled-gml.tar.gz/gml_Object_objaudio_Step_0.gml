if (newroom != 0)
{
    var stage = objplayer.stage
    newroom = 0
    bgwindvol = 1
    bgtreevol = 1
    bgwatervol = 1
    bgseasonvol = 1
    bgmvol = 1
    delay = 1
    if (room == rmempty)
    {
        ds_list_insert(global.bgswind, 0, 198)
        ds_list_insert(global.bgstree, 0, 198)
        ds_list_insert(global.bgswater, 0, 198)
        ds_list_insert(global.bgsseason, 0, 198)
        ds_list_insert(global.bgm, 0, 198)
        ds_list_insert(global.bgm, 1, 198)
    }
    else if (scrseasonmap(room) == 5)
    {
        ds_list_insert(global.bgswind, 0, 198)
        ds_list_insert(global.bgstree, 0, 198)
        ds_list_insert(global.bgswater, 0, 198)
        ds_list_insert(global.bgsseason, 0, 198)
        ds_list_insert(global.bgm, 0, 198)
        ds_list_insert(global.bgm, 1, 198)
    }
    else if (scrbfmap(room) > 0)
    {
        ds_list_insert(global.bgswind, 0, 176)
        ds_list_insert(global.bgstree, 0, 198)
        ds_list_insert(global.bgswater, 0, 283)
        ds_list_insert(global.bgsseason, 0, 198)
        if (room != rm410 && room != rm32)
        {
            ds_list_insert(global.bgm, 0, 201)
            ds_list_insert(global.bgm, 1, 201)
        }
        else
        {
            ds_list_insert(global.bgm, 0, 198)
            ds_list_insert(global.bgm, 1, 198)
        }
    }
    else if (global.season == 0)
    {
        if (room == rm46)
        {
            ds_list_insert(global.bgswind, 0, 176)
            ds_list_insert(global.bgstree, 0, 217)
            ds_list_insert(global.bgswater, 0, 86)
            ds_list_insert(global.bgsseason, 0, 275)
            if (boss == false)
                ds_list_insert(global.bgm, 0, 198)
            else
                ds_list_insert(global.bgm, 0, 276)
        }
        else if (scrlocation(room) == 2)
        {
            ds_list_insert(global.bgswind, 0, 328)
            ds_list_insert(global.bgstree, 0, 198)
            ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 198)
            if (room != rmcave0 && room != rmcave1 && room != rmcave2)
            {
                var gbgm = ds_list_find_value(global.bgm, 0)
                ds_list_insert(global.bgm, 0, 184)
                ds_list_insert(global.bgm, 1, 184)
                gbgm = ds_list_find_value(global.bgm, 0)
            }
            else
            {
                ds_list_insert(global.bgm, 0, 198)
                ds_list_insert(global.bgm, 1, 198)
            }
        }
        else if (scrlocation(room) <= 1)
        {
            ds_list_insert(global.bgswind, 0, 176)
            ds_list_insert(global.bgstree, 0, 217)
            if scrrivermap(room)
                ds_list_insert(global.bgswater, 0, 86)
            else
                ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 275)
            ds_list_insert(global.bgm, 0, 372)
            ds_list_insert(global.bgm, 1, 192)
        }
        else if (scrlocation(room) == 3)
        {
            ds_list_insert(global.bgswind, 0, 198)
            ds_list_insert(global.bgstree, 0, 198)
            ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 239)
            ds_list_insert(global.bgm, 0, 372)
            ds_list_insert(global.bgm, 1, 192)
        }
    }
    else if (global.season == 1)
    {
        if (room == rm82)
        {
            ds_list_insert(global.bgswind, 0, 176)
            ds_list_insert(global.bgstree, 0, 217)
            ds_list_insert(global.bgswater, 0, 86)
            ds_list_insert(global.bgsseason, 0, 275)
            if (boss == false)
                ds_list_insert(global.bgm, 0, 198)
            else
                ds_list_insert(global.bgm, 0, 198)
        }
        else if (scrlocation(room) == 2)
        {
            ds_list_insert(global.bgswind, 0, 328)
            ds_list_insert(global.bgstree, 0, 198)
            ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 198)
            ds_list_insert(global.bgm, 0, 198)
            ds_list_insert(global.bgm, 1, 198)
        }
        else if (scrlocation(room) <= 1)
        {
            ds_list_insert(global.bgswind, 0, 176)
            ds_list_insert(global.bgstree, 0, 217)
            if scrrivermap(room)
                ds_list_insert(global.bgswater, 0, 86)
            else
                ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 275)
            ds_list_insert(global.bgm, 0, 179)
            ds_list_insert(global.bgm, 1, 215)
        }
        else
        {
            ds_list_insert(global.bgswind, 0, 198)
            ds_list_insert(global.bgstree, 0, 198)
            ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 239)
            ds_list_insert(global.bgm, 0, 179)
            ds_list_insert(global.bgm, 1, 215)
        }
    }
    else if (global.season == 2)
    {
        if (room == rm32)
        {
            ds_list_insert(global.bgswind, 0, 176)
            ds_list_insert(global.bgstree, 0, 217)
            ds_list_insert(global.bgswater, 0, 86)
            ds_list_insert(global.bgsseason, 0, 275)
            if (boss == false)
                ds_list_insert(global.bgm, 0, 198)
            else
                ds_list_insert(global.bgm, 0, 198)
        }
        else if (scrlocation(room) == 2)
        {
            ds_list_insert(global.bgswind, 0, 328)
            ds_list_insert(global.bgstree, 0, 198)
            ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 198)
            ds_list_insert(global.bgm, 0, 198)
            ds_list_insert(global.bgm, 1, 198)
        }
        else if (scrlocation(room) <= 1)
        {
            ds_list_insert(global.bgswind, 0, 176)
            ds_list_insert(global.bgstree, 0, 217)
            if scrrivermap(room)
                ds_list_insert(global.bgswater, 0, 86)
            else
                ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 275)
            ds_list_insert(global.bgm, 0, 155)
            ds_list_insert(global.bgm, 1, 212)
        }
        else
        {
            ds_list_insert(global.bgswind, 0, 198)
            ds_list_insert(global.bgstree, 0, 198)
            ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 239)
            ds_list_insert(global.bgm, 0, 155)
            ds_list_insert(global.bgm, 1, 212)
        }
    }
    else if (global.season == 3)
    {
        if (scrlocation(room) == 2)
        {
            if (stage >= 6 && stage < 7)
            {
                ds_list_insert(global.bgswind, 0, 328)
                ds_list_insert(global.bgstree, 0, 198)
                ds_list_insert(global.bgswater, 0, 198)
                ds_list_insert(global.bgsseason, 0, 198)
                if (boss == false)
                    ds_list_insert(global.bgm, 0, 198)
                else
                    ds_list_insert(global.bgm, 0, 288)
            }
            else if (stage >= 7 && stage < 8)
            {
                ds_list_insert(global.bgswind, 0, 328)
                ds_list_insert(global.bgstree, 0, 198)
                ds_list_insert(global.bgswater, 0, 198)
                ds_list_insert(global.bgsseason, 0, 198)
                if (boss == false)
                    ds_list_insert(global.bgm, 0, 198)
                else
                    ds_list_insert(global.bgm, 0, 236)
            }
            else
            {
                ds_list_insert(global.bgswind, 0, 328)
                ds_list_insert(global.bgstree, 0, 198)
                ds_list_insert(global.bgswater, 0, 198)
                ds_list_insert(global.bgsseason, 0, 198)
                ds_list_insert(global.bgm, 0, 198)
                ds_list_insert(global.bgm, 1, 198)
            }
        }
        else if (scrlocation(room) <= 1)
        {
            ds_list_insert(global.bgswind, 0, 304)
            ds_list_insert(global.bgstree, 0, 198)
            if scrrivermap(room)
                ds_list_insert(global.bgswater, 0, 198)
            else
                ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 198)
            ds_list_insert(global.bgm, 0, 49)
            ds_list_insert(global.bgm, 1, 205)
        }
        else
        {
            ds_list_insert(global.bgswind, 0, 240)
            ds_list_insert(global.bgstree, 0, 198)
            ds_list_insert(global.bgswater, 0, 198)
            ds_list_insert(global.bgsseason, 0, 198)
            ds_list_insert(global.bgm, 0, 49)
            ds_list_insert(global.bgm, 1, 205)
        }
    }
    else
    {
        if (objplayer.stage < 8.15)
        {
            ds_list_insert(global.bgswind, 0, 322)
            bgwindvol = 0.3
        }
        else
            ds_list_insert(global.bgswind, 0, 198)
        if (objplayer.stage < 8.15)
        {
            ds_list_insert(global.bgstree, 0, 241)
            bgtreevol = 0.3
        }
        else
            ds_list_insert(global.bgstree, 0, 198)
        ds_list_insert(global.bgswater, 0, 198)
        ds_list_insert(global.bgsseason, 0, 118)
        bgseasonvol = 0.3
        ds_list_insert(global.bgm, 0, 198)
        ds_list_insert(global.bgm, 1, 198)
    }
    gbgm = ds_list_find_value(global.bgm, 0)
    var vgbgm = audio_sound_get_gain(gbgm)
    if (!audio_is_playing(gbgm))
        firstmusic = 1
}
if (delay > 0)
    delay -= (1/3)
else
{
    bgswind = scrsnswitch(global.bgswind, bgswind, bgwindvol)
    bgstree = scrsnswitch(global.bgstree, bgstree, bgtreevol)
    bgswater = scrsnswitch(global.bgswater, bgswater, bgwatervol)
    bgsseason = scrsnswitch(global.bgsseason, bgsseason, bgseasonvol)
    if (global.timeofday < 3)
        scrsnswitchm(global.bgm, bgmvol)
    mdelay = 500
}
if (season != global.season)
{
    season = global.season
    newroom = 1
}
