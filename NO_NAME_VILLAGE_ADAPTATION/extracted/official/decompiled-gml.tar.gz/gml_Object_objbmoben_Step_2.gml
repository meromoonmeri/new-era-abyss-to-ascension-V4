var vhp = hp / maxhp
if (state != 10)
{
    if (vhp < 0.9 && shatter == 0 && phase > 2)
    {
        var s = instance_create_layer(0, 0, "shadows", objbmobenshatter0)
        s.shatter = 0
        shatter = 1
    }
    if (vhp < 0.65 && shatter <= 1 && phase > 1)
    {
        s = instance_create_layer(0, 0, "shadows", objbmobenshatter0)
        s.shatter = 1
        shatter = 2
    }
    if (vhp < 0.6 && shatter <= 2 && phase > 2)
    {
        s = instance_create_layer(0, 0, "shadows", objbmobenshatter0)
        s.shatter = 2
        shatter = 3
    }
    if (vhp < 0.4 && shatter <= 3 && phase > 1)
    {
        s = instance_create_layer(0, 0, "shadows", objbmobenshatter0)
        s.shatter = 3
        shatter = 4
    }
    if (vhp < 0.25 && shatter <= 4)
    {
        s = instance_create_layer(0, 0, "shadows", objbmobenshatter0)
        s.shatter = 4
        shatter = 5
    }
    if (vhp < 0.2 && shatter <= 5 && phase > 1)
    {
        s = instance_create_layer(0, 0, "shadows", objbmobenshatter0)
        s.shatter = 5
        shatter = 6
    }
}
if (state == 14)
{
    dir = 271
    with (objrm53)
    {
        sprite_index = sbmobenend0
        image_xscale = 4
        image_yscale = 4
    }
    with (objplayer)
    {
        caninput = false
        alpha = 0
        x = 3608
        y = 236
    }
    if (timer12 < 1)
    {
        with (objempty)
            instance_destroy()
        with (objplayerview)
            target = 86
        sound = 0
    }
    else if (timer12 < 2)
    {
        with (objrm53)
        {
            if (image_index < 2)
            {
                if (image_speed != 0.035)
                    image_speed = 0.035
            }
            else if (image_index < 9)
                image_speed = 0.15
            else if (image_index < 10)
                image_speed = 0.03
            else if (image_index < 15)
                image_speed = 0.15
            else if (image_index < 16)
                image_speed = 0.075
            else if (image_index <= 20)
                image_speed = 0.15
            else
            {
                image_index = 20.5
                image_speed = 0
                other.timer12 = 2
                evpii = 0
            }
            if (other.sound == 0 && image_index > 1)
            {
                other.sound = 1
                scrsound(snrubble0, 50, 1, 1)
            }
            if (other.sound == 1 && image_index > 6)
            {
                other.sound = 2
                scrsound(snrubble1, 50, 1, 1)
            }
        }
        with (objplayerview)
            target = -4
        var ox = objrm53.x
        var oy = objrm53.y
        if (splash14 == 0 && objrm53.image_index > 2)
        {
            splash14 = 1
            scrsplash((ox + 64), (oy - 28), ssplash0, 0)
            objplayerview.targetx = ox + 64
            objplayerview.targety = oy - 28
        }
        if (splash14 == 1 && objrm53.image_index > 6)
        {
            splash14 = 2
            scrsplash((ox + 64), (oy - 28), ssplash0, 0)
            objplayerview.targetx = ox + 64
            objplayerview.targety = oy - 28
        }
        if (splash14 == 2 && objrm53.image_index > 8)
        {
            splash14 = 3
            scrsplash((ox - 8), (oy - 28), ssplash0, 0)
            scrsound(snbmobenssplash0, 9, 1, 1)
        }
        if (splash14 == 3 && objrm53.image_index > 11)
        {
            splash14 = 4
            scrsplash((ox + 60), (oy - 8), ssplash0, 0)
            objplayerview.targetx = ox + 60
            objplayerview.targety = oy - 8
        }
        if (splash14 == 4 && objrm53.image_index > 15)
        {
            splash14 = 5
            scrsplash((ox + 64), (oy + 52), ssplash0, 0)
            objplayerview.targetx = ox + 64
            objplayerview.targety = oy + 52
            scrsound(snbmobenssplash0, 9, 0.5, 1)
        }
        if (splash14 == 5 && objrm53.image_index > 18)
        {
            splash14 = 6
            scrsplash((ox + 60), (oy + 88), ssplash0, 0)
            objplayerview.targetx = ox + 60
            objplayerview.targety = oy + 88
        }
        if (splash14 == 6 && objrm53.image_index > 20)
        {
            splash14 = 7
            scrsplash((ox + 64), (oy + 108), ssplash0, 0)
            objplayerview.targetx = ox + 64
            objplayerview.targety = oy + 108
        }
        if (splash14 == 6 && objrm53.image_index > 20)
        {
            splash14 = 7
            scrsplash((ox + 64), (oy + 108), ssplash0, 0)
            objplayerview.targetx = ox + 64
            objplayerview.targety = oy + 108
        }
    }
    else if (timer12 < 3)
    {
        if (evpii < 3)
        {
            evpii += 0.2
            sound = 0
        }
        else if (evpii < 4)
            evpii += 0.025
        else if (evpii < 6)
            evpii += 0.015
        else
        {
            evpii = 6.5
            other.timer12 = 3
        }
        if (evpii < 4)
        {
            with (objempty)
                instance_destroy()
        }
        else if (evpii < 6)
        {
            if (!instance_exists(objempty))
            {
                var vs = instance_create_depth(x, y, layer_get_depth("invisible"), objempty)
                vs.sprite_index = sbmobenend1
                vs.image_index = 0
                vs.image_speed = 0
                vs.image_xscale = 4
                vs.image_yscale = 4
                objplayerview.shaket = 10
                scrsplash(x, y, smobsm2splash, 0)
            }
            with (objempty)
            {
                if (image_index < 2.5)
                    image_speed = 0.5
                else
                {
                    image_index = 2.5
                    image_speed = 0
                }
            }
        }
        else
        {
            with (objempty)
            {
                if (image_index < 3)
                {
                    image_index = 3.5
                    objplayerview.shaket = 12
                    other.evsy = 0
                    scrsplash(x, y, smobsm2splash, 0)
                }
                image_speed = 0
            }
        }
        if (sound == 0 && evpii > 4)
        {
            sound = 1
            scrsound(snstab0, 50, 1, 1)
            scrsound(snglass0, 10, 1, 1)
        }
        if (sound == 1 && evpii > 5)
        {
            sound = 2
            scrsound(snstab1, 50, 1, 1)
        }
        if (sound == 2 && evpii > 6)
        {
            sound = 3
            scrsound(snstab0, 50, 1, 0.9)
            scrsound(snglass1, 10, 1, 1)
        }
    }
    else if (timer12 < 4)
    {
        timer12 += 0.016666666666666666
        sound = 0
    }
    else if (timer12 < 5)
    {
        if (fpy > 1500)
            fpy = 1500
        timer12 += 0.005555555555555556
        if (sound == 0)
        {
            sound = 1
            scrsound(snwoosh0, 50, 1, 1)
        }
    }
    else
    {
        with (objplayer)
            stage = 8.18
    }
    if (timer12 < 2)
    {
        sprite_index = sbmobenend02
        image_speed = 0.05
        if (image_index >= (2 - image_speed))
            image_index = 0
    }
    else if (floor(evpii) == 4)
        image_index = 2.5
    else if (floor(evpii) == 5)
        image_index = 3.5
    else
        image_index = 4.5
    fpt += 0.02
    if (fpt == 1)
    {
        var vo = instance_create_layer(4096, 1280, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt00
    }
    else if (fpt == 1.7)
    {
        vo = instance_create_layer(3392, 896, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt00
    }
    else if (fpt == 2)
    {
        vo = instance_create_layer(3200, 1024, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt10
    }
    else if (fpt == 2.6)
    {
        vo = instance_create_layer(3840, 1536, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt10
    }
    else if (fpt == 3)
    {
        vo = instance_create_layer(4032, 1088, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt20
    }
    else if (fpt == 3.2)
    {
        vo = instance_create_layer(3456, 832, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt10
    }
    else if (fpt == 4)
    {
        vo = instance_create_layer(3904, 896, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt20
    }
    else if (fpt == 4.1)
    {
        vo = instance_create_layer(3392, 1024, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt20
    }
    else if (fpt == 4.4)
    {
        vo = instance_create_layer(3136, 1408, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt20
    }
    else if (fpt == 5)
    {
        vo = instance_create_layer(3904, 1152, "instances", objbmobenfpt)
        vo.sprite_index = sbmobenfpt20
    }
}
else
    timer12 = 0
