var accl = 0.5
if (spd < 32 && pcatch == 0)
    spd += accl
else if (timer > 0 && (!(place_meeting(x, y, objbmobsm))))
{
    deccl = 1
    if (spd > 20)
    {
        if (splash < 2)
            splash += 1
        else
        {
            scrsplash(x, y, sbmobsmsplash1, 0)
            splash = 0
        }
    }
    if (pcatch == 0)
    {
        timer -= spd
        if (place_meeting(x, y, objplayer) && objplayer.iframe <= 0 && objplayer.alpha == 1)
        {
            pcatch = 1
            with (objplayer)
            {
                alpha = 0
                state = -1
                caninput = false
                x += lengthdir_x(32, scrdir(self, objbmobsm))
                y += lengthdir_y(32, scrdir(self, objbmobsm))
            }
        }
    }
    else if (pcatch < 10)
    {
        pcatch += 1
        spd = 0
    }
    else if (pcatch == 10)
    {
        pcatch += 1
        scrsplash(x, y, sbmobsmsplash1, 0)
    }
    else if (pcatch < 20)
    {
        pcatch += 1
        spd = 0
    }
    else
    {
        if (spd == 0)
            spd = 16
        else if (spd < 32)
            spd += (accl * 2)
        timer -= spd
        with (objplayer)
        {
            alpha = 0
            state = -1
            caninput = false
            x += lengthdir_x(32, scrdir(self, objbmobsm))
            y += lengthdir_y(32, scrdir(self, objbmobsm))
        }
    }
}
else
{
    objbmobsm.tongue = 2
    if (pcatch != 0)
    {
        objplayer.x = objbmobsm.x
        objplayer.y = objbmobsm.y
    }
    instance_destroy()
}
x += lengthdir_x((spd / deccl), dir)
y += lengthdir_y((spd / deccl), dir)
