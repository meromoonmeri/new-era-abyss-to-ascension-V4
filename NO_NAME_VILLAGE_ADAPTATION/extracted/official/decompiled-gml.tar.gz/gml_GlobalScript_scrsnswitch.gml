function scrsnswitch(argument0, argument1, argument2) //gml_Script_scrsnswitch
{
    var mdelay = 500
    var list0 = ds_list_find_value(argument0, 0)
    if (list0 == argument1)
    {
        if (objaudio.spause > 0)
        {
            if (audio_sound_get_gain(argument1) >= 1)
                scrsoundgain(argument1, 10, 0, objaudio.mdelay)
        }
        else if (!audio_is_playing(argument1))
            scrsoundgain(argument1, 10, argument2, mdelay)
        if (ds_list_size(argument0) > 1)
        {
            for (var dlist = 1; dlist < ds_list_size(argument0); dlist++)
            {
                var dsound = ds_list_find_value(argument0, dlist)
                if (audio_sound_get_gain(dsound) <= 0)
                {
                    audio_stop_sound(dsound)
                    ds_list_delete(argument0, dlist)
                }
            }
        }
        return argument1;
    }
    else if (ds_list_size(argument0) > 1)
    {
        var list1 = ds_list_find_value(argument0, 1)
        scrsoundgain(list1, 10, 0, mdelay)
        return list0;
    }
}

