function scrsnswitchm(argument0, argument1) //gml_Script_scrsnswitchm
{
    var mdelay = objaudio.mdelay
    var listsize = ds_list_size(argument0)
    var list0 = ds_list_find_value(argument0, 0)
    var list1 = ds_list_find_value(argument0, 1)
    var m = list0
    var mm = list1
    if (scrlocation(room) == 3)
    {
        m = list1
        mm = list0
    }
    var sound0 = audio_get_name(list0)
    var sound1 = audio_get_name(list1)
    for (var dlist = listsize - 1; dlist >= 0; dlist--)
    {
        var dmusic = ds_list_find_value(argument0, dlist)
        if (dmusic == -4)
        {
        }
        else if (dlist == 0)
        {
            if (objaudio.mpause > 0)
            {
                var am = audio_sound_get_gain(m)
                var amm = audio_sound_get_gain(mm)
                if (audio_sound_get_gain(m) >= global.music)
                {
                    scrmusic(mm, 20, 0, 1, objaudio.mdelay)
                    scrmusic(m, 20, 0, 1, objaudio.mdelay)
                }
            }
            else if ((!audio_is_playing(m)) || global.mcheck != global.music)
            {
                if audio_is_playing(mm)
                {
                    if audio_sound_get_gain(mm)
                        audio_stop_sound(mm)
                }
                scrmusic(mm, 20, 0, 1, mdelay)
                scrmusic(m, 20, argument1, 1, mdelay)
                global.mcheck = global.music
            }
            else if (audio_sound_get_gain(m) <= 0)
            {
                scrmusic(mm, 20, 0, 1, mdelay)
                scrmusic(m, 20, argument1, 1, mdelay)
            }
        }
        else if (dmusic != m && dmusic != mm)
        {
            if (audio_sound_get_gain(dmusic) >= global.music)
                scrmusic(dmusic, 20, 0, 1, mdelay)
            else
            {
                audio_stop_sound(dmusic)
                ds_list_delete(argument0, dlist)
            }
        }
    }
}

