if (sprite_index != sbmoben1e0)
{
    if (facing == 1)
        draw_sprite_part_ext(sprite_index, image_index, 0, 0, sprite_width, (sprite_yoffset - 12), (x - sprite_xoffset), (y - sprite_yoffset + 12), 1, 1, c_white, alpha)
    else
        draw_sprite_part_ext(sprite_index, image_index, 0, 0, sprite_width, (sprite_yoffset - 12), (x - sprite_xoffset + sprite_width), (y - sprite_yoffset + 12), -1, 1, c_white, alpha)
}
else
    draw_sprite_ext(sprite_index, image_index, x, y, facing, 1, 0, c_white, alpha)
if (flash > 0)
{
    shader_set(shflash)
    draw_sprite_ext(sprite_index, image_index, x, (y + ford * 12), facing, 1, 0, c_white, flash)
    shader_reset()
}
if (state == 7)
    draw_sprite(sbmoben1e1, splat, x, y)
if (calpha0 > 0)
    draw_sprite_ext(sbmoben1e2, 0, x, y, 4, 4, 0, -1, calpha0)
if (calpha1 > 0)
    draw_sprite_ext(sbmoben1e2, 1, x, y, 4, 4, 0, -1, calpha1)
if (calpha2 > 0)
    draw_sprite_ext(sbmoben1e2, 2, x, y, 4, 4, 0, -1, calpha2)
