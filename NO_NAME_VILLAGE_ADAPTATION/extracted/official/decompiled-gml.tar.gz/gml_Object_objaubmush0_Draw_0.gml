draw_sprite_ext(sprite_index, image_index, x, y, (image_xscale * 4), (image_yscale * 4), 0, -1, 1)
