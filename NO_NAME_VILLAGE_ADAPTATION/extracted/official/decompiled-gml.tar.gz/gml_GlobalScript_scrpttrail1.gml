function scrpttrail1(argument0, argument1, argument2, argument3, argument4, argument5, argument6, argument7) //gml_Script_scrpttrail1
{
    var scrpt1 = part_type_create()
    var scrpt2 = part_type_create()
    var scrpt3 = part_type_create()
    var rlife = irandom_range(argument5, argument5)
    if (!variable_global_exists("pstrail1"))
        global.pstrail1 = -4
    else if (global.pstrail1 == -4)
    {
        global.pstrail1 = part_system_create()
        part_system_depth(global.pstrail1, (layer_get_depth("shadows") + 1))
        if layer_exists("farm0")
            part_system_depth(global.pstrail1, (layer_get_depth("farm0") + 1))
    }
    part_type_sprite(scrpt1, argument2, 0, 0, 1)
    part_type_scale(scrpt1, argument6, argument6)
    part_type_alpha3(scrpt1, argument7, argument7, 0)
    part_type_life(scrpt1, (rlife + 120), (rlife + 120))
    part_particles_create(global.pstrail1, argument0, argument1, scrpt1, 1)
    if (!variable_global_exists("pstrail2"))
        global.pstrail2 = -4
    else if (global.pstrail2 == -4)
    {
        global.pstrail2 = part_system_create()
        part_system_depth(global.pstrail2, (layer_get_depth("shadows") + 2))
        if layer_exists("farm0")
            part_system_depth(global.pstrail2, (layer_get_depth("farm0") + 1))
    }
    part_type_sprite(scrpt2, argument3, 0, 0, 1)
    part_type_scale(scrpt2, argument6, argument6)
    part_type_alpha3(scrpt2, argument7, argument7, 0)
    part_type_life(scrpt2, rlife, rlife)
    part_particles_create(global.pstrail2, argument0, argument1, scrpt2, 1)
    if (!variable_global_exists("pstrail3"))
        global.pstrail3 = -4
    else if (global.pstrail3 == -4)
    {
        global.pstrail3 = part_system_create()
        part_system_depth(global.pstrail3, (layer_get_depth("shadows") + 3))
        if layer_exists("farm0")
            part_system_depth(global.pstrail3, (layer_get_depth("farm0") + 1))
    }
    part_type_sprite(scrpt3, argument4, 0, 0, 1)
    part_type_scale(scrpt3, argument6, argument6)
    part_type_alpha3(scrpt3, argument7, argument7, 0)
    part_type_life(scrpt3, rlife, rlife)
    part_particles_create(global.pstrail3, argument0, argument1, scrpt3, 1)
}

