function scrplayerkd(argument0, argument1, argument2) //gml_Script_scrplayerkd
{
    objplayer.hp -= argument1
    objplayer.state = 6
    objplayer.dir = argument0
    objplayer.caninput = false
    objplayer.image_index = 0
    objplayerview.shaket = argument2
}

