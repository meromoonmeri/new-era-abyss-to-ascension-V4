function scrptford(argument0, argument1, argument2, argument3, argument4) //gml_Script_scrptford
{
    var rford = random(1)
    if (rford < 0.4)
    {
        var scrpt1 = part_type_create()
        var scrpt2 = part_type_create()
        if (!layer_exists("watershadows"))
            layer_create((layer_get_depth("ground") + 200), "watershadows")
        if (!variable_global_exists("psford1"))
        {
            global.psford1 = part_system_create()
            part_system_depth(global.psford1, layer_get_depth("watershadows"))
        }
        part_type_sprite(scrpt1, argument2, 0, 0, 1)
        part_type_size(scrpt1, 1, 1, 0.03, 0)
        part_type_alpha2(scrpt1, 0.2, 0)
        part_type_life(scrpt1, argument4, argument4)
        part_particles_create(global.psford1, argument0, argument1, scrpt1, 1)
        if (!variable_global_exists("psford2"))
        {
            global.psford2 = part_system_create()
            part_system_depth(global.psford2, layer_get_depth("watershadows"))
        }
        part_type_sprite(scrpt2, argument3, 0, 0, 1)
        part_type_size(scrpt2, 1, 1, 0.04, 0)
        part_type_alpha2(scrpt2, 0.2, 0)
        part_type_life(scrpt2, argument4, argument4)
        part_particles_create(global.psford2, argument0, argument1, scrpt2, 1)
    }
}

