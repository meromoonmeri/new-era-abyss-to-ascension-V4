depth = layer_get_depth("shadows")
