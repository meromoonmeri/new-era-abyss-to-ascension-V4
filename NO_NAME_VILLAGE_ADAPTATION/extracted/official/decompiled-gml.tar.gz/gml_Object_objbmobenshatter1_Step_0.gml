z += ((zmax - z) / 180)
