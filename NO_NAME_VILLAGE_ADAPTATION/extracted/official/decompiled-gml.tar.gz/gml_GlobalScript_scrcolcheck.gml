function scrcolcheck() //gml_Script_scrcolcheck
{
    var scrlendirx = lengthdir_x(mspd, mdir)
    var scrlendiry = lengthdir_y(mspd, mdir)
    if (fl == 0)
    {
        colcheckx = (place_meeting((x + scrlendirx), y, objcol) || place_meeting((x + scrlendirx), y, objb))
        colcheckxnot = ((!(place_meeting((x + sign(scrlendirx)), y, objcol))) && (!(place_meeting((x + sign(scrlendirx)), y, objb))))
        colchecky = (place_meeting(x, (y + scrlendiry), objcol) || place_meeting(x, (y + scrlendiry), objb))
        colcheckynot = ((!(place_meeting(x, (y + sign(scrlendiry)), objcol))) && (!(place_meeting(x, (y + sign(scrlendiry)), objb))))
    }
    else
    {
        colcheckx = (place_meeting((x + scrlendirx), y, objcol) || place_meeting((x + scrlendirx), y, objy))
        colcheckxnot = ((!(place_meeting((x + scrlendirx), y, objcol))) && (!(place_meeting((x + scrlendirx), y, objy))))
        colchecky = (place_meeting(x, (y + scrlendiry), objcol) || place_meeting(x, (y + scrlendiry), objy))
        colcheckynot = ((!(place_meeting(x, (y + sign(scrlendiry)), objcol))) && (!(place_meeting(x, (y + sign(scrlendiry)), objy))))
    }
}

