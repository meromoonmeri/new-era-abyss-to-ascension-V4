if (shaket > 0 && prevy > 448)
{
    if (ca < 1)
    {
        gpu_set_colorwriteenable(1, 0, 0, 1)
        draw_sprite_ext(sprite_index, image_index, (prevx + shakex1), (prevy + shakey1 + changey), 1, 1, 0, c_white, alpha)
        gpu_set_colorwriteenable(1, 1, 1, 1)
    }
    if (ca < 2)
    {
        gpu_set_colorwriteenable(0, 1, 0, 1)
        draw_sprite_ext(sprite_index, image_index, (prevx + shakex2), (prevy + shakey2 + changey), 1, 1, 0, c_white, alpha)
        gpu_set_colorwriteenable(1, 1, 1, 1)
    }
    if (ca < 3)
    {
        gpu_set_colorwriteenable(0, 0, 1, 1)
        draw_sprite_ext(sprite_index, image_index, (prevx + shakex3), (prevy + shakey3 + changey), 1, 1, 0, c_white, alpha)
        gpu_set_colorwriteenable(1, 1, 1, 1)
    }
    if (ca < 3)
        ca += 0.3
    else
        ca = 0
}
if (global.graphics > 0)
{
    if (!surface_exists(overlay))
        overlay = surface_create(room_width, room_height)
    else
    {
        surface_set_target(overlay)
        draw_clear_alpha(c_black, 0)
        event_inherited()
        gpu_set_colorwriteenable(1, 1, 1, 0)
        for (var bgx = 0; bgx < 5; bgx += 1)
        {
            for (var bgy = 0; bgy < 5; bgy += 1)
                draw_sprite_ext(sbmobaubg, 0, (bgx * 256 * 4), (bgy * 256 * 4 + changey), 4, 4, 0, -1, 0.5)
        }
        gpu_set_colorwriteenable(1, 1, 1, 1)
        surface_reset_target()
        draw_surface(overlay, 0, 0)
    }
}
else
    event_inherited()
draw_sprite_ext(sprite_index, image_index, x, (y + changey), facing, 1, 0, c_black, balpha)
