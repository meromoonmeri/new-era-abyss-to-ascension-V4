event_inherited()
depth = (-y)
start = 0
watershad = 387
shadshad = 868
wnsprite = 370
wnwatershad = 1065
wnshadshad = 1684
