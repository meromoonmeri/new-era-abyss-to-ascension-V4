if sprite_exists(sprite_index)
    draw_sprite_ext(sprite_index, 0, x, y, (image_xscale * scale), (image_yscale * scale), 0, -1, image_alpha)
