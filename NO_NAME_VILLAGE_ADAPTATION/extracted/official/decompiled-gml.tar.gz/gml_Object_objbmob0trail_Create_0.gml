depth = 0
image_speed = 0.01
timer = 0
alpha = 1
