event_inherited()
z = 0
dir1 = 0
run = false
timer1 = 0
timer2 = 0
