if (!instance_exists(objbmobauunder))
    instance_create_layer(x, y, "shadows", objbmobauunder)
if place_meeting(x, y, objplayer)
{
    with (objplayer)
        scrmovcol(clamp(spd, 4, 10), scrdir(other, self))
}
event_inherited()
if (hp > (maxhp * 0.66))
    aggro = 0
else if (hp > (maxhp * 0.33))
    aggro = 1
else
    aggro = 2
if (hp > 0)
{
    if (hit == 1)
    {
        hit = 2
        flash = 1
        objplayerview.shaket = 8
    }
    if (rthit > 1)
    {
        spd = 0
        rthit = 0
        flash = 1
        objplayerview.shaket = 8
        hp -= 3
    }
}
else if (state != 9)
{
    if (flash == 0)
    {
        hit = 0
        state = 7
        image_index = 0
    }
}
if (state == -1)
{
    image_speed = 0.1 * spd
    if (dir >= 22.5 && dir < 67.5)
    {
        sprite_index = sbmobaum3
        mdir = 45
        undersprite = 1888
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        sprite_index = sbmobaum4
        mdir = 90
        undersprite = 2743
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        sprite_index = sbmobaum3
        mdir = 135
        undersprite = 1888
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        sprite_index = sbmobaum2
        mdir = 180
        undersprite = 800
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        sprite_index = sbmobaum1
        mdir = 225
        undersprite = 795
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        sprite_index = sbmobaum0
        mdir = 270
        undersprite = 1882
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        sprite_index = sbmobaum1
        mdir = 315
        undersprite = 795
    }
    else
    {
        sprite_index = sbmobaum2
        mdir = 0
        undersprite = 800
    }
    if (eventt < 1)
    {
        dir = 270
        if (eventt < 0.5)
            eventt += 0.004166666666666667
        else
        {
            spd = clamp((spd + 0.2), 0, 1)
            objbmobauview.delay = 30
            y += lengthdir_y(spd, dir)
            if (y >= 320)
                eventt = 1
        }
    }
    else
    {
        spd = 0
        var eventpath = instance_create_layer(x, 640, "shadows", objbmobaupath)
        eventpath.turn = 1
        state = 1
    }
}
if (state == 1)
{
    image_speed = 0.1 * spd
    if (dir >= 22.5 && dir < 67.5)
    {
        sprite_index = sbmobaum3
        mdir = 45
        undersprite = 1888
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        sprite_index = sbmobaum4
        mdir = 90
        undersprite = 2743
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        sprite_index = sbmobaum3
        mdir = 135
        undersprite = 1888
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        sprite_index = sbmobaum2
        mdir = 180
        undersprite = 800
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        sprite_index = sbmobaum1
        mdir = 225
        undersprite = 795
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        sprite_index = sbmobaum0
        mdir = 270
        undersprite = 1882
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        sprite_index = sbmobaum1
        mdir = 315
        undersprite = 795
    }
    else
    {
        sprite_index = sbmobaum2
        mdir = 0
        undersprite = 800
    }
    if (!instance_exists(objbmobau0c))
    {
        if (dist1 < 128)
        {
            dist1 += spd
            spd = clamp((spd + 0.016666666666666666), 0, 1)
            scrmovcol(spd, mdir)
        }
        else
        {
            dist1 = 0
            state = 0
        }
    }
    else
    {
        if (alpha == 0)
            alpha = 1
        if (objbmobau0c.appear == 1)
            spd = clamp((spd - (1/120)), 0, 1)
        scrmovcol(spd, mdir)
    }
}
with (objbmobau0c)
{
    if (pcatch == true)
        objbmobau.state = 2
}
if (state == 2)
{
    objplayer.alpha = 0
    objplayer.caninput = false
    with (objfollower)
    {
        alpha = 0
        caninput = false
    }
    if (image_index < 1)
    {
        image_speed = 0.1
        if (dir >= 0 && dir < 180)
        {
            sprite_index = sbmobaue3
            mdir = 45
            undersprite = 2584
        }
        else
        {
            sprite_index = sbmobaue1
            mdir = 225
            undersprite = 1339
        }
    }
    else if (image_index < 2)
    {
        image_speed = 0
        if (!instance_exists(objbmobau0c))
            image_index = 2
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.2
        if (image_index > 4 && splash2 == 0)
        {
            splash2 = 1
            objplayerview.shaket = 12
            scrsplash(x, y, sbmobsmsplash0, 0)
        }
    }
    else
        image_speed = 0
}
if (state == 3)
{
    image_speed = 0.1 * spd
    if (dir >= 22.5 && dir < 67.5)
    {
        sprite_index = sbmobaum3
        mdir = 45
        undersprite = 1888
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        sprite_index = sbmobaum4
        mdir = 90
        undersprite = 2743
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        sprite_index = sbmobaum3
        mdir = 135
        undersprite = 1888
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        sprite_index = sbmobaum2
        mdir = 180
        undersprite = 800
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        sprite_index = sbmobaum1
        mdir = 225
        undersprite = 795
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        sprite_index = sbmobaum0
        mdir = 270
        undersprite = 1882
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        sprite_index = sbmobaum1
        mdir = 315
        undersprite = 795
    }
    else
    {
        sprite_index = sbmobaum2
        mdir = 0
        undersprite = 800
    }
    spd = clamp((spd - 0.016666666666666666), 0, 2)
    scrmovcol(spd, mdir)
    if (grabdelay < 30)
        grabdelay += 1
    else if (grabt < 6)
    {
        grabdelay = 0
        grabt += 1
        instance_create_layer((ptarget.x + (lengthdir_x(irandom_range(0, 640), irandom(360)))), (ptarget.y + (lengthdir_y(irandom_range(0, 640), irandom(360)))), "shadows", objbmobaugrab)
    }
    else
    {
        dist1 = 9999
        state = 1
    }
}
if (state == 4)
{
    if (image_index < 1)
        image_speed = 0.2
    else if (image_index < 2)
    {
        image_speed = 0.1
        if (splash4 == 0)
        {
            splash4 = 1
            scrsplash(x, y, ssplash0, 1)
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        if (splash4 == 1)
        {
            splash4 = 2
            scrsplash(x, y, ssplash0, 0)
        }
    }
    else
        state = 0
}
else
    splash4 = 0
if (state == 5)
{
}
if (state == 0)
{
    image_speed = 0.1 * spd
    if (dir >= 22.5 && dir < 67.5)
    {
        sprite_index = sbmobaum3
        mdir = 45
        undersprite = 1888
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        sprite_index = sbmobaum4
        mdir = 90
        undersprite = 2743
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        sprite_index = sbmobaum3
        mdir = 135
        undersprite = 1888
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        sprite_index = sbmobaum2
        mdir = 180
        undersprite = 800
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        sprite_index = sbmobaum1
        mdir = 225
        undersprite = 795
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        sprite_index = sbmobaum0
        mdir = 270
        undersprite = 1882
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        sprite_index = sbmobaum1
        mdir = 315
        undersprite = 795
    }
    else
    {
        sprite_index = sbmobaum2
        mdir = 0
        undersprite = 800
    }
    if (pattern < 0)
        pattern += (1/30)
    else if (pattern < 1)
        pattern = 1
    if (pattern == 1)
    {
        if (timer01 == 0)
        {
        }
    }
    else
        timer01 = 0
    if (pattern == 2)
    {
    }
    else
        timer02 = 0
    if (pattern == 3)
    {
    }
    else
        timer03 = 0
    if (delay0 < 30)
    {
        delay0 += 1
        spd = clamp((spd - 0.016666666666666666), 0, 2)
        scrmovcol(spd, mdir)
    }
    else
    {
        delay0 = 0
        if (pattern == 0)
        {
            pattern = 1
            instance_create_layer((x + (lengthdir_x(32, dir))), (y + (lengthdir_y(32, dir))), "shadows", objbmobaupath)
            state = 1
        }
        else if (pattern == 1)
        {
            var ptarget = objplayerview.player
            pattern = 0
            instance_create_layer(ptarget.x, ptarget.y, "shadows", objbmobaugrab)
            repeat (2)
            {
                instance_create_layer((ptarget.x + (lengthdir_x(irandom_range(32, 64), irandom(360)))), (ptarget.y + (lengthdir_x(irandom_range(32, 64), irandom(360)))), "shadows", objbmobaugrab)
                repeat (3)
                    instance_create_layer((ptarget.x + (lengthdir_x(irandom_range(64, 384), irandom(360)))), (ptarget.y + (lengthdir_x(irandom_range(32, 384), irandom(360)))), "shadows", objbmobaugrab)
            }
            dist1 = 128
            state = 1
        }
    }
}
