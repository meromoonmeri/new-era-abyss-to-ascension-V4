image_speed = 0
image_index = 0
creator = -4
timer = 600 + (irandom_range(-60, 60))
alpha = 1
particlecheck = 0
ptdepth = layer_get_depth("shadows")
if layer_exists("watershad")
    ptdepth = layer_get_depth("watershad")
depth = ptdepth + 4
if (!variable_global_exists("ptball0"))
{
    global.psball0 = part_system_create()
    part_system_depth(global.psball0, (ptdepth + 3))
}
if (!variable_global_exists("ptball1"))
{
    global.psball1 = part_system_create()
    part_system_depth(global.psball1, (ptdepth + 2))
}
pt0 = part_type_create()
part_type_sprite(pt0, 2753, 0, 0, 0)
part_type_alpha3(pt0, 1, 1, 0)
part_type_life(pt0, (timer + 30), (timer + 60))
part_particles_create(global.psball0, x, y, pt0, 1)
pt1 = part_type_create()
part_type_sprite(pt1, 818, 0, 0, 0)
part_type_alpha3(pt1, 1, 1, 0)
part_type_life(pt1, (timer + 60), (timer + 90))
part_particles_create(global.psball1, x, y, pt1, 1)
