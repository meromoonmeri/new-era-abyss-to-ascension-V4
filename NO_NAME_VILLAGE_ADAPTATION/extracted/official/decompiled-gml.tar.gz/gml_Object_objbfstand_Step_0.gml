if (startmap < 0)
{
    if (global.mapgrid[global.mapx][global.mapy] == 1)
        instance_destroy()
    if instance_place(x, y, objplayer)
        startmap = 0
}
else if (startmap < 1)
{
    objplayer.caninput = false
    startmap += (1/30)
}
else if (startmap < 2)
{
    if (checkx >= 0 && checky >= 0)
        objplayer.dir = point_direction(objplayer.x, objplayer.y, checkx, checky)
    else if (dir < 0)
        dir = objplayer.dir
    else
        objplayer.dir = dir
    startmap += (1/30)
}
else if (startmap < 3)
{
    if (checkx >= 0 && checky >= 0)
        scrview(checkx, checky, 0)
    else
        scrview((objplayer.x + (lengthdir_x(640, dir))), (objplayer.y + (lengthdir_y(640, dir))), 0)
    startmap += 0.006666666666666667
}
else if (startmap < 4)
{
    objplayerview.target = 100
    if (point_distance(objplayerview.x, objplayerview.y, objplayer.x, objplayer.y) < 12)
        startmap += 1
}
else if (startmap < 5)
{
    if (!instance_exists(objmenu))
    {
        with (objplayer)
            state = 0
        var menu = instance_create_depth(x, y, 0, objmenu)
        menu.caninput = false
        menu.page = 2
    }
    else
        startmap += 1
}
else if (startmap < 6)
{
    with (objmenu)
    {
        if (state >= 0)
        {
            state = 2
            drawmap = 0
            other.startmap += 1
        }
    }
}
else if (startmap < 7)
{
    with (objmenu)
    {
        if (state >= 0)
        {
            state = 2
            drawmap = 0
            other.startmap += 0.1
        }
    }
}
else if (startmap < 8)
{
    if (objmenu.drawmap >= 0)
    {
        if (objmenu.drawmap == 0)
        {
            global.mapgrid[objmenu.mapposx][objmenu.mapposy] = 1
            objmenu.drawmap = 1
        }
    }
    else
        startmap += 1
}
else if (startmap < 9)
    startmap += 0.016666666666666666
else
{
    with (objmenu)
        state = 5
    instance_destroy()
}
