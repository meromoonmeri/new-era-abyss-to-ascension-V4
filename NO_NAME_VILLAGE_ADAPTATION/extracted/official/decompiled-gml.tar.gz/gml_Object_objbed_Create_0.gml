event_inherited()
state = 0
timer1 = 0
timer2 = 0
timer3 = 0
pause1 = false
pause2 = false
box[0] = "Read"
box[1] = "Rest"
box[2] = "Save"
box[3] = "Load"
timer = 0
timertt = 0
state5 = 0
timer5 = 0
wakeupsave = false
b7t = 0
b71yt = 972
b71y = 972
b72yt = 972
b72y = 972
b73yt = 972
b73y = 972
b74yt = 972
b74y = 972
row7 = 0
select7 = -1
confirm7 = 0
if (!layer_exists("fxlayermenu"))
    layer_create(-999999, "fxlayermenu")
fxblur = fx_create("_filter_large_blur")
layer_set_fx("fxlayermenu", fxblur)
fx_set_parameter(fxblur, "g_Radius", 0)
blur = 0
