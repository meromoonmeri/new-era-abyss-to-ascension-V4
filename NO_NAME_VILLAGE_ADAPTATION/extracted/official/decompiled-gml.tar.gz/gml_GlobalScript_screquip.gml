function screquip(argument0) //gml_Script_screquip
{
    if (argument0 == 3 || argument0 == 11)
        return 2;
    else if (argument0 == 5)
        return 3;
    else if (argument0 == 26)
        return 4;
    else if (argument0 == 14)
        return 5;
    else if (argument0 == 27)
        return 6;
    else
        return 1;
}

