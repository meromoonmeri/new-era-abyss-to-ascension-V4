function scruseitem(argument0) //gml_Script_scruseitem
{
    with (objstage)
    {
        if (itemuse == argument0)
        {
            scrdeleteitem(argument0)
            itemuse = -4
            if instance_exists(objrm84)
                objrm84.timer += 1
            return 1;
        }
    }
}

