function scrsave(argument0, argument1) //gml_Script_scrsave
{
    ini_open("NoNameVillage.ini")
    var sav = "save" + string(argument1)
    if (argument0 == 0)
        ini_write_real(sav, "stage", objplayer.stage)
    else
        objplayer.stage = ini_read_real(sav, "stage", 0)
    if (argument0 == 0)
        ini_write_real(sav, "stagetimer", objstage.timer)
    else
        objplayer.stagetimer = ini_read_real(sav, "stagetimer", 0)
    if (argument0 == 0)
        ini_write_real(sav, "stagetimertt", objstage.timertt)
    else
        objplayer.stagetimertt = ini_read_real(sav, "stagetimertt", 0)
    if (argument0 == 0)
        ini_write_real(sav, "hours", global.hours)
    else
        global.hours = ini_read_real(sav, "hours", global.hours)
    if (argument0 == 0)
        ini_write_real(sav, "minutes", global.minutes)
    else
        global.minutes = ini_read_real(sav, "minutes", global.minutes)
    if (argument0 == 0)
        ini_write_real(sav, "seconds", global.seconds)
    else
        global.seconds = ini_read_real(sav, "seconds", global.seconds)
    if (argument0 == 0)
        ini_write_real(sav, "weaponlvl", objplayer.weaponlvl)
    else
        objplayer.weaponlvl = ini_read_real(sav, "weaponlvl", 0)
    if (argument0 == 0)
        ini_write_real(sav, "clotheslvl", objplayer.clotheslvl)
    else
    {
        objplayer.clotheslvl = ini_read_real(sav, "clotheslvl", 0)
        objplayer.maxhp = 3 + (ini_read_real(sav, "clotheslvl", 0))
        objplayer.hp = objplayer.maxhp
    }
    if (argument0 == 0)
        ini_write_real(sav, "heallvl", objplayer.heallvl)
    else
    {
        objplayer.heallvl = ini_read_real(sav, "heallvl", 0)
        if (objplayer.heallvl > 0)
            scrplaceitem(26)
        objplayer.healcount = objplayer.heallvl
    }
    if (argument0 == 0)
        ini_write_real(sav, "gbp", objplayer.gbp)
    else
        objplayer.gbp = ini_read_real(sav, "gbp", 0)
    if (argument0 == 0)
        ini_write_real(sav, "gbpe", objplayer.gbpe)
    else
        objplayer.gbpe = ini_read_real(sav, "gbpe", 0)
    if (argument0 == 0)
    {
        var str = ds_list_write(global.upgrades)
        ini_write_string(sav, "upgrades", str)
    }
    else
    {
        str = ini_read_string(sav, "upgrades", "")
        if (str != "")
            ds_list_read(global.upgrades, str)
    }
    if (argument0 == 0)
    {
        var str1 = ds_list_write(global.postrest)
        ini_write_string(sav, "postrest", str1)
    }
    else
    {
        str1 = ini_read_string(sav, "postrest", "")
        if (str1 != "")
            ds_list_read(global.postrest, str1)
    }
    for (var eq = 0; eq <= 2; eq++)
    {
        if (argument0 == 0)
            ini_write_real(sav, ("equip" + string(eq)), global.invitem[eq][0])
        else
            global.invitem[eq][0] = ini_read_real(sav, ("equip" + string(eq)), global.invitem[eq][0])
    }
    for (var ix = 0; ix <= 3; ix++)
    {
        for (var iy = 0; iy <= 2; iy++)
        {
            if (argument0 == 0)
                ini_write_real(sav, ("inventory" + string(ix) + "," + string(iy)), global.invitem[ix][iy])
            else
                global.invitem[ix][iy] = ini_read_real(sav, ("inventory" + string(ix) + "," + string(iy)), global.invitem[ix][iy])
        }
    }
    for (var i = 0; i <= 10; i++)
    {
        for (var j = 0; j <= 10; j++)
        {
            if (argument0 == 0)
                ini_write_real(sav, ("mapgrid" + string(i) + "," + string(j)), global.mapgrid[i][j])
            else
                global.mapgrid[i][j] = ini_read_real(sav, ("mapgrid" + string(i) + "," + string(j)), global.mapgrid[i][j])
        }
    }
    ini_close()
}

