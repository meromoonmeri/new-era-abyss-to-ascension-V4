event_inherited()
sprite = 2484
watershad = 1252
shadshad = 2040
