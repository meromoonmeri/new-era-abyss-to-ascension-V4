event_inherited()
depth = layer_get_depth("watershadows")
if ((charge % 1) == 0)
    scrsplash(x, y, smobau2splash, 3)
if (charge < 1)
{
    charge += (1/120)
    alpha = charge * 2 / 3
    if (worms < wormst)
        worms += 0.5
    else
    {
        worms = 0
        wormst = 1 - charge
        var rdist = random(256)
        var rdir = random(360)
        part_particles_create(part_system, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), part_type, 4)
    }
}
else if (charge < 2)
    charge = 2
else if (charge < 3)
{
    charge += 0.002777777777777778
    if (worms < wormst)
        worms += 0.5
    else
    {
        worms = 0
        wormst = (charge - 2) * 5
        rdist = random(256)
        rdir = random(360)
        part_particles_create(part_system, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), part_type, 1)
    }
}
else if (charge < 4)
{
    charge += (1/120)
    alpha = (1 - (charge - 3)) * 2 / 3
}
else
    instance_destroy()
