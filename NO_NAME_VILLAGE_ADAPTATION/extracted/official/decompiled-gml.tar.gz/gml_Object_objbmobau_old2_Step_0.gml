if (!instance_exists(objbmobauunder))
    instance_create_layer(x, y, "watershadows", objbmobauunder)
if (place_meeting(x, y, player) && state != 2)
{
    with (player)
        scrmovcol(clamp(spd, 4, 10), scrdir(other, self))
}
dip += dipspd
event_inherited()
if (hp > (maxhp * 0.66))
    aggro = 0
else if (hp > (maxhp * 0.33))
    aggro = 1
else
    aggro = 2
if (hp > 0)
{
    if (hit <= 0)
        hit = -3
    if (rthit == 1)
    {
        rthit = 0
        with (objregt)
            other.rthitdir = stickdir
    }
    if (rthit == 2)
    {
        rthit = 0
        objplayerview.shaket = 15
        scrsplash(x, y, smobau2splash, 1)
        shellhp = clamp((shellhp + 1), 0, 3)
        rtmove = 8
    }
    if (rtmove > 0)
    {
        rtmove += ((-rtmove) / 4)
        scrmovcol((-rtmove), rthitdir)
    }
}
else if (state != 5 && state != 6)
{
    with (objbmobau0c)
        instance_destroy()
    with (objbmobaupath)
        instance_destroy()
    with (objbmobaugrab)
        instance_destroy()
    if (flash == 0)
    {
        hit = 0
        image_index = 0
        state = 5
    }
}
if (shaket >= 0)
{
    if (shaket < 24)
        shaket += 4
    else
    {
        shaket = -1
        scrsplash(prevx, prevy, smobau2splash, 1)
        repeat (2)
        {
            var rdist = random_range(64, 192)
            var rdir = random(360)
            part_particles_create(ps, (prevx + (lengthdir_x(rdist, rdir))), (prevy + (lengthdir_y((rdist / 2), rdir))), wpt0, 1)
        }
        repeat (5)
        {
            rdist = random_range(64, 192)
            rdir = random(360)
            part_particles_create(ps, (prevx + (lengthdir_x(rdist, rdir))), (prevy + (lengthdir_y((rdist / 2), rdir))), wpt1, 1)
        }
    }
}
if (wptt > 0)
{
    wptt -= 1
    repeat (2)
    {
        rdist = random_range(64, 192)
        rdir = random(360)
        part_particles_create(ps, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), wpt0, 1)
    }
    repeat (5)
    {
        rdist = random_range(64, 192)
        rdir = random(360)
        part_particles_create(ps, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), wpt1, 1)
    }
}
else if (wptt == 0)
    wptt = -1
if (state == -1)
{
    dipspd = 0.1 * spd
    image_index = shellhp
    image_speed = 0
    if (dir >= 22.5 && dir < 67.5)
    {
        sprite_index = sbmobaum3
        mdir = 45
        undersprite = 1888
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        sprite_index = sbmobaum4
        mdir = 90
        undersprite = 2743
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        sprite_index = sbmobaum3
        mdir = 135
        undersprite = 1888
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        sprite_index = sbmobaum2
        mdir = 180
        undersprite = 800
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        sprite_index = sbmobaum1
        mdir = 225
        undersprite = 795
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        sprite_index = sbmobaum0
        mdir = 270
        undersprite = 1882
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        sprite_index = sbmobaum1
        mdir = 315
        undersprite = 795
    }
    else
    {
        sprite_index = sbmobaum2
        mdir = 0
        undersprite = 800
    }
    if (dip >= (4 - image_speed))
        dip = 0
    else if (dip >= 1 && dip < 2)
        changey += ((8 - changey) / 4)
    else
        changey += ((-changey) / 12)
    if (eventt < 1)
    {
        dir = 270
        if (eventt < 0.5)
            eventt += 0.004166666666666667
        else
        {
            spd = clamp((spd + 0.2), 0, 0.9)
            objbmobauview.delay = 30
            y += lengthdir_y(spd, dir)
            if (y >= 224)
                eventt = 1
        }
    }
    else
    {
        spd = 0
        var eventpath = instance_create_layer(x, 640, "shadows", objbmobaupath)
        eventpath.turn = 1
        state = 1
    }
}
if (state == 1)
{
    dipspd = 0.1 * spd
    image_index = shellhp
    image_speed = 0
    scrspr8dir(dir, sbmobaushell0, sbmobaushell1, sbmobaushell2, sbmobaushell3, sbmobaushell4)
    if (dir >= 22.5 && dir < 67.5)
    {
        mdir = 45
        undersprite = 1888
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        mdir = 90
        undersprite = 2743
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        mdir = 135
        undersprite = 1888
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        mdir = 180
        undersprite = 800
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        mdir = 225
        undersprite = 795
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        mdir = 270
        undersprite = 1882
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        mdir = 315
        undersprite = 795
    }
    else
    {
        mdir = 0
        undersprite = 800
    }
    if (dip >= (4 - dipspd))
        dip = 0
    else if (dip >= 1 && dip < 2)
        changey += ((8 - changey) / 4)
    else
        changey += ((-changey) / 12)
    if (!instance_exists(objbmobau0c))
    {
        if (dist1 < 128)
        {
            dist1 += spd
            spd = clamp((spd + 0.016666666666666666), 0, 1)
            scrmovcol(spd, mdir)
        }
        else if (!instance_exists(objbmobaupath))
            state = 0
    }
    else
    {
        if (alpha == 0)
        {
            alpha = 1
            shellhp = 0
        }
        if (objbmobau0c.appear == 1)
            spd = clamp((spd - (1/120)), 0, 1)
        scrmovcol(spd, mdir)
    }
}
with (objbmobau0c)
{
    if (pcatch == true)
        objbmobau.state = 2
}
if (state == 2)
{
    with (objplayer)
        caninput = false
    with (objfollower)
        caninput = false
    if (image_index < 1)
    {
        objplayer.alpha = 0
        with (objfollower)
            alpha = 0
        image_speed = 0.1
        if (dir >= 0 && dir < 90)
        {
            sprite_index = sbmobaue3
            mdir = 45
            undersprite = 2584
        }
        else if (dir >= 90 && dir < 180)
        {
            sprite_index = sbmobaue3
            mdir = 135
            undersprite = 2584
        }
        else if (dir >= 180 && dir < 270)
        {
            sprite_index = sbmobaue1
            mdir = 225
            undersprite = 1339
        }
        else
        {
            sprite_index = sbmobaue1
            mdir = 315
            undersprite = 1339
        }
    }
    else if (image_index < 2)
    {
        objplayer.alpha = 0
        with (objfollower)
            alpha = 0
        image_speed = 0
        if (!instance_exists(objbmobau0c))
        {
            image_index = 2
            var ldx = x + (lengthdir_x(-256, mdir))
            var ldy = y + (lengthdir_y(-256, mdir))
            scrnpcspawn((ldx + (lengthdir_x(32, 30))), (ldy + (lengthdir_y(32, 30))), objplayer)
            scrnpcspawn((ldx + (lengthdir_x(32, 210))), (ldy + (lengthdir_y(32, 210))), objfollower)
            with (objplayer)
            {
                alpha = 1
                state = -1
                sprite_index = spkd1
                image_index = 4.5
                image_speed = 0
                scrsplash(x, y, ssplash0, 0)
            }
            with (objfollower)
            {
                alpha = 1
                state = -1
                sprite_index = sr023
                image_index = 0
                image_speed = 0
                scrsplash(x, y, ssplash0, 0)
            }
        }
    }
    else if (image_index < (image_number - 0.5))
    {
        image_speed = 0.2
        if (image_index < 5)
        {
            with (objplayer)
                scrmovcol(((other.image_index - 2) / 3 * 8), scrdir(self, other))
            with (objfollower)
                scrmovcol(((other.image_index - 2) / 3 * 8), scrdir(self, other))
        }
        else if (splash2 == 0)
        {
            splash2 = 1
            objplayerview.shaket = 12
            scrsplash(x, y, sbmobsmsplash0, 0)
            with (objplayer)
            {
                alpha = 0
                objplayer.hp -= 1
            }
            with (objfollower)
                alpha = 0
            wptt = 3
        }
    }
    else
    {
        image_speed = 0
        if (timer2 < 1)
            timer2 += (1/30)
        else if (timer2 < 2)
        {
            timer2 += (1/30)
            changey += ((-changey) / 16)
        }
        else if (timer2 < 3)
        {
            changey = -8
            objplayerview.shaket = 8
            objplayer.hp -= 1
            wptt = 3
            if (objplayer.hp > 0)
                timer2 = 1
            else
                timer2 = 3
        }
    }
}
if (state == 3)
{
    dipspd = 0.1 * spd
    image_index = shellhp
    image_speed = 0
    scrspr8dir(dir, sbmobaushell0, sbmobaushell1, sbmobaushell2, sbmobaushell3, sbmobaushell4)
    if (dir >= 22.5 && dir < 67.5)
    {
        mdir = 45
        undersprite = 1888
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        mdir = 90
        undersprite = 2743
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        mdir = 135
        undersprite = 1888
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        mdir = 180
        undersprite = 800
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        mdir = 225
        undersprite = 795
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        mdir = 270
        undersprite = 1882
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        mdir = 315
        undersprite = 795
    }
    else
    {
        mdir = 0
        undersprite = 800
    }
    if (dip >= (4 - dipspd))
        dip = 0
    else if (dip >= 1 && dip < 2)
        changey += ((8 - changey) / 4)
    else
        changey += ((-changey) / 12)
    spd = clamp((spd - 0.016666666666666666), 0, 2)
    scrmovcol(spd, mdir)
    if (grabdelay < 30)
        grabdelay += 1
    else if (grabt < 3)
    {
        grabdelay = 0
        var gdir = (scrdir(self, player)) - 45 + 45 * grabt
        var objgrab = instance_create_layer((x + (lengthdir_x(192, gdir))), (y + (lengthdir_y(192, gdir))), "instances", objbmobaugrab)
        objgrab.dir = gdir
        scrsplash(x, y, smobau2splash, 1)
        objplayerview.shaket = 6
        grabt += 1
    }
    else
        state = 0
}
else
    grabt = 0
if (state == 4)
{
    dipspd = 0.1 * spd
    image_index = shellhp
    image_speed = 0
    scrspr8dir(dir, sbmobaushell0, sbmobaushell1, sbmobaushell2, sbmobaushell3, sbmobaushell4)
    if (dir >= 22.5 && dir < 67.5)
    {
        mdir = 45
        undersprite = 1888
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        mdir = 90
        undersprite = 2743
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        mdir = 135
        undersprite = 1888
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        mdir = 180
        undersprite = 800
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        mdir = 225
        undersprite = 795
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        mdir = 270
        undersprite = 1882
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        mdir = 315
        undersprite = 795
    }
    else
    {
        mdir = 0
        undersprite = 800
    }
    if (dip >= (4 - dipspd))
        dip = 0
    else if (dip >= 1 && dip < 2)
        changey += ((8 - changey) / 4)
    else
        changey += ((-changey) / 12)
    if (dip < 1)
        image_speed = 0.2
    else if (dip < 2)
    {
        dipspd = 0.05
        if (splash4 == 0)
        {
            splash4 = 1
            scrsplash(x, y, smobau2splash, 1)
        }
        else if ((splash4 == 1 && dip > 1.25) || (splash4 == 2 && dip > 1.5) || (splash4 == 3 && dip > 1.75))
        {
            splash4 += 1
            rdir = irandom(360)
            rdist = irandom(512)
            instance_create_layer((x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist * 2 / 3), rdir))), "bmobausink", objbmobausink)
        }
    }
    else if (dip < (3 - dipspd))
    {
        dipspd = 0.05
        if (splash4 != 0)
        {
            splash4 = 0
            scrsplash(x, y, smobau2splash, 0)
            repeat (3)
            {
                rdir = irandom(360)
                rdist = irandom(512)
                instance_create_layer((x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist * 2 / 3), rdir))), "bmobausink", objbmobausink)
            }
        }
    }
    else
        state = 0
}
else
    splash4 = 0
if (state == 5)
{
    if (dir >= 0 && dir < 90)
    {
        sprite_index = sbmobaud1
        mdir = 45
        undersprite = 1866
    }
    else if (dir >= 90 && dir < 180)
    {
        sprite_index = sbmobaud1
        mdir = 135
        undersprite = 1866
    }
    else if (dir >= 180 && dir < 270)
    {
        sprite_index = sbmobaud1
        mdir = 225
        undersprite = 1866
    }
    else
    {
        sprite_index = sbmobaud1
        mdir = 315
        undersprite = 1866
    }
    if (image_index < 2)
        image_speed = 0.2
    else if (image_index < 4)
        image_speed = 0.1
    else if (image_index < 5)
    {
        image_speed = 0.2
        if (timer5 < 0)
            timer5 = 0
    }
    else
    {
        image_index = 5.4
        if (image_speed != 0)
        {
            image_speed = 0
            objplayerview.shaket = 12
            scrsplash((x - 16), (y + 64), smobau2splash, 0)
            wptt = 3
        }
    }
    if (timer5 >= 0 && timer5 < 400)
    {
        timer5 += 1
        if (worms < wormst)
            worms += 1
        else
        {
            worms = 0
            wormst = timer5 / 100
            repeat (3)
            {
                rdist = timer5 * 5 - irandom(192) - irandom(192) - irandom(192) - irandom(192)
                rdir = random(360)
                part_particles_create(ps, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), pt, 1)
            }
            repeat (15)
            {
                var rdist2 = timer5 * 5 - irandom(192) - irandom(192) - irandom(192) - irandom(192)
                var rdir2 = random(360)
                part_particles_create(ps2, (x + (lengthdir_x(rdist2, rdir2))), (y + (lengthdir_y((rdist2 / 2), rdir2))), pt2, 1)
            }
        }
    }
}
if (state == 6)
{
    if (dir >= 0 && dir < 90)
    {
        sprite_index = sbmobauex1
        mdir = 45
        undersprite = 1686
    }
    else if (dir >= 90 && dir < 180)
    {
        sprite_index = sbmobauex1
        mdir = 135
        undersprite = 1686
    }
    else if (dir >= 180 && dir < 270)
    {
        sprite_index = sbmobauex1
        mdir = 225
        undersprite = 1686
    }
    else
    {
        sprite_index = sbmobauex1
        mdir = 315
        undersprite = 1686
    }
    if (image_index < 1)
        image_speed = 0
    else if (image_index < 4)
    {
        image_speed = (1/30)
        if (timer6 == 0 && image_index > 1)
        {
            timer6 = 1
            objplayerview.shaket = 6
            flash = 0.5
            scrsplash((x - 16), (y + 64), smobau2splash, 1)
        }
        if (timer6 == 1 && image_index > 2)
        {
            timer6 = 2
            objplayerview.shaket = 6
            flash = 0.5
            scrsplash((x - 16), (y + 64), smobau2splash, 1)
        }
        if (timer6 == 2 && image_index > 3)
        {
            timer6 = 3
            objplayerview.shaket = 6
            flash = 0.5
            scrsplash((x - 16), (y + 64), smobau2splash, 1)
        }
    }
    else
    {
        if (timer6 != 0)
        {
            timer6 = 0
            objplayerview.shaket = 12
            flash = 1
            scrsplash((x - 16), (y + 64), smobau2splash, 0)
            repeat (10)
            {
                rdist = irandom(192)
                rdir = random(360)
                part_particles_create(psbreak, (x - 16 + (lengthdir_x(rdist, rdir))), (y + 64 + (lengthdir_y((rdist / 2), rdir))), ptbreak, 1)
            }
            repeat (8)
            {
                rdist = irandom(192)
                rdir = random(360)
                part_particles_create(psbreak, (x - 16 + (lengthdir_x(rdist, rdir))), (y + 64 + (lengthdir_y((rdist / 2), rdir))), pt, 1)
            }
            repeat (15)
            {
                rdist2 = irandom(192)
                rdir2 = random(360)
                part_particles_create(psbreak, (x - 16 + (lengthdir_x(rdist2, rdir2))), (y + 64 + (lengthdir_y((rdist2 / 2), rdir2))), pt2, 1)
            }
        }
        image_index = 4.5
    }
}
if (state == 0)
{
    dipspd = 0.1 * spd
    image_index = shellhp
    image_speed = 0
    scrspr8dir(dir, sbmobaushell0, sbmobaushell1, sbmobaushell2, sbmobaushell3, sbmobaushell4)
    if (dir >= 22.5 && dir < 67.5)
    {
        mdir = 45
        undersprite = 1888
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        mdir = 90
        undersprite = 2743
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        mdir = 135
        undersprite = 1888
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        mdir = 180
        undersprite = 800
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        mdir = 225
        undersprite = 795
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        mdir = 270
        undersprite = 1882
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        mdir = 315
        undersprite = 795
    }
    else
    {
        mdir = 0
        undersprite = 800
    }
    if (dip >= (4 - dipspd))
        dip = 0
    else if (dip >= 1 && dip < 2)
        changey += ((8 - changey) / 4)
    else
        changey += ((-changey) / 12)
    if (pattern < 0)
    {
        scrmovcol(spd, mdir)
        if (dist1 == 0)
            spd += ((-spd) / 12)
        pattern += (1/30)
    }
    else if (pattern < 1)
        pattern = choose(1, 2, 3)
    if (pattern == 1)
    {
        instance_create_layer((x + (lengthdir_x(32, dir))), (y + (lengthdir_y(32, dir))), "shadows", objbmobaupath)
        dist1 = 0
        state = 1
        pattern = -1
    }
    else
        timer01 = 0
    if (pattern == 2)
    {
        if (timer02 == 0)
        {
            timer02 += choose(1, 2)
            image_index = 0
            state = 4
        }
        else if (timer02 == 1)
        {
            timer02 += 2
            image_index = 0
            state = 3
        }
        else
        {
            timer02 = 1
            instance_create_layer((x + (lengthdir_x(32, dir))), (y + (lengthdir_y(32, dir))), "shadows", objbmobaupath)
            dist1 = 128
            state = 1
            pattern = -1
        }
    }
    else
        timer02 = 0
    if (pattern == 3)
    {
        if (timer03 == 0)
        {
            timer03 += 1
            image_index = 0
            state = 3
        }
        else
        {
            timer03 = 1
            instance_create_layer((x + (lengthdir_x(32, dir))), (y + (lengthdir_y(32, dir))), "shadows", objbmobaupath)
            dist1 = 128
            state = 1
            pattern = -1
        }
    }
    else
        timer03 = 0
}
