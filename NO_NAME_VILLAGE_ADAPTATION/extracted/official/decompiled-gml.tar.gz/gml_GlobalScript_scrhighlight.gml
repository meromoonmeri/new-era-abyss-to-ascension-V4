function scrhighlight(argument0, argument1, argument2, argument3, argument4, argument5) //gml_Script_scrhighlight
{
    if (objplayer.interactid == id)
        highlight += ((1 - highlight) / 12)
    else
        highlight += ((-highlight) / 12)
    if (highlight > 0)
    {
        gpu_set_fog(true, c_white, 0, 1000)
        draw_sprite_ext(argument0, argument1, (argument2 + 2), argument3, argument4, argument5, 0, -1, highlight)
        draw_sprite_ext(argument0, argument1, (argument2 - 2), argument3, argument4, argument5, 0, -1, highlight)
        draw_sprite_ext(argument0, argument1, argument2, (argument3 + 2), argument4, argument5, 0, -1, highlight)
        draw_sprite_ext(argument0, argument1, argument2, (argument3 - 2), argument4, argument5, 0, -1, highlight)
        gpu_set_fog(false, c_white, 0, 1000)
    }
}

