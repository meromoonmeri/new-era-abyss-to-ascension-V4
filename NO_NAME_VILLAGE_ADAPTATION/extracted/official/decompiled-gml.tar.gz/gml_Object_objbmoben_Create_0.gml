event_inherited()
objplayer.boss = self
mobname = "Reg"
mob = 3
dir = 270
level = 8
phase = 1
hpmax = [0, 8, 14, 20, 60, 1]
maxhp = hpmax[1]
hp = maxhp
givexp = 0
pattern = -1
prevpat = -1
hvyamr = 0
sound = 0
state = -1
prevx = 0
prevy = 0
prevz = 0
targetx = 0
targety = 0
cdir = 1
cbt = 0
dx = 0
dy = 0
dist3 = 320
ppx = 0
ppy = 0
pbx = 0
pby = 0
staterev = 0
revrange = 0
prev = 0
rev = 0
maxsrev = 0
revframe = -1
newhp = 0.75
revhp = 0
poise = 1
jb = 0
ashad = 1
timer = 0
timer3 = 0
timer12 = 0
ct = 0
ptx = 0
pty = 0
z = 0
zt = 0
flash = 0
evpii = -1
splash14 = 0
evsy = -1
fpt = 0
fpy = 2001
shatter = 0
wcol = 0
pcol = ds_list_create()
ds_list_add(pcol, 50)
ds_list_add(pcol, 375)
ds_list_add(pcol, 69)
ds_list_add(pcol, 307)
ds_list_add(pcol, 68)
ps = part_system_create()
ptj = part_type_create()
part_type_sprite(ptj, 1949, 1, 1, 0)
part_type_life(ptj, 45, 45)
ptl = part_type_create()
part_type_sprite(ptl, 2739, 1, 1, 0)
part_type_scale(ptl, 0.75, 0.75)
part_type_alpha3(ptl, 1, 1, 0)
part_type_life(ptl, 30, 30)
psr0 = part_system_create()
part_system_depth(psr0, ((-room_height) * 2))
ptr0 = part_type_create()
part_type_sprite(ptr0, 1041, 0, 0, 0)
part_type_scale(ptr0, 4, 4)
part_type_size(ptr0, 0.2, 0.3, 0.1, 0)
part_type_alpha3(ptr0, 0.6, 1, 0)
part_type_life(ptr0, 30, 30)
ptc = part_type_create()
part_type_sprite(ptc, 501, 0, 0, 0)
part_type_scale(ptc, 0.8, 0.8)
part_type_direction(ptc, 0, 360, 0, 0)
part_type_orientation(ptc, 0, 360, 0, 0, 1)
part_type_life(ptc, 999, 999)
ptsp = part_type_create()
part_type_sprite(ptsp, 1593, 0, 0, 0)
part_type_scale(ptsp, 4, 12)
part_type_size(ptsp, 0.6, 1.2, -0.2, 0)
part_type_orientation(ptsp, 0, 360, 0, 0, 0)
part_type_life(ptsp, 8, 12)
ptdsp = part_type_create()
part_type_sprite(ptdsp, 1477, 1, 1, 0)
part_type_life(ptdsp, 20, 20)
ptbsp = part_type_create()
part_type_sprite(ptbsp, 382, 1, 1, 0)
part_type_alpha3(ptbsp, 1, 1, 0)
part_type_life(ptbsp, 40, 40)
ptsh = part_type_create()
part_type_sprite(ptsh, 2637, 0, 0, 0)
part_type_size(ptsh, 0.02, 0.02, 0.02, 0.1)
part_type_alpha3(ptsh, 0.2, 0.9, 0)
part_type_life(ptsh, 20, 20)
