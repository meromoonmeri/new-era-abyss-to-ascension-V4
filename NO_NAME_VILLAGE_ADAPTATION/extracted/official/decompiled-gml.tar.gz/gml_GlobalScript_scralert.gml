function scralert(argument0, argument1, argument2) //gml_Script_scralert
{
    with (objalert)
    {
        if (creator == id)
            instance_destroy()
    }
    var salert = instance_create_depth(x, y, ((-y) - 4), objalert)
    if (argument0 == 0)
        salert.sprite_index = salert0
    else if (argument0 == 1)
        salert.sprite_index = salert1
    else if (argument0 == 2)
        salert.sprite_index = salert2
    if (argument1 == 100 || argument1 == 227 || argument1 == 641)
    {
        salert.creator = argument1
        salert.yoffset = 100
    }
    else
    {
        salert.creator = id
        salert.yoffset = argument1
        salert.x = x
        salert.y = y
    }
    salert.time = argument2
}

