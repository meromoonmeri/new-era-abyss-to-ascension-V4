event_inherited()
var zmax = 1120
var accl = 2
if (chit != 0)
    instance_destroy()
if (state == 0)
{
    sindex = 2
    x += lengthdir_x(4, dir)
    y += lengthdir_y(4, dir)
    if (z < zmax)
    {
        z += spd
        spd -= accl
    }
    else
    {
        timer1 = 30 - dist * 0.03 + (irandom_range(-5, 5))
        x = objbmobsm.x + (lengthdir_x(dist, dir))
        y = objbmobsm.y + (lengthdir_y(dist, dir))
        state = 1
    }
}
else if (state == 1)
{
    alpha = 0
    salpha = timer1 / 90 / 2
    timer1 += 1
    if (timer1 < 30)
        sindex = 2
    else if (timer1 < 60)
        sindex = 1
    else if (timer1 < 90)
        sindex = 0
    else
        state = 2
}
else if (state == 2)
{
    alpha = 1
    if (z > 0)
    {
        z -= spd
        spd += accl
    }
    else
        state = 3
}
else if (state == 3)
{
    alpha = 0
    objplayerview.shaket = 6
    scrsplash(x, y, smobsm2splash, 0)
    chit = 2
    state = 4
}
