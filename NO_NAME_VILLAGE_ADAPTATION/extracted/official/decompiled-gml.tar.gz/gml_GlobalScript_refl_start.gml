function refl_start(argument0, argument1) //gml_Script_refl_start
{
    instance_create_layer(0, 0, argument0, obj_waterrefl)
    global.camera_used = argument1
}

