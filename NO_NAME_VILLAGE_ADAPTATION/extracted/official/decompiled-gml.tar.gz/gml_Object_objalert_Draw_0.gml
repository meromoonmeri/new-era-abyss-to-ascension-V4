if (creator != -4)
    draw_self()
else
    draw_sprite(sprite_index, image_index, (x - xoffset), (y - yoffset))
