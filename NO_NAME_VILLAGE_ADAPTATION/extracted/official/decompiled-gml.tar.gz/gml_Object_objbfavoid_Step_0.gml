with (objmob)
    mobpause = 1
objplayer.caninput = false
objplayer.iframe = 1
if (timer < 1)
{
    bfmapx = global.mapx
    bfmapy = global.mapy
    with (objplayer)
    {
        if (transitt < 0)
            other.timer = 1
    }
    if (!instance_exists(objbfswitch))
    {
        var bfswitch = instance_create_layer(0, 0, "instances", objbfswitch)
        bfswitch.alphat = 0
        bfswitch.alphatt = -0.008333333333333333
    }
}
else if (timer < 2)
{
    if (scrplayerrun(bfx, bfy) == 1)
    {
        timer += (1/30)
        objplayer.dir = dir
    }
    if (objplayer.transitt == -1)
    {
        with (objbfswitch)
            start = true
    }
}
else if (timer < 3)
{
    if (scrview((objplayer.x + (lengthdir_x(640, dir))), (objplayer.y + (lengthdir_y(640, dir))), 0) < 12)
        timer += (1/120)
}
else if (timer < 4)
{
    if (timer < 3.5)
    {
        with (objplayer)
        {
            if (follower > 1)
            {
                follower = 1
                objfollower.state = 0
            }
        }
        objplayerview.target = 100
        if (point_distance(objplayerview.x, objplayerview.y, objplayer.x, objplayer.y) < 12)
            timer = 3.5
    }
    else
    {
        scrplayerrun(x, y)
        if (objplayer.transitt >= 0)
            timer = 4
    }
}
else if (timer < 5)
{
    if (objplayer.transitt < 0)
    {
        timer = 5
        x = objplayer.x + (lengthdir_x(192, (dir + 180)))
        y = objplayer.y + (lengthdir_y(192, (dir + 180)))
    }
}
else if (timer < 6)
{
    if (scrplayerrun(x, y) > 0)
        timer += (1/30)
}
else if (timer < 7)
{
    if (!instance_exists(objmenu))
    {
        with (objplayer)
            state = 0
        var menu = instance_create_depth(x, y, 0, objmenu)
        menu.caninput = false
        menu.page = 2
    }
    else
        timer = 7
}
else if (timer < 8)
{
    with (objmenu)
    {
        if (state >= 0)
        {
            state = 2
            drawmap = 0
            other.timer = 8
        }
    }
}
else if (timer < 9)
    timer = 9
else if (timer < 10)
{
    if (dir == 0)
    {
        with (objmenu)
        {
            if (pmapx < 6 && inmapx == 5)
            {
                fpmapx += 4
                mapposx += 1
                scrsound(snclick0, 50, 0.5, 1)
            }
            else if (inmapx > 2)
            {
                inmapx -= 1
                mapposx += 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
    }
    else if (dir == 90)
    {
        with (objmenu)
        {
            if (pmapy > 3 && inmapy == 5)
            {
                fpmapy -= 4
                mapposy -= 1
                scrsound(snclick0, 50, 0.5, 1)
            }
            else if (inmapy < 6)
            {
                inmapy += 1
                mapposy -= 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
    }
    else if (dir == 180)
    {
        with (objmenu)
        {
            if (pmapx > 3 && inmapx == 5)
            {
                fpmapx -= 4
                mapposx -= 1
                scrsound(snclick0, 50, 0.5, 1)
            }
            else if (inmapx < 8)
            {
                inmapx += 1
                mapposx -= 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
    }
    else
    {
        with (objmenu)
        {
            if (pmapy < 9 && inmapy == 5)
            {
                fpmapy += 4
                mapposy += 1
                scrsound(snclick0, 50, 0.5, 1)
            }
            else if (inmapy > 4)
            {
                inmapy -= 1
                mapposy += 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
    }
    timer = 10
}
else if (timer < 11)
{
    with (objmenu)
    {
        if (fpmapx == 0 && fpmapy == 0)
            other.timer += (1/30)
    }
}
else if (timer < 12)
{
    with (objmenu)
    {
        if (state >= 0)
        {
            state = 2
            drawmap = 0
            other.timer += 0.1
        }
    }
}
else if (timer < 13)
{
    if (objmenu.drawmap >= 0)
    {
        if (objmenu.drawmap == 0)
        {
            global.mapgrid[objmenu.mapposx][objmenu.mapposy] = 1
            objmenu.drawmap = 1
        }
    }
    else
        timer = 13
}
else if (timer < 14)
    timer += 0.016666666666666666
else if (timer < 15)
{
    if (global.mapgrid[(global.mapx + 1)][global.mapy] == 1 && global.mapgrid[global.mapx][(global.mapy - 1)] == 1 && global.mapgrid[(global.mapx - 1)][global.mapy] == 1 && global.mapgrid[global.mapx][(global.mapy + 1)] == 1)
    {
        timer = 15
        dir += 180
        if (dir >= 360)
            dir -= 360
    }
    else
        timer = 20
}
else if (timer < 16)
{
    if (dir == 0)
    {
        with (objmenu)
        {
            if (pmapx < 6 && inmapx == 5)
            {
                fpmapx += 4
                mapposx += 1
                scrsound(snclick0, 50, 0.5, 1)
            }
            else if (inmapx > 2)
            {
                inmapx -= 1
                mapposx += 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
    }
    else if (dir == 90)
    {
        with (objmenu)
        {
            if (pmapy > 3 && inmapy == 5)
            {
                fpmapy -= 4
                mapposy -= 1
                scrsound(snclick0, 50, 0.5, 1)
            }
            else if (inmapy < 6)
            {
                inmapy += 1
                mapposy -= 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
    }
    else if (dir == 180)
    {
        with (objmenu)
        {
            if (pmapx > 3 && inmapx == 5)
            {
                fpmapx -= 4
                mapposx -= 1
                scrsound(snclick0, 50, 0.5, 1)
            }
            else if (inmapx < 7)
            {
                inmapx += 1
                mapposx -= 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
    }
    else
    {
        with (objmenu)
        {
            if (pmapy < 9 && inmapy == 5)
            {
                fpmapy += 4
                mapposy += 1
                scrsound(snclick0, 50, 0.5, 1)
            }
            else if (inmapy > 4)
            {
                inmapy -= 1
                mapposy += 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
    }
    timer = 16
}
else if (timer < 17)
{
    with (objmenu)
    {
        if (fpmapx == 0 && fpmapy == 0)
            other.timer += 0.1
    }
}
else if (timer < 18)
{
    with (objmenu)
    {
        if (state >= 0)
        {
            state = 2
            drawmap = 0
            other.timer += 0.1
        }
    }
}
else if (timer < 19)
{
    if (objmenu.drawmap >= 0)
    {
        if (objmenu.drawmap == 0)
        {
            global.mapgrid[global.mapx][global.mapy] = 1
            objmenu.drawmap = 1
        }
    }
    else
        timer += 0.016666666666666666
}
else
{
    if instance_exists(objmenu)
        objmenu.state = 5
    with (objtransit)
        update = true
    instance_destroy()
}
