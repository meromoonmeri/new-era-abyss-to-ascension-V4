function scrsfont(argument0, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10) //gml_Script_scrsfont
{
    var vsfont = argument0
    var vx = argument1
    var vy = argument2
    var vtext = argument3
    var vcol = argument4
    var vhal = argument5
    var vval = argument6
    var vsep = argument7
    var vw = floor(argument8 / argument9)
    var vxscale = argument9
    var vyscale = argument10
    var strtxt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890.,!?%-~:;'()"
    var strtxtid = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890.,!?%-~:;'()_#&£$"
    if (!variable_global_exists("sfont5x8"))
        global.sfont5x8 = font_add_sprite_ext(sfont5x8, strtxt, true, 4)
    if (!variable_global_exists("sfont6x9"))
        global.sfont6x9 = font_add_sprite_ext(sfont6x9, strtxt, true, 4)
    if (!variable_global_exists("sfont7x12"))
        global.sfont7x12 = font_add_sprite_ext(sfont7x12, strtxt, true, 6)
    if (!variable_global_exists("sfont6x9id"))
        global.sfont6x9id = font_add_sprite_ext(sfont6x9id, strtxtid, true, 6)
    if (vsfont == 2565)
        draw_set_font(global.sfont5x8)
    else if (vsfont == 1019)
        draw_set_font(global.sfont6x9)
    else if (vsfont == 467)
        draw_set_font(global.sfont7x12)
    else if (vsfont == 1187)
        draw_set_font(global.sfont6x9id)
    if (vhal == fa_left)
        draw_set_halign(fa_left)
    else
        draw_set_halign(vhal)
    if (vval == fa_top)
        draw_set_valign(fa_top)
    else
        draw_set_valign(vval)
    if (vcol != -1)
        gpu_set_fog(true, vcol, 0, 1000)
    var rtext = draw_text_ext_transformed(vx, vy, vtext, vsep, vw, vxscale, vyscale, 0)
    gpu_set_fog(false, vcol, 0, 1000)
    draw_set_halign(-1)
    draw_set_valign(-1)
    return rtext;
}

