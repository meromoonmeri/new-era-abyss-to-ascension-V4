function scrdistview(argument0, argument1, argument2, argument3) //gml_Script_scrdistview
{
    var alertdist = point_distance(argument0, argument1, argument2, argument3)
    var alertdir = point_direction(argument0, argument1, argument2, argument3)
    var lengthdirx = abs(lengthdir_x(alertdist, alertdir))
    var lengthdiry = abs(lengthdir_y((alertdist * 1.5), alertdir))
    var sqrtlengthdir = sqrt(sqr(lengthdirx) + sqr(lengthdiry))
    return sqrtlengthdir;
}

