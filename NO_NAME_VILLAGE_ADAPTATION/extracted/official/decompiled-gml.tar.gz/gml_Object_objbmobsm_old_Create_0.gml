event_inherited()
state = -1
objplayer.boss = self
boss = true
maxhp = 30
hp = maxhp
instance_create_layer(x, y, "shadows", objbmobsmshad)
nextstate = 0
timer2 = 0
spit = 0
tongue = 0
timer2 = 0
timer3 = 0
splash3 = 0
splash4 = 0
eat = 0
splash5 = 0
