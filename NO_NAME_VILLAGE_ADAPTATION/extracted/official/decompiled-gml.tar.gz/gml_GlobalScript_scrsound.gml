function scrsound(argument0, argument1, argument2, argument3) //gml_Script_scrsound
{
    if (!variable_global_exists("music"))
        global.music = 1
    if (!variable_global_exists("sound"))
        global.sound = 1
    var sound = audio_play_sound(argument0, argument1, 0)
    if is_undefined(argument2)
        argument2 = 0
    if (instance_exists(objplayerview) && (!instance_exists(objbmobauview)))
    {
        if (scrdistview(x, y, objplayerview.x, objplayerview.y) < 864)
            audio_sound_gain(sound, (argument2 * global.sound), 0)
        else if (scrdistview(x, y, objplayerview.x, objplayerview.y) < 1296)
            audio_sound_gain(sound, (argument2 * global.sound / 2), 0)
        else
            audio_sound_gain(sound, 0, 0)
    }
    else
        audio_sound_gain(sound, (argument2 * global.sound), 0)
    audio_sound_pitch(sound, argument3)
}

