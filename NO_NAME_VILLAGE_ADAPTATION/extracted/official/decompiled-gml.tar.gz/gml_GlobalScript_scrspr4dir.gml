function scrspr4dir(argument0, argument1, argument2) //gml_Script_scrspr4dir
{
    if (argument0 >= 0 && argument0 < 90)
        sprite_index = argument2
    else if (argument0 >= 90 && argument0 < 180)
        sprite_index = argument2
    else if (argument0 >= 180 && argument0 < 270)
        sprite_index = argument1
    else
        sprite_index = argument1
}

