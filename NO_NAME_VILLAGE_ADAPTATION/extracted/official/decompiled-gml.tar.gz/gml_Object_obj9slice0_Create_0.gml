controls()
scrsound(snclick1, 50, 0.5, 1)
objplayer.caninput = false
caninput = false
text = 0
font = 2
state = 1
xscale = 0
yscale = 0
yscalemax = 0
bar = 0
bxscale = 0
by = 0
select = 0
canblink = 0
blinking = 0
with (objrm56)
{
    if ((!scritemcheck(3)) && objplayer.stage <= 1)
        other.canblink = 1
}
with (objrm63)
{
    if ((!scritemcheck(15)) && (!scritemcheck(18)) && objplayer.stage <= 2.29)
        other.canblink = 1
}
with (objrm73)
{
    if ((!scritemcheck(17)) && objplayer.stage <= 2.29)
        other.canblink = 1
}
with (objrm84)
{
    if ((!scritemcheck(15)) && objplayer.stage <= 2.29)
        other.canblink = 1
}
with (objrm43)
{
    if ((!scritemcheck(21)) && objplayer.stage < 3.07)
        other.canblink = 1
}
with (objrm43)
{
    if ((!scritemcheck(21)) && objplayer.stage < 3.07)
        other.canblink = 1
}
with (objrm150)
{
    if ((!scritemcheck(23)) && objplayer.stage < 3.1)
        other.canblink = 1
}
with (objrm25)
{
    if (event == 1)
        other.canblink = 1
}
with (objrm253)
{
    if ((!scritemcheck(22)) && objplayer.stage < 3.1)
        other.canblink = 1
}
