function scrsplash(argument0, argument1, argument2, argument3) //gml_Script_scrsplash
{
    if (objplayerview.at <= 0.1)
    {
        var splash = instance_create_depth(argument0, argument1, ((-argument1) + 12), objsplash)
        splash.splash = argument2
        splash.sprite_index = argument2
        splash.image_index = argument3
        splash.creator = self
    }
}

