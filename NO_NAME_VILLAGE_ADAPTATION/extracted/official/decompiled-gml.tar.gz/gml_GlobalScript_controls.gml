function controls() //gml_Script_controls
{
    vkpause = 27
    vkaction = 88
    vkrun = 90
    vkswitch = 67
    vkheal = 65
    vkup = 38
    vkdown = 40
    vkleft = 37
    vkright = 39
    vkinv = 73
    vkmap = 77
}

