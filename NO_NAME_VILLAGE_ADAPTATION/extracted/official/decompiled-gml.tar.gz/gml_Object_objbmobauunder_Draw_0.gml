if instance_exists(objbmobau)
{
    draw_sprite_ext(sprite_index, image_index, x, y, objbmobau.facing, 1, 0, c_white, (objbmobau.alpha * alpha))
    if (objbmobau.balpha > 0)
        draw_sprite_ext(sprite_index, image_index, x, y, objbmobau.facing, 1, 0, c_black, (objbmobau.balpha * alpha))
}
else
    instance_destroy()
