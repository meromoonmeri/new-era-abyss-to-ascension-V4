event_inherited()
c = -1
var yblock = instance_create_layer(x, y, "invisible", objywall)
yblock.c = (-c)
if (image_xscale == 1)
{
    if (image_yscale == 1)
    {
        dir = 270
        yblock.dir = 90
    }
    else
    {
        dir = 0
        yblock.dir = 180
        yblock.x = x - 64
        yblock.y = y - 64
    }
}
else if (image_yscale == 1)
{
    dir = 180
    yblock.dir = 0
}
else
{
    dir = 90
    yblock.dir = 270
    yblock.x = x - 64
}
