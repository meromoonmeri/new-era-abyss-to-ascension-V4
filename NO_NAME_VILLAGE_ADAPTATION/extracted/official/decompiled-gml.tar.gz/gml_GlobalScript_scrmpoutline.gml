function scrmpoutline(argument0, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8) //gml_Script_scrmpoutline
{
    var pos = (global.time + y / 5 + x / 2) / 15
    var opacity = (sin(pos) / 2 + 0.5) * 0.5
    if (argument0 < 1)
        opacity = 0
    if instance_exists(objplayer)
    {
        var iid = objplayer.interactid
        if (instance_exists(iid) && objplayer.caninput == 1)
        {
            if (iid == argument8 || iid.object_index == argument8)
                outline += ((1 - outline) / 5)
            else
                outline += ((-outline) / 5)
        }
        else
            outline += ((-outline) / 5)
    }
    shader_set(shoutline)
    var tex = sprite_get_texture(sprite_index, image_index)
    var texw = texture_get_texel_width(tex) * 4 / argument5
    var texh = texture_get_texel_height(tex) * 4 / argument6
    shader_set_uniform_f(shader_get_uniform(shoutline, "u_pixelSize"), texw, texh)
    var u1 = array_get(texture_get_uvs(tex), 0)
    var v1 = array_get(texture_get_uvs(tex), 1)
    var u2 = array_get(texture_get_uvs(tex), 2)
    var v2 = array_get(texture_get_uvs(tex), 3)
    var shdr = shader_current()
    shader_set_uniform_f(shader_get_uniform(shdr, "u_uvTopLeft"), u1, v1)
    shader_set_uniform_f(shader_get_uniform(shdr, "u_uvBottomRight"), u2, v2)
    shader_set_uniform_f_array(shader_get_uniform(shoutline, "u_outlineColor"), [1, 1, 1, (opacity + outline)])
    draw_sprite_ext(argument1, argument2, argument3, argument4, argument5, argument6, 0, c_white, argument7)
    shader_reset()
    if (global.mapgrid[global.mapx][global.mapy] != 1 && global.season >= 1)
    {
        pos = pos / 5
        shader_set(shoutline1)
        var res_uniform = shader_get_uniform(shoutline1, "u_resolution")
        shader_set_uniform_f(res_uniform, (sprite_width * image_xscale), (sprite_height * image_yscale))
        var time_uniform = shader_get_uniform(shoutline1, "u_time")
        shader_set_uniform_f(time_uniform, pos)
        var angle_uniform = shader_get_uniform(shoutline1, "u_angle")
        shader_set_uniform_f(angle_uniform, 0.4363323129985824)
        var alpha_uniform = shader_get_uniform(shoutline1, "u_alpha")
        shader_set_uniform_f(alpha_uniform, 0.15)
        draw_sprite_ext(argument1, argument2, argument3, argument4, argument5, argument6, 0, c_white, argument7)
        shader_reset()
    }
}

