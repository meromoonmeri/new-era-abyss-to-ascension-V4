function scrinput(argument0) //gml_Script_scrinput
{
    gamepad_set_axis_deadzone(0, 0.25)
    if (!variable_global_exists("c_up"))
        global.c_up = 37
    if (!variable_global_exists("c_down"))
        global.c_down = 38
    if (!variable_global_exists("c_left"))
        global.c_left = 36
    if (!variable_global_exists("c_right"))
        global.c_right = 39
    if (!variable_global_exists("c_select"))
        global.c_select = 23
    if (!variable_global_exists("c_back"))
        global.c_back = 25
    if (!variable_global_exists("c_switch"))
        global.c_switch = 2
    if (!variable_global_exists("c_heal"))
        global.c_heal = 0
    switch argument0
    {
        case "up":
            return ((keyboard_check(scrchangecontrol(38, global.c_up))) - (gamepad_axis_value(0, gp_axislv)));
        case "upp":
            return ((keyboard_check_pressed(scrchangecontrol(38, global.c_up))) + (gamepad_button_check_pressed(0, gp_padu)));
        case "down":
            return ((keyboard_check(scrchangecontrol(40, global.c_down))) + (gamepad_axis_value(0, gp_axislv)));
        case "downp":
            return ((keyboard_check_pressed(scrchangecontrol(40, global.c_down))) + (gamepad_button_check_pressed(0, gp_padd)));
        case "left":
            return ((keyboard_check(scrchangecontrol(37, global.c_left))) - (gamepad_axis_value(0, gp_axislh)));
        case "leftp":
            return ((keyboard_check_pressed(scrchangecontrol(37, global.c_left))) + (gamepad_button_check_pressed(0, gp_padl)));
        case "right":
            return ((keyboard_check(scrchangecontrol(39, global.c_right))) + (gamepad_axis_value(0, gp_axislh)));
        case "rightp":
            return ((keyboard_check_pressed(scrchangecontrol(39, global.c_right))) + (gamepad_button_check_pressed(0, gp_padr)));
        case "action":
            return ((keyboard_check(scrchangecontrol(88, global.c_select))) + (gamepad_button_check(0, gp_face1)) + mouse_check_button(mb_left));
        case "actionp":
            return ((keyboard_check_pressed(scrchangecontrol(88, global.c_select))) + (gamepad_button_check_pressed(0, gp_face1)) + mouse_check_button_pressed(mb_left));
        case "actionr":
            return ((keyboard_check_released(scrchangecontrol(88, global.c_select))) + (gamepad_button_check_released(0, gp_face1)) + mouse_check_button_released(mb_left));
        case "run":
            return ((keyboard_check(scrchangecontrol(90, global.c_back))) + (gamepad_button_check(0, gp_face2)) + mouse_check_button(mb_right));
        case "runp":
            return ((keyboard_check_pressed(scrchangecontrol(90, global.c_back))) + (gamepad_button_check_pressed(0, gp_face2)) + mouse_check_button_pressed(mb_right));
        case "runr":
            return ((keyboard_check_released(scrchangecontrol(90, global.c_back))) + (gamepad_button_check_released(0, gp_face2)) + mouse_check_button_released(mb_right));
        case "switch":
            return ((keyboard_check_pressed(scrchangecontrol(67, global.c_switch))) + (gamepad_button_check_pressed(0, gp_face3)));
        case "heal":
            return ((keyboard_check_pressed(scrchangecontrol(65, global.c_heal))) + (gamepad_button_check_pressed(0, gp_face4)));
        case "menu":
            return (keyboard_check_pressed(vk_escape) + (gamepad_button_check_pressed(0, gp_start)));
        case "map":
            return (keyboard_check_pressed(ord("M")) + (gamepad_button_check_pressed(0, gp_select)));
        case "inv":
            return keyboard_check_pressed(ord("I"));
    }

}

