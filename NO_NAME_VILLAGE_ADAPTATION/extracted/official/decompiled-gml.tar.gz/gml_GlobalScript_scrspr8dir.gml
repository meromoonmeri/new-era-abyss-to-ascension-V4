function scrspr8dir(argument0, argument1, argument2, argument3, argument4, argument5) //gml_Script_scrspr8dir
{
    if (argument0 >= 22.5 && argument0 < 67.5)
        sprite_index = argument4
    else if (argument0 >= 67.5 && argument0 < 112.5)
        sprite_index = argument5
    else if (argument0 >= 112.5 && argument0 < 157.5)
        sprite_index = argument4
    else if (argument0 >= 157.5 && argument0 < 202.5)
        sprite_index = argument3
    else if (argument0 >= 202.5 && argument0 < 247.5)
        sprite_index = argument2
    else if (argument0 >= 247.5 && argument0 < 292.5)
        sprite_index = argument1
    else if (argument0 >= 292.5 && argument0 < 337.5)
        sprite_index = argument2
    else
        sprite_index = argument3
}

