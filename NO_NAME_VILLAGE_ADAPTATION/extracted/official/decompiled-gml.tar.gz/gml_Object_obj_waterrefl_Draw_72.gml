if (!surface_exists(global.refl_surf))
{
    if global.camera_used
    {
        var w = camera_get_view_width(view_camera[(0 << 0)])
        var h = camera_get_view_height(view_camera[(0 << 0)])
    }
    else
    {
        w = room_width
        h = room_height
    }
    global.refl_surf = surface_create(w, h)
}
surface_set_target(global.refl_surf)
draw_clear_alpha(c_black, 0)
surface_reset_target()
