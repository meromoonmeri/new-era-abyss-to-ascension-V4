function scrcolline(argument0, argument1, argument2, argument3) //gml_Script_scrcolline
{
    colline = ds_list_create()
    ds_list_add(colline, 50)
    ds_list_add(colline, 375)
    ds_list_add(colline, 69)
    ds_list_add(colline, 543)
    ds_list_add(colline, 307)
    ds_list_add(colline, 68)
    if (fl == 0)
        ds_list_add(colline, 447)
    else
        ds_list_add(colline, 39)
    if variable_instance_exists(id, "mob")
    {
        if (mob == 2)
            ds_list_add(colline, 305)
    }
    for (var c = 0; c < ds_list_size(colline); c += 1)
    {
        if collision_line(argument0, argument1, argument2, argument3, ds_list_find_value(colline, c), true, true)
            return true;
    }
    ds_list_delete(colline, 1)
}

