if (z > 0)
{
    draw_self()
    draw_sprite(sbmob0p, image_index, x, (y - z))
}
else if (fadet > 60)
    draw_sprite(sbmob0pe, 0, x, y)
else
    draw_sprite_ext(sbmob0pe, 0, x, y, 1, 1, 0, c_white, (fadet / 60))
