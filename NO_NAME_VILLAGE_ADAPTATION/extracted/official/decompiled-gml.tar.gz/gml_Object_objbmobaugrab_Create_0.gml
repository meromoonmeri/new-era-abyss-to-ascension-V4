controls()
var hf = instance_create_layer(x, y, "instances", objbmobaugrabf)
hf.creator = id
image_speed = 0
alpha = 1
fl = 0
spd = 0
dir = (scrdir(self, objplayerview.player)) + (irandom_range(-90, 90))
z = 0
vel = 0
jump = 0
timer = 0
grab = -1
player = -4
flash = 0
psubt = 0
ps = part_system_create()
part_system_depth(ps, layer_get_depth("shadows"))
pt = part_system_create()
part_type_sprite(pt, 1354, 1, 1, 0)
part_type_life(pt, 15, 15)
part_system = part_system_create()
part_system_depth(part_system, layer_get_depth("shadows"))
pt2 = part_type_create()
pts2 = part_type_create()
ptd2 = part_type_create()
part_type_sprite(pt2, 1889, 0, 0, 0)
part_type_speed(pt2, 0.8, 4, 0, 0)
part_type_direction(pt2, 50, 130, 0, 0)
part_type_gravity(pt2, 0.4, 270)
part_type_life(pt2, 10, 10)
part_type_step(pt2, -2, pts2)
part_type_death(pt2, 1, ptd2)
part_type_sprite(pts2, 1889, 1, 1, 0)
part_type_life(pts2, 10, 10)
part_type_sprite(ptd2, 1302, 1, 1, 0)
part_type_alpha3(ptd2, 1, 0.5, 0)
part_type_life(ptd2, 10, 10)
