event_inherited()
if place_meeting(rmx, rmy, objplayer)
{
    with (objplayer)
        scrmovcol(spd, scrdir(objbmoben0, self))
}
else if place_meeting(rmx, rmy, objbmoben1)
{
    with (objbmoben1)
        scrmovcol(spd, scrdir(objbmoben0, self))
}
if (state == -1)
{
    if (timere1 == 0)
    {
        sprite_index = sbmoben1
        image_index = 0
        image_speed = 0
    }
    else
    {
        with (objplayer)
            caninput = false
    }
    if (timere1 == 1)
    {
        sprite_index = sbmoben1
        if (image_index < 3.5)
            image_speed = 0.1
        else
            image_speed = 0
    }
    else if (timere1 == 2)
    {
        sprite_index = sbmoben1
        if (image_index < (image_number - 0.5))
            image_speed = 0.1
        else
        {
            image_speed = 0
            state = 1
        }
    }
}
if (state == 0)
{
    if (pattern < -1)
    {
        image_index = 0
        image_speed = 0
        if (dir >= 22.5 && dir < 67.5)
            sprite_index = sbmoben1i3
        else if (dir >= 67.5 && dir < 112.5)
            sprite_index = sbmoben1i4
        else if (dir >= 112.5 && dir < 157.5)
            sprite_index = sbmoben1i3
        else if (dir >= 157.5 && dir < 202.5)
            sprite_index = sbmoben1i2
        else if (dir >= 202.5 && dir < 247.5)
            sprite_index = sbmoben1i1
        else if (dir >= 247.5 && dir < 292.5)
            sprite_index = sbmoben1i0
        else if (dir >= 292.5 && dir < 337.5)
            sprite_index = sbmoben1i1
        else
            sprite_index = sbmoben1i2
        if (abs(angle_difference(dir, idir)) > 30)
            pattern += 0.016666666666666666
        else
            pattern += 0.004166666666666667
    }
    else if (pattern < 1)
        pattern = 1
    else if (pattern == 1)
    {
        if (timer1 == 0)
        {
            state = 1
            pattern = -1.5
        }
    }
    else
        timer1 = 0
}
if (state == 1)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmoben1tu3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmoben1tu4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmoben1tu3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmoben1tu2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmoben1tu1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmoben1tu0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmoben1tu1
    else
        sprite_index = sbmoben1tu2
    if (image_index < 1)
    {
        image_speed = 0.1
        dir = idir
    }
    else if (image_index < 2)
        image_speed = 0.2
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.1
        if (timer1s == 0)
        {
            timer1s = 1
            var p = instance_create_layer((rmx + 78), rmy, "instances", objbmobenp1)
            p.dir = dir
            p.height = 424
            p.spd = 1
        }
    }
    else
        state = 0
}
else
    timer1s = 0
if (state == 2)
{
}
if (state == 3)
{
}
if (hit != 0 && state < 4)
{
    objplayerview.shaket = 12
    with (objbmobenp1)
    {
        if (shoot == 0)
            instance_destroy()
        else
            stack = 10
    }
    with (objbmobenp)
        dud = true
    state = 4
    with (objplayer)
    {
        caninput = false
        iframe = 1
        dir = scrdir(self, objbmoben0)
    }
    scrview(objbmoben0.rmx, (objbmoben0.rmy - 192), false)
    image_index = 0
    flash = 1
}
if (state == 4)
{
    if (timer4s == 0)
    {
        sprite_index = sbmoben12
        image_index = 0
        image_speed = 0
        with (objplayerview)
        {
            if (point_distance(x, y, targetx, targety) < 16)
                objbmoben0.timer4s = 1
        }
    }
    else if (timer4s == 1)
    {
        sprite_index = sbmoben12
        if (image_index < 2)
            image_speed = 0.1
        else if (image_index < 3)
            image_speed = 0.2
        else if (image_index < 4)
            scrview((rmx - sprite_xoffset + 396), (rmy - sprite_yoffset + 200), false)
        else if (image_index < 5)
        {
            image_speed = 0.05
            scrview(rmx, rmy, false)
        }
        else if (image_index < (image_number - 0.5))
        {
            image_speed = 0.1
            if (!instance_exists(objbmoben1))
            {
                instance_create_layer(rmx, (rmy - sprite_yoffset + 700), "instances", objbmoben1)
                scrsplash(rmx, (rmy - sprite_yoffset + 700), ssplash0, 0)
            }
            else
                objplayerview.target = 699
        }
        else
        {
            image_speed = 0
            state = 5
        }
    }
}
if (state == 5)
{
}
