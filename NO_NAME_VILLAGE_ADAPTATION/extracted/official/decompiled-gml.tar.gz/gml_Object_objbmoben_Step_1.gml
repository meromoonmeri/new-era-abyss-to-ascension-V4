var fi = floor(image_index)
if (state == 3)
{
    if (fi == 1)
    {
        if (sprite_index == sbmobenp0)
        {
            ptx = 8
            pty = 16
        }
        if (sprite_index == sbmobenp1)
        {
            ptx = 6
            pty = 17
        }
        if (sprite_index == sbmobenp2)
        {
            ptx = 3
            pty = 18
        }
        if (sprite_index == sbmobenp3)
        {
            ptx = -7
            pty = 14
        }
        if (sprite_index == sbmobenp4)
        {
            ptx = -9
            pty = 11
        }
    }
}
