function Documentation_Reflection() //gml_Script_Documentation_Reflection
{
}

