function scrptdust2(argument0, argument1, argument2, argument3, argument4, argument5, argument6) //gml_Script_scrptdust2
{
    if (ford <= 0)
    {
        var rperc = random(1)
        if (rperc < argument6)
        {
            var rdir = choose(0, 10, -10, 30, -30, 45, -45)
            scrptdust1((argument0 + (lengthdir_x(argument4, (argument3 + 180 + rdir)))), (argument1 + (lengthdir_y((argument4 * 0.6), (argument3 + 180 + rdir)))), argument2, (-argument5), argument3)
        }
    }
}

