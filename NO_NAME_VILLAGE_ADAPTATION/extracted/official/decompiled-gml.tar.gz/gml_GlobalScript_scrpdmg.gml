function scrpdmg() //gml_Script_scrpdmg
{
}

