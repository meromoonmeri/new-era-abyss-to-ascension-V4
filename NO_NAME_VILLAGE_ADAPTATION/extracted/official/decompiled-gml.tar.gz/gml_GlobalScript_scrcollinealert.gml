function scrcollinealert() //gml_Script_scrcollinealert
{
    colline = ds_list_create()
    ds_list_add(colline, 50)
    ds_list_add(colline, 375)
    ds_list_add(colline, 69)
    ds_list_add(colline, 543)
    ds_list_add(colline, 307)
    if (fl == 0)
        ds_list_add(colline, 447)
    else
        ds_list_add(colline, 39)
    for (var c = 0; c < ds_list_size(colline); c += 1)
    {
        if collision_line(x, y, player.x, player.y, ds_list_find_value(colline, c), true, true)
            return true;
    }
    ds_list_destroy(colline)
}

