if (interact == true)
    service = 0
if (service == 0)
{
    if (scr9slice((x + 84), (y - 60), [["Interact"]]) == -1)
    {
        if (optboxselect == 0)
            service = 1
        else
            service = -1
        optbox = 0
        optboxselect = -1
    }
}
if (service == 1)
{
    if (!variable_global_exists("bsinteract"))
        global.bsinteract = 0
    if (timer == 0)
    {
        if (global.season == 0)
        {
            if (objplayer.stage == 0.11)
                scrtbox(0, [[0, 1925, "Got the water!"], [1, 2331, "Mhm. Just pour into the basin there."]])
            else
                scrtbox(0, [[1, 1821, "..."], [0, 394, "I probably shouldn't disturb him..."]])
        }
        if (global.season == 1)
        {
            if (objplayer.follower == 0)
                scrtbox(0, [[1, 1821, "..."], [0, 394, "I probably shouldn't disturb him..."]])
            else if (global.bsinteract == 0)
                scrtbox(0, [[0, 1603, "Hey Dad. Can you make a metal sword for us?"], [1, 2331, "No."], [0, 401, "Welp. I gave it my best shot."], [0, 362, "We'll try again next time!"], [1, 1821, "(Not happening.)"]])
            else
                scrtbox(0, [[0, 1550, "... I have a question!"], [1, 546, "What is it Reg?"], [0, 2694, "Where does metal come from?"], [1, 2755, "Underground. Though, I've been getting my metal from scraps washed ashore in the Blue Forest."], [0, 394, "(It's rare to hear dad talk this much.)"], [0, 1550, "Ohhh... I have another question!"], [1, 2331, "Another time..."], [0, 401, "(Nevermind...)"]])
        }
        if (global.season == 3)
            scrtbox(0, [[1, 1878, "..."]])
    }
    else
    {
        global.bsinteract = 1 - global.bsinteract
        timer = 0
        service = -1
    }
}
event_inherited()
if (state == 0)
{
    image_speed = 0
    if (work == 0)
    {
        if (dir >= 22.5 && dir < 67.5)
            sprite_index = sbsi3
        else if (dir >= 67.5 && dir < 112.5)
            sprite_index = sbsi4
        else if (dir >= 112.5 && dir < 157.5)
            sprite_index = sbsi3
        else if (dir >= 157.5 && dir < 202.5)
            sprite_index = sbsi2
        else if (dir >= 202.5 && dir < 247.5)
            sprite_index = sbsi1
        else if (dir >= 247.5 && dir < 292.5)
            sprite_index = sbsi0
        else if (dir >= 292.5 && dir < 337.5)
            sprite_index = sbsi1
        else
            sprite_index = sbsi2
    }
    else if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbswi3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbswi4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbswi3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbswi2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbswi1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbswi0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbswi1
    else
        sprite_index = sbswi2
    spd = 0
}
if (state == 1)
{
    image_speed = 0.1
    sprite_index = sbsm0
    if (spd < 6)
        spd += 0.2
    x += lengthdir_x(spd, dir)
    y += lengthdir_y(spd, dir)
}
if (state == 2)
{
    work = 1
    sprite_index = sbsw0
    image_speed = 0.3
    if (image_index > 3 && image_index < 4 && timer1 != 1)
    {
        with (objbook)
        {
            if (bookstate > 0)
                other.state = 0
        }
        var lat = 1 - objplayerview.lat
        var at = 1 - objplayerview.at
        if instance_exists(objbook)
        {
            if (objbook.bookstate == 0)
                scrsound(snanvil, 50, (0.3 * lat * at * alpha), (1 + (random_range(-0.1, 0))))
        }
        else
            scrsound(snanvil, 50, (0.3 * lat * at * alpha), (1 + (random_range(-0.1, 0))))
        timer1 = 1
    }
    else if (image_index > 4)
        timer1 = 0
}
if (state == 3)
{
    work = 1
    dir = 0
    sprite_index = sbsw1
    image_speed = 0.1
}
