function scrseasonmap(argument0) //gml_Script_scrseasonmap
{
    if (argument0 == 7 || argument0 == 8 || argument0 == 33 || argument0 == 5 || argument0 == 6)
        return 0;
    if (argument0 == 4 || argument0 == 4 || argument0 == 1 || argument0 == 11 || argument0 == 54 || argument0 == 2 || argument0 == 41 || argument0 == 44 || argument0 == 28 || argument0 == 12 || argument0 == 19 || argument0 == 42)
        return 1;
    if (argument0 == 27 || argument0 == 32 || argument0 == 25 || argument0 == 47 || argument0 == 17 || argument0 == 15 || argument0 == 34 || argument0 == 50 || argument0 == 40 || argument0 == 3 || argument0 == 49 || argument0 == 23)
        return 2;
    if (argument0 == 16 || argument0 == 38 || argument0 == 58 || argument0 == 37 || argument0 == 29 || argument0 == 24 || argument0 == 13 || argument0 == 22 || argument0 == 30 || argument0 == 46 || argument0 == 31 || argument0 == 21 || argument0 == 14 || argument0 == 36 || argument0 == 65)
        return 3;
    if (argument0 == 74 || argument0 == 72 || argument0 == 73 || argument0 == 78 || argument0 == 63 || argument0 == 76 || argument0 == 64 || argument0 == 75 || argument0 == 53 || argument0 == 77 || argument0 == 56)
        return 4;
    if (argument0 == 60)
        return 5;
    return -1;
}

