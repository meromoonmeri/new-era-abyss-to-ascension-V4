if (watershad != -4)
{
    if layer_exists("watershad")
    {
        var shad = layer_sprite_create("watershad", x, y, watershad)
        layer_sprite_xscale(shad, image_xscale)
        watershad = -4
    }
}
