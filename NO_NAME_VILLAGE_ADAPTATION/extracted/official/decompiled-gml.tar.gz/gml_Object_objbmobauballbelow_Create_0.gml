depth = layer_get_depth("watershad") + 1
image_alpha = 0
creator = -4
