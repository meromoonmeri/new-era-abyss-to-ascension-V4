if (particlecheck == 0)
{
    particlecheck = 1
    if (sprite_index == sbmobaubeslow)
    {
        part_type_sprite(pt0, 1870, 0, 0, 0)
        part_type_sprite(pt1, 1193, 0, 0, 0)
    }
}
if (timer > 0)
    timer -= 1
else if (alpha > 0)
    alpha -= 0.016666666666666666
else
    instance_destroy()
