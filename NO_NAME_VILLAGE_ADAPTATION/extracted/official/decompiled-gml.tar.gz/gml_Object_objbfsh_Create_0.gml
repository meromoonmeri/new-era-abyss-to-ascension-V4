unitimer = shader_get_uniform(shblueforest, "timer")
