function scrtrail(argument0, argument1, argument2, argument3, argument4) //gml_Script_scrtrail
{
    var splash = instance_create_layer(argument0, argument1, "shadows", objtrail)
    splash.trail = argument2
    splash.image_index = argument3
    splash.tvolume = argument4
    splash.creator = self
}

