function scrinteractflora() //gml_Script_scrinteractflora
{
    var floralist = ds_list_create()
    var floranumber = instance_place_list(x, y, 333, floralist, false)
    if (floranumber > 0)
    {
        for (var i = 0; i < floranumber; i++)
        {
            with (ds_list_find_value(floralist, i))
            {
                if (!variable_global_exists("ptdandelion"))
                    global.ptdandelion = -1
                if (sprite_index == ssmbplant04)
                {
                    sprite_index = ssmbplant06
                    if (global.ptdandelion != -1)
                        part_particles_create(global.psdandelion, x, (y - 40), global.ptdandelion, 2)
                }
                if (sprite_index == ssmbplant05)
                {
                    sprite_index = ssmbplant07
                    if (global.ptdandelion != -1)
                        part_particles_create(global.psdandelion, x, (y - 32), global.ptdandelion, 2)
                }
            }
        }
    }
    ds_list_destroy(floralist)
}

