event_inherited()
if (state == -1)
{
    dir = 0
    scrnpcspawn(x, y, objbmobwn2e)
    if (timerev == 0)
    {
        sprite_index = sbmobwn2e0
        if (image_index < 1)
            image_speed = 0.1
        else
            image_speed = 0.1
    }
    else if (timerev == 1)
    {
        sprite_index = sbmobwn2e0
        image_speed = 0
        image_index = 0
    }
    else if (timerev == 2)
    {
        sprite_index = sbmobwn2e1
        if (image_index < (image_number - image_speed * 2))
            image_speed = 0.1
        else
            image_speed = 0
    }
    else if (timerev == 3)
    {
        sprite_index = sbmobwn2e2
        if (image_index < 6)
            image_speed = 0.2
        else if (image_index < (image_number - image_speed * 2))
            image_speed = 0.05
        else
        {
            state = 0
            pattern = -2
            image_speed = 0
        }
    }
}
if (state == 0)
{
    if (pattern < 0)
    {
        sprite_index = sbmobwn2i0
        ptimer = 1 + (1 - hp / maxhp) * 4
        pattern += (ptimer / 60)
    }
    else if (pattern < 1)
    {
        dir = idir
        if (instance_number(objbmobwn2sp) < 8)
            pattern = choose(1, 2, 3)
        else
            pattern = choose(1, 2)
    }
    if (pattern == 1)
    {
        if (timer1 == 0)
        {
            timer1 = 1
            state = 2
        }
        else if (timer1 == 1)
        {
            timer1 = 2
            curve = choose(-1, 1)
            dir = point_direction(x, y, 2248, 1904)
            movex = x + (lengthdir_x(640, dir))
            movey = y + (lengthdir_y(640, dir))
            dist = point_distance(x, y, (x + (lengthdir_x(640, dir))), (y + (lengthdir_y(640, dir))))
            state = 1
        }
        else if (timer1 == 2)
        {
            timer1 = 3
            state = 3
        }
        else
            pattern = -1
    }
    else
        timer1 = 0
    if (pattern == 2)
    {
        if (timer2 == 0)
        {
            timer2 = 1
            state = 4
        }
        else
            pattern = -1
    }
    else
        timer2 = 0
    if (pattern == 3)
    {
        if (timer3 == 0)
        {
            timer3 = 1
            state = 5
        }
        else
            pattern = -1
    }
    else
        timer3 = 0
    if (pattern == 4)
    {
        if (timer4 == 0)
        {
            timer4 = 1
            state = 2
        }
        else if (timer4 == 1)
        {
            timer4 = 2
            movex = lengthdir_x(640, dir)
            movey = lengthdir_y(640, dir)
            state = 6
        }
        else if (timer4 == 2)
        {
            timer4 = 3
            state = 3
        }
        else
            pattern = -1
    }
    else
        timer4 = 0
    if (pattern == 5)
    {
        if (timer5 == 0)
        {
        }
    }
    else
        timer5 = 0
}
if (state == 1)
{
    sprite_index = sbmobwn2m0
    scrmovcol(spd, (dir + curve * (60 - timer1s) * 2))
    firet += 1
    if ((firet % 15) == 0)
    {
        if (spd > 4)
        {
            firet = 0
            var rdir = dir + (irandom_range(-60, 60))
            instance_create_layer((x + (lengthdir_x(((-spd) * 8), rdir))), (y + (lengthdir_y(((-spd) * 8), rdir))), "instances", objfire)
        }
    }
    if (timer1s < 60)
    {
        timer1s += 1
        var pcol = instance_place(x, y, player)
        if (pcol != noone && objplayer.iframe <= 0)
        {
            objplayer.hp -= 1
            pcol.state = 6
            pcol.dir = scrdir(pcol, objbmobwn2)
            pcol.caninput = false
            pcol.image_index = 0
            objplayerview.shaket = 16
        }
        if (point_distance(x, y, movex, movey) > 32)
            spd = clamp((spd + 0.2), 0, 12)
        else
            timer1s = 60
    }
    else if (spd > 0)
        spd -= 0.25
    else
    {
        harmor = 0
        state = 0
    }
}
else
    timer1s = 0
if (state == 2)
{
    sprite_index = sbmobwn2d0
    if (image_index > 2 && image_index <= (2 + image_speed))
    {
        objplayerview.shaket = 8
        pcol = instance_place(x, y, player)
        if (pcol != noone && objplayer.iframe <= 0)
        {
            objplayer.hp -= 1
            pcol.state = 6
            pcol.dir = scrdir(pcol, objbmobwn2)
            pcol.caninput = false
            pcol.image_index = 0
            objplayerview.shaket = 16
        }
    }
    if (image_index < 3)
        image_speed = 0.2
    else if (image_index < (image_number - image_speed))
        image_speed = 0.05
    else
    {
        image_speed = 0
        harmor = 0
        state = 0
    }
}
if (state == 3)
{
    sprite_index = sbmobwn2u0
    if (image_index < (image_number - image_speed))
        image_speed = 0.2
    else
    {
        image_speed = 0
        harmor = 0
        state = 0
    }
}
if (state == 4)
{
    sprite_index = sbmobwn2sh0
    if (image_index < 6)
        image_speed = 0.2
    else if (image_index < (image_number - image_speed))
    {
        if (image_index >= timer4s)
        {
            timer4s += 0.5
            rdir = irandom_range(-60, 60)
            var proj1 = instance_create_layer((x + (lengthdir_x(64, (idir + rdir)))), (y + (lengthdir_x(32, (idir + rdir)))), "instances", objbmobwn2p)
            proj1.movex = objplayer.x + (lengthdir_x(128, irandom(360)))
            proj1.movey = objplayer.y + (lengthdir_y(64, irandom(360)))
            proj1.height = 128 + (irandom_range(0, 64))
        }
    }
    else
    {
        image_speed = 0
        harmor = 0
        state = 0
    }
}
else
    timer4s = 6
if (state == 5)
{
    sprite_index = sbmobwn2sp0
    if (image_index < 5)
        image_speed = 0.2
    else if (image_index < 7.2)
    {
        if (image_index >= timer5s)
        {
            timer5s += 0.5
            instance_create_layer((x + (lengthdir_x(64, irandom(360)))), (y + (lengthdir_y(32, irandom(360)))), "instances", objbmobwn2spp)
        }
    }
    else if (image_index < 8)
        image_speed = 0.05
    else if (image_index < (image_number - image_speed))
        image_speed = 0.2
    else
    {
        image_speed = 0
        harmor = 0
        state = 0
    }
}
else
    timer5s = 5
if (state == 6)
    sprite_index = sbmobwn2i0
if (hit != 0)
{
    hp -= (hit + hit * (max(0, (objplayer.weaponlvl - 1))) * 0.5)
    flash = 1
    objplayerview.shaket = 8
    if (hp > 0)
    {
        if (harmor == 0)
        {
            harmor = 1
            dir = idir
            image_index = 0
            spd = -4
            state = 7
        }
    }
    else if (state != 8)
    {
        dir = idir
        image_index = 0
        spd = -4
        var head = instance_create_layer(x, y, "instances", objbmobwn20)
        head.dir = scrdir(objplayer, self)
        state = 8
    }
}
if (state == 7)
{
    sprite_index = sbmobwn2h0
    scrmovcol(spd, dir)
    if (spd < 0)
        spd += 0.2
    if (image_index < (image_number - image_speed))
        image_speed = 0.2
    else
    {
        pattern = 0
        state = 0
    }
}
if (state == 8)
{
    with (objbmobwn2sp)
        state = 2
    sprite_index = sbmobwn2d00
    if (image_index < 4)
        image_speed = 0.2
    else if (image_index < 6)
    {
        if (timer8s != 1)
        {
            timer8s = 1
            objplayerview.shaket = 8
        }
    }
    else if (image_index < (image_number - image_speed * 2))
    {
        if (timer8s != 0)
        {
            timer8s = 0
            objplayerview.shaket = 6
        }
    }
    else
        image_speed = 0
}
else
    timer8s = 0
if (cling > 0)
{
    objplayer.candodge = false
    if (cling > 6)
        cling = 6
    if (cling <= 2)
    {
        objplayer.canrun = false
        objplayer.canmove = true
    }
    else if (cling <= 4)
    {
        objplayer.canrun = false
        objplayer.canmove = true
        objplayer.slow = 2
    }
    else
    {
        objplayer.canrun = false
        objplayer.canmove = false
    }
    if (scrinput("runp") || state == 8)
    {
        objplayerview.shaket = 8
        if (cling > 1)
            cling -= 1
        else
        {
            objplayer.canrun = true
            objplayer.canmove = true
            objplayer.candodge = true
            objplayer.slow = 1
            cling = 0
        }
    }
}
