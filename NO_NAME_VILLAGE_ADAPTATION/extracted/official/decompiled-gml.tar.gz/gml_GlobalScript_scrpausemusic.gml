function scrpausemusic(argument0) //gml_Script_scrpausemusic
{
    if (argument0 > 0)
    {
        if (ds_list_find_value(global.bgm, 0) != 198)
        {
            ds_list_insert(global.bgm, 0, 198)
            ds_list_insert(global.bgm, 1, 198)
        }
    }
    else if (ds_list_find_value(global.bgm, 0) == 198 || ds_list_find_value(global.bgm, 1) == 198)
    {
        with (objaudio)
            newroom = 1
    }
}

