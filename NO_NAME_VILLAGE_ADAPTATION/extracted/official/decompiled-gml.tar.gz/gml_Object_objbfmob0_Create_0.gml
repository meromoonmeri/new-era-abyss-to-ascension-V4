state = 0
