function scrptdust0(argument0, argument1, argument2, argument3, argument4) //gml_Script_scrptdust0
{
    var vford = 0
    if variable_instance_exists(id, "ford")
        vford = ford
    if (vford <= 0)
    {
        var scrpt1 = part_type_create()
        var scrpt2 = part_type_create()
        if (!variable_global_exists("psdust0"))
            global.psdust0 = -1
        if (!variable_global_exists("psdust0shad"))
            global.psdust0shad = -1
        if (global.psdust0 == -1)
        {
            global.psdust0 = part_system_create()
            part_system_depth(global.psdust0, (layer_get_depth("shadows") - 2))
        }
        if (global.psdust0shad == -1)
        {
            global.psdust0shad = part_system_create()
            part_system_depth(global.psdust0shad, layer_get_depth("shadows"))
        }
        for (var i = 0; i < 360; i += (360 / argument4))
        {
            part_type_sprite(scrpt1, argument2, 0, 0, 1)
            part_type_sprite(scrpt2, 929, 0, 0, 1)
            part_type_alpha3(scrpt1, 0.2, 0.1, 0)
            part_type_alpha3(scrpt2, 0.1, 0.05, 0)
            part_type_size(scrpt1, 0.8, 0.8, 0.01, 0)
            part_type_size(scrpt2, 0.8, 0.8, 0.01, 0)
            part_type_life(scrpt1, 30, 40)
            part_type_life(scrpt2, 30, 40)
            if (i < 180)
                var ptspd = argument3 / 2 + (abs(angle_difference(i, 90))) * (argument3 / 2) / 180
            else
                ptspd = argument3 / 2 + (abs(angle_difference(i, 270))) * (argument3 / 2) / 180
            part_type_speed(scrpt1, ptspd, ptspd, ((-argument3) / 30), 0)
            part_type_speed(scrpt2, ptspd, ptspd, ((-argument3) / 30), 0)
            part_type_direction(scrpt1, i, i, 0, 0)
            part_type_direction(scrpt2, i, i, 0, 0)
            part_particles_create(global.psdust0, argument0, argument1, scrpt1, 1)
            part_particles_create(global.psdust0shad, argument0, argument1, scrpt2, 1)
        }
    }
}

