noenter = false
block[0][0] = 0
block[0][1] = 0
blockcount = 0
timer = 0
timertt = 0
text[0] = 0
update = true
