function refl_water_object(argument0) //gml_Script_refl_water_object
{
    ds_list_add(global.water_insts, argument0)
}

