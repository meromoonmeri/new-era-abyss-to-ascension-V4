function scrslowdir(argument0) //gml_Script_scrslowdir
{
    var idir = scrdir(self, objplayerview.player)
    var ad = angle_difference(dir, idir)
    dir -= ((min(abs(ad), argument0)) * sign(ad))
}

