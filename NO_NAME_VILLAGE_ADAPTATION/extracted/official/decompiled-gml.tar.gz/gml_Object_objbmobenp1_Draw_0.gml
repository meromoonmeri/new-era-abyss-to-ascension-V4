if (height != 0)
{
    draw_sprite(sprite_index, image_index, x, (y - height))
    draw_sprite(sbmobenp, charge, x, (y - height))
}
