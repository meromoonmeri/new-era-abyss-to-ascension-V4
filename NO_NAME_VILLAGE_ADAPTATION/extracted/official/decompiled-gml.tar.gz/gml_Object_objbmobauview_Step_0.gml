var player = objplayerview.player
if (!instance_exists(objbmobau))
    instance_destroy()
else if (objbmobau.hp <= 0)
    instance_destroy()
else if (objbmobau.state >= 0 && objplayer.boss == 555)
{
    objplayerview.target = 555
    maxhp = objbmobau.maxhp
    hp = objbmobau.hp
    if (objbmobau.alpha == 0)
        delay = 30
    if (pcatch == false)
    {
        if (delay > 0)
        {
            delay -= 1
            spd = clamp((spd * 0.5), 0, 15)
        }
        else
        {
            var maxview = 320
            var targdist = scrdist(player, objbmobau)
            var targdir = scrdir(player, objbmobau)
            var targetx = player.x + (lengthdir_x(clamp((targdist / 3), 0, (maxview * 2)), targdir))
            var targety = player.y + (lengthdir_y(clamp((targdist / 3), 0, maxview), targdir))
            var viewdist = point_distance(x, y, targetx, targety)
            dir = point_direction(x, y, targetx, targety)
            if (viewdist > 4)
            {
                if (spd < 1)
                    spd = 1
                else
                    spd = viewdist / 15
            }
            else
                spd += ((-spd) / 5)
            x += lengthdir_x(spd, dir)
            y += lengthdir_y(spd, dir)
        }
    }
    else
        scrobjview(objbmobauview, objbmobauview, 50)
}
else
{
    objplayerview.target = 555
    dir = scrdir(objbmobauview, objbmobau)
    if (delay > 0)
    {
        delay -= 1
        spd = clamp((spd - 0.4), 0, 64)
    }
    else if (point_distance(x, y, 2816, 640) > 320)
        spd = clamp((spd + 1), 0, 64)
    else
    {
        spd = clamp((spd - 1), 0, 30)
        if (objbmobau.state >= 0)
        {
            delay = 30
            spd = 0
            objplayer.boss = 555
        }
    }
    x += lengthdir_x(spd, dir)
    y += lengthdir_y(spd, dir)
}
