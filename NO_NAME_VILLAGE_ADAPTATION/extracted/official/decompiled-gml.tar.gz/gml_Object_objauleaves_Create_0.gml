depth = layer_get_depth("shadows") + 4
autumnleaves = surface_create((room_width / 4), (room_height / 4))
sautumnleaves = 667
draw = false
parttimer = 0
part_system = part_system_create()
part_system_depth(part_system, (-room_height))
pt = part_type_create()
part_type_sprite(pt, 1047, 1, 1, 1)
part_type_size(pt, 3, 4, -0.0005, 0)
part_type_alpha3(pt, 0.5, 1, 0)
part_type_speed(pt, 3, 4, -0.01, 0)
part_type_direction(pt, 230, 230, -0.3, 0)
part_type_orientation(pt, 0, 360, -2, 0, 1)
part_type_life(pt, (game_get_speed(gamespeed_fps) * 3), (game_get_speed(gamespeed_fps) * 5))
