with (objplayerview)
    target = other
if keyboard_check_pressed(ord("1"))
{
    state = 0
    image_index = 0
}
if keyboard_check_pressed(ord("2"))
{
    state = 1
    image_index = 0
    dir = irandom(360)
}
if keyboard_check_pressed(ord("3"))
{
    state = 2
    image_index = 0
}
if keyboard_check_pressed(ord("4"))
    dir = point_direction(x, y, mouse_x, mouse_y)
if keyboard_check_pressed(ord("5"))
    image_alpha = 1 - image_alpha
if (dir < 0)
    dir += 360
else if (dir > 360)
    dir -= 360
if (dir > 90 && dir <= 270)
    image_xscale = -1
else
    image_xscale = 1
if (state == 0)
{
    if (dir >= 0 && dir < 60)
        sprite_index = smobsm0i3
    else if (dir >= 60 && dir < 120)
        sprite_index = smobsm0i4
    else if (dir >= 120 && dir < 180)
        sprite_index = smobsm0i3
    else if (dir >= 180 && dir < 240)
        sprite_index = smobsm0i1
    else if (dir >= 240 && dir < 300)
        sprite_index = smobsm0i0
    else
        sprite_index = smobsm0i1
    image_speed = 0.05
    spd += ((-spd) / 12)
    scrmovcol(spd, dir)
}
if (state == 1)
{
    if (dir >= 0 && dir < 60)
        sprite_index = smobsm0i3
    else if (dir >= 60 && dir < 120)
        sprite_index = smobsm0i4
    else if (dir >= 120 && dir < 180)
        sprite_index = smobsm0i3
    else if (dir >= 180 && dir < 240)
        sprite_index = smobsm0i1
    else if (dir >= 240 && dir < 300)
        sprite_index = smobsm0i0
    else
        sprite_index = smobsm0i1
    if (image_index < 1)
    {
        image_speed = 0.1
        spd += ((1 - spd) / 12)
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.2
        spd += ((3 - spd) / 4)
    }
    else
    {
        state = 0
        image_index = 0
    }
    scrmovcol1(spd, dir)
}
if (state == 2)
{
    if (dir >= 0 && dir < 60)
        sprite_index = smobsm0j3
    else if (dir >= 60 && dir < 120)
        sprite_index = smobsm0j4
    else if (dir >= 120 && dir < 180)
        sprite_index = smobsm0j3
    else if (dir >= 180 && dir < 240)
        sprite_index = smobsm0j1
    else if (dir >= 240 && dir < 300)
        sprite_index = smobsm0j0
    else
        sprite_index = smobsm0j1
    if (image_index < 3)
        image_speed = 0.2
    else if (image_index < 4)
    {
        image_index = 3.5
        image_speed = 0
        if (scrdist(objplayerview.player, self) < 192)
        {
            image_index = 0
            state = 3
        }
    }
}
if (state == 3)
{
    sprite_index = smobsm0aa
    if (image_index < 3)
    {
        image_speed = 0.1
        flash = image_index / 3 * 0.8
    }
    else if (flash > 0.7)
    {
        flash = 0.7
        objplayerview.shaket = 8
        scrsound(snmobsm02, 50, 1, 1)
        mask_index = smobsm0sw
        part_particles_create(ps, x, y, pt, 30)
        part_particles_create(ps, x, y, pt1, 1)
        scrinteractflora()
    }
    else
    {
        flash -= 0.05
        if (image_index < 4)
            image_speed = 0.2
        else if (image_index < 5)
            image_index = 5
        else if (image_index < (image_number - image_speed))
            image_speed = 0.016666666666666666
        else
            state = 0
    }
}
