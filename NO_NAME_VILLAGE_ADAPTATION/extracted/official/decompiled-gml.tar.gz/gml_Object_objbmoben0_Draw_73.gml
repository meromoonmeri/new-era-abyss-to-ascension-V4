if (state != 5)
{
    if (sprite_index == sbmoben1 || sprite_index == sbmoben12)
        draw_self()
    else
        draw_sprite_ext(sprite_index, image_index, (x + 78), (y - 376), facing, 1, 0, -1, 1)
}
if (flash > 0)
{
    shader_set(shflash)
    draw_sprite_ext(sprite_index, image_index, rmx, rmy, facing, 1, 0, c_white, flash)
    draw_sprite_ext(sbmoben0, 0, rmx, rmy, 1, 1, 0, c_white, flash)
    shader_reset()
}
