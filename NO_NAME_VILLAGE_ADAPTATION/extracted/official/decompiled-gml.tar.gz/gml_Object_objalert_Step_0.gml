if (creator != noone)
{
    if instance_exists(creator)
    {
        depth = (-creator.y) - 4
        x = creator.x - xoffset
        y = creator.y - yoffset
    }
}
if (image_index > (image_number - 1))
    image_speed = time
