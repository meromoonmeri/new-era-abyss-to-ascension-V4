event_inherited()
mob = -1
depth = layer_get_depth("bmobausink")
var back = instance_create_depth(x, y, (depth + 4), objbmobausink0)
back.creator = id
charge = 0
alpha = 0
worms = 0
wormst = 0
part_system = part_system_create()
part_system_depth(part_system, layer_get_depth("shadows"))
part_type = part_type_create()
part_step = part_type_create()
part_death = part_type_create()
part_type_sprite(part_type, 1747, 0, 0, 0)
part_type_speed(part_type, 0.8, 4, 0, 0)
part_type_direction(part_type, 50, 130, 0, 0)
part_type_gravity(part_type, 0.4, 270)
part_type_life(part_type, 10, 10)
part_type_step(part_type, -2, part_step)
part_type_death(part_type, 1, part_death)
part_type_sprite(part_step, 1747, 1, 1, 0)
part_type_life(part_step, 10, 10)
part_type_sprite(part_death, 1302, 1, 1, 0)
part_type_alpha3(part_death, 1, 0.5, 0)
part_type_life(part_death, 10, 10)
