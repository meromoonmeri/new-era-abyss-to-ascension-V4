depth = (-room_height) * 4
if (maxvelheight == -1)
    maxvelheight = velheight
if (shoot == 0)
{
    charge = velheight * 5 / maxvelheight - 1
    height += velheight
    if (velheight > 1)
    {
        velheight -= (1/30)
        x += lengthdir_x(spd, dir)
        y += lengthdir_y(spd, dir)
    }
    else
        shoot = 1
}
else if (stack < 14)
{
    image_speed = 0
    charge = (14 - stack) * 5 / 14
    if (stack == 0)
    {
        with (objplayer)
        {
            var p = instance_create_layer((x + (lengthdir_x(spd, dir))), (y + (lengthdir_y(spd, dir))), "instances", objbmobenp)
            p.startx = other.x
            p.starty = other.y
            p.startz = other.height
        }
    }
    if (timer < 1)
        timer += 1
    else
    {
        timer = 0
        stack += 1
        repeat (2)
        {
            var rdir = irandom(360)
            var rdist = irandom(64 * stack)
            p = instance_create_layer((objplayer.x + (lengthdir_x(rdist, rdir))), (objplayer.y + (lengthdir_y((rdist / 2), rdir))), "instances", objbmobenp)
            p.startx = x + (choose(((-stack) * 2), (stack * 2)))
            p.starty = y + (choose(((-stack) * 2), (stack * 2)))
            p.startz = height + (choose(((-stack) * 2), (stack * 2)))
        }
    }
}
else
    instance_destroy()
