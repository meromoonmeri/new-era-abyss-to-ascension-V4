function refl_water_layer(argument0, argument1) //gml_Script_refl_water_layer
{
    global.water_tile = argument0
    global.water_detection = argument1
}

