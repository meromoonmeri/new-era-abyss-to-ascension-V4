image_xscale = 4
image_yscale = 4
image_alpha = 0
testx = x
testy = y
testa = image_alpha
testd = 0
state = 0
