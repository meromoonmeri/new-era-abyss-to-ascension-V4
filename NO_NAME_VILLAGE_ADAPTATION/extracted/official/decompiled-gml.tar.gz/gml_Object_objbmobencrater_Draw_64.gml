if (state == 0)
{
    var cx = camera_get_view_x(view_camera[0])
    var cy = camera_get_view_y(view_camera[0])
    draw_sprite_ext(sprite_index, image_index, (x - cx), (y - cy), image_xscale, image_yscale, 0, -1, image_alpha)
    draw_sprite_ext(sbmobenend31, image_index, (x - cx + objrm53.hit * 16), (y - cy), image_xscale, image_yscale, 0, -1, image_alpha)
}
