function screxplripple(argument0, argument1, argument2, argument3, argument4, argument5) //gml_Script_screxplripple
{
    var ripple = instance_create_depth(argument0, argument1, (depth + 4), objripples)
    if layer_exists(argument2)
        ripple = instance_create_layer(argument0, argument1, argument2, objripples)
    ripple.x = argument0
    ripple.y = argument1
    ripple.sprite_index = argument3
    ripple.maxsize = argument4 * argument5
    ripple.scale = argument5
}

