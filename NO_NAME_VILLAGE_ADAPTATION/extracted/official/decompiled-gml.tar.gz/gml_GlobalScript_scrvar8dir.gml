function scrvar8dir(argument0, argument1, argument2, argument3, argument4, argument5) //gml_Script_scrvar8dir
{
    if (argument0 >= 22.5 && argument0 < 67.5)
        return argument5;
    else if (argument0 >= 112.5 && argument0 < 157.5)
        return argument4;
    else if (argument0 >= 157.5 && argument0 < 202.5)
        return argument3;
    else if (argument0 >= 202.5 && argument0 < 247.5)
        return argument2;
    else if (argument0 >= 247.5 && argument0 < 292.5)
        return argument1;
    else if (argument0 >= 292.5 && argument0 < 337.5)
        return argument2;
    else
        return argument3;
}

