if surface_exists(blacksea)
    draw_surface(blacksea, 0, 0)
