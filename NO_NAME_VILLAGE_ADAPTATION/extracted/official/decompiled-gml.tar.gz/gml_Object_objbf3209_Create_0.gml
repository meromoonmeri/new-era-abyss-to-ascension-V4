event_inherited()
layer_sprite_create("watershad", x, y, 1309)
