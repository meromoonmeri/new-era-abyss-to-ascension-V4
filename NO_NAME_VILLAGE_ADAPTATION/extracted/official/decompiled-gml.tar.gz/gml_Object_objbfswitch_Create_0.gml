depth = (-room_height)
start = false
event = 0
alpha = 1
alphat = 0
alphatt = -0.03333333333333333
if layer_exists("blueforest")
    layer_set_visible("blueforest", true)
