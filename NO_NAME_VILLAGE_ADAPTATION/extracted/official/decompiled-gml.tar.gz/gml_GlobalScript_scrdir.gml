function scrdir(argument0, argument1) //gml_Script_scrdir
{
    if (instance_exists(argument0) && instance_exists(argument1))
    {
        var dir = point_direction(argument0.x, argument0.y, argument1.x, argument1.y)
        return dir;
    }
}

