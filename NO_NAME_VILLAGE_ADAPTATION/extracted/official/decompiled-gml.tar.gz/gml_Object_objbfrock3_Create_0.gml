event_inherited()
if layer_exists("watershad")
    layer_sprite_create("watershad", x, y, 956)
