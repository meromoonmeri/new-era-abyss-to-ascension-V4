var vttcx = 0
var vttcy = 0
if (facing == 1)
{
    vttcx = x - sprite_xoffset + ttcx * 4
    vttcy = y - sprite_yoffset + ttcy * 4
}
else
{
    vttcx = x - sprite_xoffset + sprite_width - ttcx * 4
    vttcy = y - sprite_yoffset + ttcy * 4
}
if (point_distance(ttcprevx, ttcprevy, vttcx, (vttcy - z)) > 0)
{
    var ttspd = (point_distance(ttcprevx, ttcprevy, vttcx, (vttcy - z))) / 8
    var ttdir = point_direction(ttcprevx, ttcprevy, vttcx, (vttcy - z))
    ttcprevx += lengthdir_x(ttspd, ttdir)
    ttcprevy += lengthdir_y(ttspd, ttdir)
}
if (state == -1)
{
    ttcx = 75
    ttcy = 69
}
if (state == 0)
{
    if (sprite_index == sbmobwn2i0)
    {
        tthoriz = 0
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 75
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 75
            ttcy = 70
        }
        else
        {
            ttcx = 75
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2i1)
    {
        tthoriz = 1
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 76
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 76
            ttcy = 70
        }
        else
        {
            ttcx = 76
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2i2)
    {
        tthoriz = 2
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 77
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 77
            ttcy = 70
        }
        else
        {
            ttcx = 77
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2i3)
    {
        tthoriz = 1
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 76
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 76
            ttcy = 70
        }
        else
        {
            ttcx = 76
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2i4)
    {
        tthoriz = 0
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 74
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 74
            ttcy = 70
        }
        else
        {
            ttcx = 74
            ttcy = 70
        }
    }
}
if (state == 1)
{
    if (sprite_index == sbmobwn2r0)
    {
        tthoriz = 0
        if (image_index < 1)
        {
            ttcx = 75
            ttcy = 73
            ttvert = 0
            ttangle = 0
        }
        else if (image_index < 2)
        {
            ttcx = 75
            ttcy = 76
            ttvert = 1
            ttangle = 0
        }
        else if (image_index < 3)
        {
            ttcx = 75
            ttcy = 88
            ttvert = 2
            ttangle = 0
        }
        else
        {
            ttcx = 75
            ttcy = 74
            ttvert = 1
            ttangle = 0
        }
    }
    if (sprite_index == sbmobwn2r1)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 78
            ttcy = 74
            ttvert = 0
            ttangle = 0
        }
        else if (image_index < 2)
        {
            ttcx = 79
            ttcy = 76
            ttvert = 1
            ttangle = 0
        }
        else if (image_index < 3)
        {
            ttcx = 84
            ttcy = 87
            ttvert = 2
            ttangle = 0
        }
        else
        {
            ttcx = 78
            ttcy = 73
            ttvert = 1
            ttangle = 0
        }
    }
    if (sprite_index == sbmobwn2r2)
    {
        tthoriz = 2
        if (image_index < 1)
        {
            ttcx = 78
            ttcy = 74
            ttvert = 0
            ttangle = 0
        }
        else if (image_index < 2)
        {
            ttcx = 82
            ttcy = 77
            ttvert = 1
            ttangle = 0
        }
        else if (image_index < 3)
        {
            ttcx = 88
            ttcy = 86
            ttvert = 2
            ttangle = 0
        }
        else
        {
            ttcx = 80
            ttcy = 76
            ttvert = 1
            ttangle = 0
        }
    }
    if (sprite_index == sbmobwn2r3)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 78
            ttcy = 74
            ttvert = 0
            ttangle = 0
        }
        else if (image_index < 2)
        {
            ttcx = 80
            ttcy = 76
            ttvert = 1
            ttangle = 0
        }
        else if (image_index < 3)
        {
            ttcx = 86
            ttcy = 76
            ttvert = 2
            ttangle = 0
        }
        else
        {
            ttcx = 79
            ttcy = 72
            ttvert = 1
            ttangle = 0
        }
    }
    if (sprite_index == sbmobwn2r4)
    {
        tthoriz = 0
        if (image_index < 1)
        {
            ttcx = 74
            ttcy = 73
            ttvert = 0
            ttangle = 0
        }
        else if (image_index < 2)
        {
            ttcx = 74
            ttcy = 78
            ttvert = 1
            ttangle = 0
        }
        else if (image_index < 3)
        {
            ttcx = 74
            ttcy = 76
            ttvert = 2
            ttangle = 0
        }
        else
        {
            ttcx = 74
            ttcy = 73
            ttvert = 1
            ttangle = 0
        }
    }
    if (image_index > 2 && image_index < 3)
    {
        var facedir = round(dir / 45)
        facedir = facedir * 45
        if (facedir == 360)
            facedir = 0
        if ((global.time % 5) == 0)
        {
            part_system_depth(pssw, ((-y) - (lengthdir_y(32, facedir))))
            part_type_speed(ptsw, 2, 2, 0, 0)
            part_type_direction(ptsw, facedir, facedir, 0, 0)
            if (facedir == 90 || facedir == 270)
                part_type_scale(ptsw, 4, 4)
            else if (facedir == 0 || facedir == 180)
                part_type_scale(ptsw, 2, 4)
            else
                part_type_scale(ptsw, 3, 4)
            part_particles_create(psrr, (x + (lengthdir_x(80, facedir))), (y + (lengthdir_y(32, facedir)) - 24), ptsw, 1)
        }
        if ((global.time % 10) == 0)
            part_particles_create(pssw, x, y, ptsp, 1)
    }
}
if (state == 2)
{
    if (sprite_index == sbmobwn2w0)
    {
        tthoriz = 0
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 74
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 75
            ttcy = 69
        }
        else if (image_index < 3)
        {
            ttcx = 75
            ttcy = 68
        }
        else
        {
            ttcx = 74
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2w1)
    {
        tthoriz = 1
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 75
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 76
            ttcy = 69
        }
        else if (image_index < 3)
        {
            ttcx = 76
            ttcy = 68
        }
        else
        {
            ttcx = 74
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2w2)
    {
        tthoriz = 2
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 76
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 77
            ttcy = 69
        }
        else if (image_index < 3)
        {
            ttcx = 77
            ttcy = 68
        }
        else
        {
            ttcx = 75
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2w3)
    {
        tthoriz = 1
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 76
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 75
            ttcy = 69
        }
        else if (image_index < 3)
        {
            ttcx = 75
            ttcy = 68
        }
        else
        {
            ttcx = 76
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2w4)
    {
        tthoriz = 0
        ttvert = 0
        ttangle = 0
        if (image_index < 1)
        {
            ttcx = 75
            ttcy = 69
        }
        else if (image_index < 2)
        {
            ttcx = 74
            ttcy = 69
        }
        else if (image_index < 3)
        {
            ttcx = 74
            ttcy = 68
        }
        else
        {
            ttcx = 75
            ttcy = 70
        }
    }
}
if (state == 3)
{
    ttvert = 0
    ttangle = 0
    if (sprite_index == sbmobwn2sw0)
    {
        if (image_index < 1)
        {
            tthoriz = 0
            ttcx = 75
            ttcy = 74
        }
        else if (image_index < 2)
        {
            tthoriz = 0
            ttcx = 75
            ttcy = 77
        }
        else if (image_index < 3)
        {
            tthoriz = 0
            ttcx = 75
            ttcy = 90
            sptx = 42
            spty = 78
        }
        else if (image_index < 4)
        {
            tthoriz = 0
            ttcx = 76
            ttcy = 87
            spx = 42
            spy = 78
        }
        else if (image_index < 5)
        {
            tthoriz = 1
            ttcx = 78
            ttcy = 82
            spx = 28
            spy = 84
        }
        else if (image_index < 6)
        {
            tthoriz = 1
            ttcx = 78
            ttcy = 76
            spx = 24
            spy = 101
        }
        else if (image_index < 7)
        {
            tthoriz = 1
            ttcx = 78
            ttcy = 73
            spx = 74
            spy = 128
        }
        else if (image_index < 8)
        {
            tthoriz = 2
            ttcx = 75
            ttcy = 71
            spx = 120
            spy = 111
        }
        else if (image_index < 9)
        {
            tthoriz = 2
            ttcx = 75
            ttcy = 70
            spx = 119
            spy = 85
        }
        else if (image_index < 10)
        {
            tthoriz = 2
            ttcx = 74
            ttcy = 69
        }
        else
        {
            tthoriz = 1
            ttcx = 75
            ttcy = 68
        }
    }
    if (sprite_index == sbmobwn2sw1)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 78
            ttcy = 74
        }
        else if (image_index < 2)
        {
            ttcx = 79
            ttcy = 77
        }
        else
        {
            ttcx = 86
            ttcy = 85
        }
    }
    if (sprite_index == sbmobwn2sw2)
    {
        if (image_index < 1)
        {
            tthoriz = 2
            ttcx = 78
            ttcy = 74
        }
        else if (image_index < 2)
        {
            tthoriz = 2
            ttcx = 81
            ttcy = 77
        }
        else if (image_index < 3)
        {
            tthoriz = 2
            ttcx = 86
            ttcy = 78
            sptx = 47
            spty = 93
        }
        else if (image_index < 4)
        {
            tthoriz = 2
            ttcx = 84
            ttcy = 75
            spx = 47
            spy = 93
        }
        else if (image_index < 5)
        {
            tthoriz = 1
            ttcx = 83
            ttcy = 75
            spx = 47
            spy = 107
        }
        else if (image_index < 6)
        {
            tthoriz = 1
            ttcx = 82
            ttcy = 73
            spx = 78
            spy = 125
        }
        else if (image_index < 7)
        {
            tthoriz = 1
            ttcx = 78
            ttcy = 71
            spx = 132
            spy = 92
        }
        else if (image_index < 8)
        {
            tthoriz = 0
            ttcx = 76
            ttcy = 67
            spx = 113
            spy = 70
        }
        else if (image_index < 9)
        {
            tthoriz = 0
            ttcx = 75
            ttcy = 67
            spx = 84
            spy = 61
        }
        else if (image_index < 10)
        {
            tthoriz = 0
            ttcx = 76
            ttcy = 68
        }
        else
        {
            tthoriz = 1
            ttcx = 75
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2sw3)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 78
            ttcy = 74
        }
        else if (image_index < 2)
        {
            ttcx = 79
            ttcy = 76
        }
        else
        {
            ttcx = 82
            ttcy = 72
        }
    }
    if (sprite_index == sbmobwn2sw4)
    {
        if (image_index < 1)
        {
            tthoriz = 0
            ttcx = 74
            ttcy = 73
        }
        else if (image_index < 2)
        {
            tthoriz = 0
            ttcx = 74
            ttcy = 76
        }
        else if (image_index < 3)
        {
            tthoriz = 0
            ttcx = 74
            ttcy = 69
            sptx = 99
            spty = 85
        }
        else if (image_index < 4)
        {
            tthoriz = 0
            ttcx = 74
            ttcy = 70
            spx = 99
            spy = 85
        }
        else if (image_index < 5)
        {
            tthoriz = 1
            ttcx = 74
            ttcy = 73
            spx = 113
            spy = 91
        }
        else if (image_index < 6)
        {
            tthoriz = 1
            ttcx = 72
            ttcy = 71
            spx = 122
            spy = 80
        }
        else if (image_index < 7)
        {
            tthoriz = 1
            ttcx = 71
            ttcy = 70
            spx = 78
            spy = 53
        }
        else if (image_index < 8)
        {
            tthoriz = 2
            ttcx = 72
            ttcy = 70
            spx = 37
            spy = 61
        }
        else if (image_index < 9)
        {
            tthoriz = 2
            ttcx = 72
            ttcy = 69
            spx = 23
            spy = 87
        }
        else if (image_index < 10)
        {
            tthoriz = 2
            ttcx = 73
            ttcy = 69
        }
        else
        {
            tthoriz = 1
            ttcx = 74
            ttcy = 69
        }
    }
    if (image_index > 3 && image_index < 9)
    {
        var spdist = point_distance(sptx, spty, spx, spy)
        var spddir = point_direction(sptx, spty, spx, spy)
        spspd += ((spdist - spspd) / 2)
        var ad = (angle_difference(spdir, spddir)) / 1.03
        spdir -= ((min(abs(ad), 360)) * sign(ad))
        sptx += lengthdir_x(spspd, spdir)
        spty += lengthdir_y(spspd, spdir)
        if (facing == 1)
        {
            pdx = x - sprite_xoffset + sptx * 4
            pdy = y - sprite_yoffset + spty * 4
        }
        else
        {
            pdx = x - sprite_xoffset + sprite_width - sptx * 4
            pdy = y - sprite_yoffset + spty * 4
        }
        if (scrdistview(prevspx, prevspy, pdx, pdy) > 48)
        {
            prevspx = pdx
            prevspy = pdy
            instance_create_layer(pdx, pdy, "instances", objbmobwn2pd)
        }
        if (!instance_exists(objbmobwn2hbox))
            instance_create_layer(sptx, spty, "instances", objbmobwn2hbox)
        with (objbmobwn2hbox)
        {
            x = other.pdx
            y = other.pdy
            image_xscale = 1.4
            image_yscale = 1.4
            var hitdir = other.spdir + (angle_difference(other.spdir, ((scrdir(objplayer, other)) / 2)))
            var pcol = instance_place(x, y, objplayerview.player)
            var linehit = noone
            if collision_line(x, y, other.x, other.y, objplayerview.player, 1, 0)
                linehit = objplayerview.player
            if (other.image_index > 5)
            {
                if (pcol != noone)
                    scrhitplayer(pcol, 1, hitdir, 12)
                else if (linehit != noone)
                    scrhitplayer(linehit, 1, hitdir, 12)
            }
        }
    }
    else
        spdir = dir
}
if (state == 4)
{
    var slspx = 0
    var slspy = 0
    if (sprite_index == sbmobwn2sl0)
    {
        if (image_index < 1)
        {
            tthoriz = 0
            ttcx = 75
            ttcy = 77
        }
        else if (image_index < 2)
        {
            tthoriz = 0
            ttcx = 75
            ttcy = 85
        }
        else if (image_index < 3)
        {
            tthoriz = 0
            ttcx = 75
            ttcy = 69
        }
        else if (image_index < 4)
        {
            tthoriz = 1
            ttcx = 69
            ttcy = 69
        }
        else if (image_index < 5)
        {
            tthoriz = 1
            ttcx = 69
            ttcy = 75
        }
        else if (image_index < 6)
        {
            tthoriz = 2
            ttcx = 69
            ttcy = 82
        }
        else if (image_index < 7)
        {
            tthoriz = 2
            ttcx = 69
            ttcy = 83
        }
        else if (image_index < 8)
        {
            tthoriz = 2
            ttcx = 68
            ttcy = 87
        }
        else
        {
            tthoriz = 1
            ttcx = 69
            ttcy = 82
        }
        slspx = 72
        slspy = 122
        if (image_index < 7)
            hitsplash = 0
        else if (hitsplash == 0)
            hitsplash = 1
    }
    if (sprite_index == sbmobwn2sl1)
    {
        if (image_index < 1)
        {
            tthoriz = 1
            ttcx = 80
            ttcy = 77
        }
        else if (image_index < 2)
        {
            tthoriz = 1
            ttcx = 80
            ttcy = 84
        }
        else if (image_index < 8)
        {
            tthoriz = 1
            ttcx = 68
            ttcy = 88
        }
        else
        {
            tthoriz = 1
            ttcx = 70
            ttcy = 84
        }
        slspx = 106
        slspy = 114
        if (image_index < 7)
            hitsplash = 0
        else if (hitsplash == 0)
            hitsplash = 1
    }
    if (sprite_index == sbmobwn2sl2)
    {
        if (image_index < 1)
        {
            tthoriz = 2
            ttcx = 81
            ttcy = 77
        }
        else if (image_index < 2)
        {
            tthoriz = 2
            ttcx = 82
            ttcy = 82
        }
        else if (image_index < 3)
        {
            tthoriz = 2
            ttcx = 78
            ttcy = 68
        }
        else if (image_index < 4)
        {
            tthoriz = 1
            ttcx = 72
            ttcy = 71
        }
        else if (image_index < 5)
        {
            tthoriz = 1
            ttcx = 72
            ttcy = 73
        }
        else if (image_index < 6)
        {
            tthoriz = 0
            ttcx = 71
            ttcy = 78
        }
        else if (image_index < 7)
        {
            tthoriz = 0
            ttcx = 71
            ttcy = 80
        }
        else if (image_index < 8)
        {
            tthoriz = 0
            ttcx = 73
            ttcy = 89
        }
        else
        {
            tthoriz = 1
            ttcx = 73
            ttcy = 85
        }
        slspx = 121
        slspy = 95
        if (image_index < 7)
            hitsplash = 0
        else if (hitsplash == 0)
            hitsplash = 1
    }
    if (sprite_index == sbmobwn2sl3)
    {
        if (image_index < 1)
        {
            tthoriz = 1
            ttcx = 80
            ttcy = 76
        }
        else if (image_index < 2)
        {
            tthoriz = 1
            ttcx = 81
            ttcy = 79
        }
        else if (image_index < 8)
        {
            tthoriz = 1
            ttcx = 81
            ttcy = 89
        }
        else
        {
            tthoriz = 2
            ttcx = 79
            ttcy = 84
        }
        slspx = 103
        slspy = 66
        if (image_index < 7)
            hitsplash = 0
        else if (hitsplash == 0)
            hitsplash = 1
    }
    if (sprite_index == sbmobwn2sl4)
    {
        if (image_index < 1)
        {
            tthoriz = 0
            ttcx = 74
            ttcy = 76
        }
        else if (image_index < 2)
        {
            tthoriz = 0
            ttcx = 74
            ttcy = 81
        }
        else if (image_index < 3)
        {
            tthoriz = 0
            ttcx = 76
            ttcy = 69
        }
        else if (image_index < 4)
        {
            tthoriz = 1
            ttcx = 80
            ttcy = 70
        }
        else if (image_index < 5)
        {
            tthoriz = 1
            ttcx = 81
            ttcy = 73
        }
        else if (image_index < 6)
        {
            tthoriz = 2
            ttcx = 81
            ttcy = 76
        }
        else if (image_index < 7)
        {
            tthoriz = 2
            ttcx = 81
            ttcy = 78
        }
        else if (image_index < 8)
        {
            tthoriz = 2
            ttcx = 83
            ttcy = 86
        }
        else
        {
            tthoriz = 1
            ttcx = 80
            ttcy = 81
        }
        slspx = 76
        slspy = 57
        if (image_index < 7)
            hitsplash = 0
        else if (hitsplash == 0)
            hitsplash = 1
    }
    var slpdx = 0
    var slpdy = 0
    if (facing == 1)
    {
        slpdx = x - sprite_xoffset + slspx * 4
        slpdy = y - sprite_yoffset + slspy * 4
    }
    else
    {
        slpdx = x - sprite_xoffset + sprite_width - slspx * 4
        slpdy = y - sprite_yoffset + slspy * 4
    }
    pdx = slpdx
    pdy = slpdy
    if (hitsplash == 1)
    {
        hitsplash = 2
        instance_create_layer(slpdx, slpdy, "instances", objbmobwn2pdb)
        var pspd = random_range(4, 5)
        var rdir = choose(-1, 1)
        repeat (10)
        {
            var psdir = dir + rdir + (irandom_range(-10, 10))
            var psx = lengthdir_x((pspd * 12), psdir)
            var psy = lengthdir_y((pspd * 12), psdir)
            var projectile = instance_create_layer((slpdx + psx), (slpdy + psy), "instances", objbmobwn2p)
            projectile.dir = psdir
            projectile.spd = clamp((pspd + (random_range(-2, 2))), 2, 10)
            projectile.z = 72
            projectile.vel = irandom_range(6, 10)
            pspd = pspd * 9 / 10
            rdir = (-rdir) + 10 * sign((-rdir))
        }
        if (!instance_exists(objbmobwn2hbox))
            instance_create_layer(pdx, pdy, "instances", objbmobwn2hbox)
        with (objbmobwn2hbox)
        {
            x = other.pdx
            y = other.pdy
            image_xscale = 2.2
            image_yscale = 2.2
            scrptdust0(x, y, 463, 48, 64)
            pcol = instance_place(x, y, objplayerview.player)
            linehit = objbmobau_old
            if collision_line(x, y, other.x, other.y, objplayerview.player, 1, 0)
                linehit = objbmobwn2e_old
            if (pcol != noone)
                scrhitplayer(pcol, 1, scrdir(objplayerview.player, other), 12)
            else if (linehit != noone)
                scrhitplayer(linehit, 1, scrdir(objplayerview.player, other), 12)
        }
    }
}
if (state == 5)
{
    if (sprite_index == sbmobwn2st0)
    {
        tthoriz = 0
        if (image_index < 1)
        {
            ttcx = 76
            ttcy = 59
        }
        else if (image_index < 2)
        {
            ttcx = 76
            ttcy = 67
        }
        else if (image_index < 3)
        {
            ttcx = 75
            ttcy = 75
        }
        else
        {
            ttcx = 75
            ttcy = 72
        }
    }
    if (sprite_index == sbmobwn2st1)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 73
            ttcy = 61
        }
        else if (image_index < 2)
        {
            ttcx = 79
            ttcy = 67
        }
        else if (image_index < 3)
        {
            ttcx = 78
            ttcy = 81
        }
        else
        {
            ttcx = 78
            ttcy = 73
        }
    }
    if (sprite_index == sbmobwn2st2)
    {
        tthoriz = 2
        if (image_index < 1)
        {
            ttcx = 79
            ttcy = 60
        }
        else if (image_index < 2)
        {
            ttcx = 77
            ttcy = 66
        }
        else if (image_index < 3)
        {
            ttcx = 82
            ttcy = 71
        }
        else
        {
            ttcx = 78
            ttcy = 70
        }
    }
    if (sprite_index == sbmobwn2st3)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 71
            ttcy = 62
        }
        else if (image_index < 2)
        {
            ttcx = 75
            ttcy = 64
        }
        else if (image_index < 3)
        {
            ttcx = 80
            ttcy = 73
        }
        else
        {
            ttcx = 79
            ttcy = 72
        }
    }
    if (sprite_index == sbmobwn2st4)
    {
        tthoriz = 0
        if (image_index < 1)
        {
            ttcx = 74
            ttcy = 61
        }
        else if (image_index < 2)
        {
            ttcx = 74
            ttcy = 67
        }
        else if (image_index < 3)
        {
            ttcx = 74
            ttcy = 74
        }
        else
        {
            ttcx = 74
            ttcy = 71
        }
    }
}
if (state == 6)
{
    if (sprite_index == sbmobwn2h0)
    {
        tthoriz = 0
        if (image_index < 1)
        {
            ttcx = 75
            ttcy = 66
        }
        else if (image_index < 2)
        {
            ttcx = 75
            ttcy = 77
        }
        else
        {
            ttcx = 75
            ttcy = 74
        }
    }
    if (sprite_index == sbmobwn2h1)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 72
            ttcy = 66
        }
        else if (image_index < 2)
        {
            ttcx = 80
            ttcy = 77
        }
        else
        {
            ttcx = 78
            ttcy = 74
        }
    }
    if (sprite_index == sbmobwn2h2)
    {
        tthoriz = 2
        if (image_index < 1)
        {
            ttcx = 72
            ttcy = 65
        }
        else if (image_index < 2)
        {
            ttcx = 81
            ttcy = 77
        }
        else
        {
            ttcx = 78
            ttcy = 74
        }
    }
    if (sprite_index == sbmobwn2h3)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 70
            ttcy = 66
        }
        else if (image_index < 2)
        {
            ttcx = 80
            ttcy = 76
        }
        else
        {
            ttcx = 78
            ttcy = 73
        }
    }
    if (sprite_index == sbmobwn2h4)
    {
        tthoriz = 0
        if (image_index < 1)
        {
            ttcx = 74
            ttcy = 66
        }
        else if (image_index < 2)
        {
            ttcx = 74
            ttcy = 76
        }
        else
        {
            ttcx = 74
            ttcy = 73
        }
    }
}
if (state == 7)
{
    if (sprite_index == sbmobwn2d1)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 72
            ttcy = 66
        }
        else if (image_index < 2)
        {
            ttcx = 74
            ttcy = 69
        }
        else if (image_index < 3)
        {
            ttcx = 78
            ttcy = 74
        }
        else
        {
            ttcx = 76
            ttcy = 77
        }
    }
    if (sprite_index == sbmobwn2d3)
    {
        tthoriz = 1
        if (image_index < 1)
        {
            ttcx = 70
            ttcy = 66
        }
        else if (image_index < 2)
        {
            ttcx = 73
            ttcy = 66
        }
        else if (image_index < 3)
        {
            ttcx = 78
            ttcy = 73
        }
        else
        {
            ttcx = 75
            ttcy = 74
        }
    }
}
