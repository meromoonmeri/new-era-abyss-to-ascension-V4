function scraicoldir(argument0, argument1, argument2) //gml_Script_scraicoldir
{
    var maxcheck = 0
    var dirdist = clamp((argument0 - (point_distance(x, y, argument1, argument2))), 0, 360)
    var aidir = (point_direction(x, y, argument1, argument2)) + (random_range((-dirdist), dirdist))
    while (scrcolline(x, y, (x + (lengthdir_x((argument0 / 5), aidir))), (y + (lengthdir_y((argument0 / 5), aidir)))) && maxcheck < 10)
    {
        aidir = (point_direction(x, y, argument1, argument2)) + (random_range((-dirdist), dirdist))
        maxcheck += 1
    }
    return aidir;
}

