function scrcontroller() //gml_Script_scrcontroller
{
    if (scrremap() > -1)
        return 0;
    var maxpads = gamepad_get_device_count()
    for (var i = 0; i < maxpads; i++)
    {
        if gamepad_is_connected(i)
        {
            if gamepad_button_check(i, _key)
            {
                var desc = string_lower(gamepad_get_description(i))
                if (string_pos("wireless controller", desc) > 0 || string_pos("dualshock", desc) > 0 || string_pos("dual sense", desc) > 0 || string_pos("playstation", desc) > 0)
                    return 1;
                else
                    return 2;
            }
        }
    }
    return -1;
}

