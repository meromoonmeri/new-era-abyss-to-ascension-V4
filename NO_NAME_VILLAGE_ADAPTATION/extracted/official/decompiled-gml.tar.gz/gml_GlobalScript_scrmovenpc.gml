function scrmovenpc(argument0, argument1, argument2) //gml_Script_scrmovenpc
{
    if (argument0 == objplayer)
    {
        if (point_distance(objplayer.x, objplayer.y, argument1, argument2) > 12)
        {
            objplayer.caninput = false
            objplayer.controlinput = true
            objplayer.state = 1
            objplayer.dir = point_direction(objplayer.x, objplayer.y, argument1, argument2)
            if (abs(argument1 - objplayer.x) <= 6)
                objplayer.hspd = 0
            else if (argument1 > objplayer.x)
                objplayer.hspd = 1
            else if (argument1 < objplayer.x)
                objplayer.hspd = -1
            if (abs(argument2 - objplayer.y) <= 6)
                objplayer.vspd = 0
            else if (argument2 > objplayer.y)
                objplayer.vspd = 1
            else if (argument2 < objplayer.y)
                objplayer.vspd = -1
        }
    }
    else if (argument0 == objfollower)
    {
        argument0.state = 1
        argument0.target = -4
        argument0.targetx = argument1
        argument0.targety = argument2
        argument0.spd = clamp((argument0.spd + 2), 0, 8)
    }
    else if (point_distance(argument0.x, argument0.y, argument1, argument2) > 12)
    {
        argument0.state = 1
        if (argument0 == objreg)
            argument0.spd = clamp((argument0.spd + 0.1), 0, 6)
        else
            argument0.spd = clamp((argument0.spd + 0.2), 0, 8)
        argument0.dir = point_direction(argument0.x, argument0.y, argument1, argument2)
    }
    else
        argument0.state = 0
    return point_distance(argument0.x, argument0.y, argument1, argument2);
}

