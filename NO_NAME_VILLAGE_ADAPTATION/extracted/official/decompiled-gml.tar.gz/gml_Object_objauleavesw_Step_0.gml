if surface_exists(autumnleaves)
{
    if (draw == false)
    {
        surface_set_target(autumnleaves)
        with (objautree1)
        {
            for (var i = 0; i < 1000; i += 1)
            {
                var rdist = exp(random(6)) + irandom(192) + irandom(192)
                var rdir = random(360)
                draw_sprite(sleaf, irandom(11), ((x + (lengthdir_x(rdist, rdir))) / 4), ((y + (lengthdir_y((rdist * 2 / 3), rdir))) / 4))
            }
        }
        with (objautree2)
        {
            for (i = 0; i < 1000; i += 1)
            {
                rdist = exp(random(6)) + irandom(192) + irandom(192)
                rdir = random(360)
                draw_sprite(sleaf, irandom(11), ((x + (lengthdir_x(rdist, rdir))) / 4), ((y + (lengthdir_y((rdist * 2 / 3), rdir))) / 4))
            }
        }
        if (scrbfmap(room) == 0)
        {
            for (i = 0; i < 10000; i += 1)
                draw_sprite(sleaf, irandom(11), (irandom(room_width) / 4), (irandom(room_height) / 4))
        }
        sautumnleaves = sprite_create_from_surface(autumnleaves, 0, 0, (room_width / 4), (room_height / 4), 0, 0, 0, 0)
        surface_reset_target()
        surface_free(autumnleaves)
        draw = true
    }
}
