function scrdist(argument0, argument1) //gml_Script_scrdist
{
    if (instance_exists(argument0) && instance_exists(argument1))
    {
        var dist = point_distance(argument0.x, argument0.y, argument1.x, argument1.y)
        return dist;
    }
}

