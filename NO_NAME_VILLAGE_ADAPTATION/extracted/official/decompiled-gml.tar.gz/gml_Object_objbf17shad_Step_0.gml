if (point_distance(x, y, destx, desty) <= 0.02)
{
    x += lengthdir_x(spd, point_direction(x, y, destx, desty))
    y += lengthdir_y(spd, point_direction(x, y, destx, desty))
    spd += abs((point_distance(x, y, destx, desty)) / 64 - spd)
}
else
{
    var rdir = random(360)
    var rdist = random(128)
    destx = x + (lengthdir_x(rdist, rdir))
    desty = y + (lengthdir_y(rdist, rdir))
}
