draw_sprite_ext(s9slice0, image_index, x, y, xscale, yscale, 0, c_white, 1)
if (state == 0)
{
    draw_sprite_ext(s9slice1, image_index, (x + 8), (y + 8 + by), bxscale, 2.2, 0, c_white, 1)
    for (var i = 0; i < array_length_1d(text); i++)
    {
        draw_set_halign(fa_center)
        draw_set_font(font)
        draw_set_color(c_black)
        draw_text((x + sprite_get_width(s9slice0) * xscale / 2), (y + 16 + 48 * i), text[i][0])
    }
}
