if (watershad != -4)
{
    if (global.season >= 3)
    {
        sprite_index = wnsprite
        watershad = wnwatershad
        shadshad = wnshadshad
    }
    if layer_exists("watershad")
    {
        var shad = layer_sprite_create("watershad", x, y, watershad)
        layer_sprite_xscale(shad, image_xscale)
    }
    if layer_exists("shadows")
    {
        var shadow = layer_sprite_create("shadows", x, y, shadshad)
        layer_sprite_xscale(shadow, image_xscale)
    }
    watershad = -4
}
