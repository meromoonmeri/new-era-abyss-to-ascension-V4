player = 100
state = 0
spd = 0
dir = 0
aggro = 0
timer0 = 0
