is_game_restarting = false
show_debug_message("create")
randomize()
if steam_initialised()
    room_goto(Room_Steam_Main)
