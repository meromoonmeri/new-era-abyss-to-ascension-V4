function scrptarc(argument0, argument1, argument2, argument3, argument4, argument5, argument6, argument7) //gml_Script_scrptarc
{
    var ptspd = argument2 + (abs(angle_difference(dir, 180))) * (abs(argument3 - argument2)) / 180
    part_type_speed(argument0, ptspd, ptspd, 0, 0)
    if (argument1 < 180)
    {
        var ptdir = 90 + (angle_difference(180, dir)) * 2 * (abs(angle_difference(argument4, argument5))) / 90
        part_type_direction(argument0, ptdir, ptdir, 0, 0)
    }
    else
    {
        ptdir = 90 + (angle_difference(180, dir)) * 2 * (abs(angle_difference(argument4, argument5))) / 90
        part_type_direction(argument0, (-ptdir), (-ptdir), 0, 0)
    }
    part_type_gravity(argument0, argument6, 270)
    part_type_life(argument0, argument7, argument7)
}

