if instance_exists(creator)
{
    x = creator.x
    y = creator.y
    image_alpha = creator.image_alpha
}
else
    instance_destroy()
