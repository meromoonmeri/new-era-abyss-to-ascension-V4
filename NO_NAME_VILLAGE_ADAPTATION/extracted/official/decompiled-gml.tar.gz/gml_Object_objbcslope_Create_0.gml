event_inherited()
c = -1
var yblock = instance_create_layer(x, y, "invisible", objyslope)
yblock.c = (-c)
if (image_xscale == 1)
{
    if (image_yscale == 1)
    {
        dir = 315
        yblock.dir = 135
    }
    else
    {
        dir = 45
        yblock.dir = 225
        yblock.image_xscale = -1
        yblock.x = x + 64
        yblock.y = y - 64
    }
}
else if (image_yscale == 1)
{
    dir = 225
    yblock.dir = 45
    yblock.image_xscale = -1
}
else
{
    dir = 135
    yblock.dir = 315
    yblock.x = x - 64
    yblock.y = y - 64
}
