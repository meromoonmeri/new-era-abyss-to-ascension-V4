if (snatch == false)
{
    if (turn > 0)
    {
        if (!(scrcolline(x, y, (x + (lengthdir_x((spd * 2), dir))), (y + (lengthdir_y(spd, dir))))))
        {
            maxcheck = 0
            instance_create_layer(x, y, "shadows", objbmobau0c)
            x += lengthdir_x((spd * 2), dir)
            y += lengthdir_y(spd, dir)
        }
        else
        {
            turn -= 1
            dir = dir - 180 + 20 + changedir
            if (ptarg == false && turn <= 4)
            {
                if (!(scrcolline(x, y, objplayerview.player.x, objplayerview.player.y)))
                {
                    dir = scrdir(self, objplayerview.player)
                    ptarg = true
                }
            }
            while (scrcolline(x, y, (x + (lengthdir_x((spd * 2), dir))), (y + (lengthdir_y(spd, dir)))) && maxcheck < 10)
            {
                changedir *= 1.2
                dir += changedir
                maxcheck += 1
            }
        }
    }
    else if (turn > -5 && (!(scrcolline(x, y, (x + (lengthdir_x((spd * 2), dir))), (y + (lengthdir_y(spd, dir)))))))
    {
        instance_create_layer(x, y, "shadows", objbmobau0c)
        x += lengthdir_x((spd * 2), dir)
        y += lengthdir_y(spd, dir)
        turn -= 1
    }
    else
    {
        if (objbmobau.hp > 0)
        {
            objbmobau.balpha = 0
            objbmobau.alpha = 0
            objbmobau.shaket = 0
            objbmobau.prevx = objbmobau.x
            objbmobau.prevy = objbmobau.y
            objbmobau.x = x + (lengthdir_x(((-spd) * 2), dir))
            objbmobau.y = y + (lengthdir_y((-spd), dir))
            objbmobau.idir = dir
            objbmobau.dir = dir
        }
        with (objbmobau0c)
            appear = 1
        instance_destroy()
    }
}
