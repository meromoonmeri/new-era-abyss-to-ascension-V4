function scrmapspawnfix(argument0) //gml_Script_scrmapspawnfix
{
    if (argument0 == 9)
    {
        with (objplayer)
        {
            x = 2640
            y = 1744
        }
    }
    if (argument0 == 39)
    {
        with (objplayer)
        {
            x = 1280
            y = 112
        }
    }
    if (argument0 == 61)
    {
        with (objplayer)
        {
            x = 1184
            y = 128
        }
    }
    if (argument0 == 18)
    {
        with (objplayer)
        {
            x = 4912
            y = 3072
        }
    }
}

