/*
DECOMPILER FAILED!

System.NullReferenceException: Arg_NullReferenceException
   at UndertaleModLib.Decompiler.Decompiler.FunctionDefinition.ToString(DecompileContext context)
   at UndertaleModLib.Decompiler.Decompiler.AssignmentStatement.ToString(DecompileContext context)
   at UndertaleModLib.Decompiler.Decompiler.Decompile(UndertaleCode code, GlobalDecompileContext globalContext, Action`1 msgDelegate)
   at UndertaleModCli.Program.GetDecompiledText(UndertaleCode code, GlobalDecompileContext context)
*/