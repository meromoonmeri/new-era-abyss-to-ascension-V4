event_inherited()
if (z < 32)
    z += 1
else
    z = 128 + (scrwave(-32, 32, 2, 0))
if (state == 0)
{
    if (pattern <= -1)
    {
        if (scrdistview(x, y, player.x, player.y) < 256)
            pattern = -0.9666666666666667
        if (pattern < -1)
            pattern += 0.016666666666666666
        else
        {
            pattern = -2
            state = 1
            dir1 = irandom(360)
        }
    }
    else if (pattern < 0)
        pattern += (1/30)
    else if (run == false)
        pattern = 1
    else
        pattern = 2
    if (pattern == 1)
    {
        if (timer1 == 0)
        {
            state = 1
            dir1 += irandom_range(-90, 90)
            timer1 += 1
        }
        else if (timer1 == 1)
        {
            state = 0
            pattern = -1
        }
    }
    else
        timer1 = 0
    if (pattern == 2)
    {
        if (timer2 < 3)
        {
            state = 1
            dir1 = scrdir(player, self)
            timer2 += 1
        }
        else if (timer2 == 3)
        {
            state = 2
            dir1 = scrdir(player, self)
            timer2 = 4
        }
        else
        {
            state = 0
            pattern = -0.5
        }
    }
    else
        timer2 = 0
}
if (state == 1)
{
    var ad = angle_difference(dir, dir1)
    dir -= ((min(abs(ad), 5)) * sign(ad))
    scrmovcol(spd, dir1)
    image_speed = 0.1
    if (image_speed < 1)
        spd += (-1 * spd / 12)
    else if (image_index < (image_number - image_speed))
        spd += (-1 * (spd - 8) / 12)
    else
        state = 0
}
if (state == 2)
{
    if (image_index < 1)
    {
        image_speed = 0.1
        ad = angle_difference(dir, dir1)
        dir -= ((min(abs(ad), 5)) * sign(ad))
    }
    else if (image_index < (image_number - image_speed))
    {
        if (image_speed != 0.2)
        {
            image_speed = 0.2
            dir = dir1
        }
    }
    else
        state = 0
}
if (hit > 0)
{
    hp -= (hit + hit * (max(0, (objplayer.weaponlvl - 1))) * 0.5)
    flash = 1
    if (harmor == false)
        state = 3
}
if (state == 3)
{
    if (image_index < (image_number - image_speed))
        image_speed = 0.2
    else
        state = 0
}
if (state == 4)
{
}
