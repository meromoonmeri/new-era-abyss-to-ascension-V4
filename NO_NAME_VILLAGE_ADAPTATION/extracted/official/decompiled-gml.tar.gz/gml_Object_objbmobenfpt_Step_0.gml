if (z > 1)
{
    z = clamp((z - zvel), 1, 999999)
    image_alpha += 0.1
}
else
{
    if (z > 0)
    {
        z = 0
        image_alpha = 1
        scrsound(snsplash1, 9, random_range(0.2, 0.4), random_range(0.9, 1.1))
        scrsound(snbmobenssplash0, 9, random_range(0.2, 0.4), random_range(0.9, 1.1))
    }
    if (sprite_index == sbmobenfpt00)
    {
        sprite_index = sbmobenfpt01
        scrsplash(x, y, sbmobenjsplash, 0)
        scrsplash(x, y, sbmobenjsplash2, 0)
        objplayerview.shaket = 10
    }
    if (sprite_index == sbmobenfpt10)
    {
        sprite_index = sbmobenfpt11
        scrsplash(x, y, sbmobenjsplash, 0)
        scrsplash(x, y, sbmobenjsplash2, 0)
        objplayerview.shaket = 8
    }
    if (sprite_index == sbmobenfpt20)
    {
        sprite_index = sbmobenfpt21
        scrsplash(x, y, sbmobenjsplash, 0)
        scrsplash(x, y, sbmobenjsplash2, 0)
        objplayerview.shaket = 6
    }
}
