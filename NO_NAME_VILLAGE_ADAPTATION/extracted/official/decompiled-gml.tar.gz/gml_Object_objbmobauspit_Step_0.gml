depth = (-y)
var player = objplayerview.player
if (start < 1)
{
    start += 0.016666666666666666
    repeat (2)
    {
        var sradius = 1 - start
        var rdist = random(256) * sradius
        var rdir = random(360)
        part_particles_create(part_system, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), part_type, 1)
    }
}
else if (start < 2)
    start += (1/30)
else if (start < 3)
{
    start = 3
    part_particles_create(global.ptwater0, x, y, ptsp, 1)
    scrsplash(x, y, ssplash0, 0)
    alpha = 1
    rdist = random(128)
    rdir = random(360)
    spd = (point_distance(x, y, (player.x + (lengthdir_x(rdist, rdir))), (player.y + (lengthdir_y(rdist, rdir))))) / (2 * vel / zaccl)
    dir = point_direction(x, y, (player.x + (lengthdir_x(rdist, rdir))), (player.y + (lengthdir_y(rdist, rdir))))
}
else if (start < 4)
{
    vel -= zaccl
    z += vel
    if (z <= 0)
    {
        z = 0
        start = 4
    }
    var ptrdir = random_range(1, 360)
    var ptlendirx = lengthdir_x(16, ptrdir)
    var ptlendiry = lengthdir_y(16, ptrdir)
    if (random(1) < 0.5)
        part_particles_create(global.ptwater0, (x + ptlendirx), (y - z + ptlendiry), pt0, 1)
    else if (random(1) < 0.5)
        part_particles_create(global.ptwater0, (x + ptlendirx), (y - z + ptlendiry), pt1, 1)
    x += lengthdir_x(spd, dir)
    y += lengthdir_y(spd, dir)
}
else
{
    if variable_global_exists("ptwater0")
        part_system_depth(global.ptwater0, (-y))
    part_particles_create(global.ptwater0, x, y, pte, 1)
    scrsplash(x, y, ssplash0, 0)
    scrsplash(x, y, sbmobsmsplash1, 0)
    scrsound(snbmobaup1, 20, 1, 1)
    col = 1
}
shadsize = clamp((1 - z / 512), 0.5, 1)
if (col > 0)
{
    col -= 1
    var pcol = instance_place(x, y, player)
    if (pcol != noone && pcol.iframe <= 0 && noncol == false)
    {
        if (player != 374)
            objplayer.hp -= 1
        else
            objft0.hp -= 1
        pcol.iframe = 1
        pcol.state = 6
        pcol.dir = scrdir(pcol, self)
        pcol.caninput = false
        pcol.image_index = 0
        objplayerview.shaket = 16
    }
    if (start >= 4)
        instance_destroy()
}
