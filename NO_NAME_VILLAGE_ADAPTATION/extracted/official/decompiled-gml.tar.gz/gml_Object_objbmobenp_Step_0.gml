if (startz < 400)
{
    if scrcolline(startx, starty, x, y)
        instance_destroy()
}
if (shoot == 0)
{
    dir = point_direction(startx, starty, x, y)
    var ptdir = point_direction(startx, starty, (startx + (lengthdir_x(12, (dir + 180)))), (starty + (lengthdir_y(6, (dir + 180))) - 12))
    part_type_direction(part_type, ptdir, ptdir, 0, 0)
    part_particles_create(part_system, startx, (starty - startz), part_type, 1)
    px = startx
    py = starty
    pz = startz
    dir = point_direction(px, py, x, y)
    shoot = 1
}
else if (pspd > 0)
{
    trail = power(point_distance(px, (py - pz), startx, (starty - startz)), (2/3))
    if (point_distance(px, py, x, y) >= pspd)
        pspd = (point_distance(startx, starty, x, y)) / 2
    else
    {
        pspd = 0
        px = x
        py = y
        pz = 0
    }
    px += lengthdir_x(pspd, dir)
    py += lengthdir_y(pspd, dir)
    pz = startz * ((point_distance(px, py, x, y)) / (point_distance(startx, starty, x, y)))
}
else if (shoot == 1)
{
    px = x
    py = y
    pz = 0
    if (trail > 0)
        trail -= (trail / 2)
    if (timer == 0)
    {
        timer = 1
        scrsplash(x, y, ssplash0, 1)
        if (position_meeting(x, y, objplayer) && objplayer.iframe <= 0 && objplayer.harmor == false)
        {
            objplayer.state = 5
            objplayer.dir = dir + 180
            objplayer.spd = 12
            objplayer.caninput = false
            objplayer.image_index = 0
            objplayerview.shaket = 6
        }
    }
    else if (timer < 30)
        timer += 1
    else
    {
        timer = 0
        shoot = 2
    }
}
else if (explode < 6)
{
    if (timer < 1)
        timer += 0.2
    else
    {
        timer = 0
        explode += 1
    }
    alpha += 0.0016666666666666668
}
else if (shoot == 2 && dud == false)
{
    shoot = 3
    alpha = 1
    repeat (5)
    {
        var rdist = irandom(6)
        var rdir = irandom(360)
        ptdir = point_direction(x, y, (x + (lengthdir_x((rdist * 4), rdir))), (y + (lengthdir_x((rdist * 2), rdir)) - 48))
        part_type_direction(part_type2, ptdir, ptdir, 0, 0)
        part_particles_create(part_system, (x + (lengthdir_x((rdist * 4), rdir))), (y + (lengthdir_x((rdist * 2), rdir))), part_type2, 1)
    }
    var pcol = instance_place(x, y, objplayer)
    if (pcol != noone && objplayer.iframe <= 0)
    {
        objplayer.hp -= 1
        pcol.state = 6
        pcol.dir = dir + 180
        pcol.caninput = false
        pcol.image_index = 0
        objplayerview.shaket = 16
    }
}
else
{
    alpha = clamp((alpha - 0.2), 0, 1)
    if (part_particles_count(part_system) <= 0)
        instance_destroy()
}
