event_inherited()
sprite = 947
watershad = 2444
shadshad = 2700
