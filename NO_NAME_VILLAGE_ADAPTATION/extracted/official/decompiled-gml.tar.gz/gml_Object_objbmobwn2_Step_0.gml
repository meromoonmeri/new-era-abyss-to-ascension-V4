event_inherited()
var rmcx = 2304
var rmcy = 1920
if (state == -1)
{
    if (rise == 0)
    {
        rise = 1
        var bl = instance_create_depth(x, y, (layer_get_depth("shadows") + 1), objempty)
        if layer_exists("bg2")
            bl.depth = layer_get_depth("bg2") + 1
        bl.sprite_index = sbmobwn2ri
        scrsoundgain(snwrithe0, 50, 1, 0)
        sound = 0
    }
    else if (rise == 1)
    {
        sprite_index = sbmobwn2ri0
        image_speed = 0.15
        var ssw = clamp((1 - (scrdist(objplayerview, self)) / 640), 0.2, 1)
        scrsoundgain(snwrithe0, 50, ssw, 0)
    }
    else if (rise == 2)
    {
        sprite_index = sbmobwn2ri1
        if (image_index < 1)
            image_speed = 0.016666666666666666
        else if (image_index < 2)
        {
            image_speed = 0.2
            objplayerview.shaket = 10
        }
        else if (image_index < 3)
            image_speed = 0.2
        else if (image_index < 4)
            image_speed = 0.016666666666666666
        else if (image_index < 11)
            image_speed = 0.15
        else
        {
            image_index = 0
            state = 1
            pattern = 2
        }
        scrsoundgain(snwrithe0, 50, 0, 1000)
        if (sound == 0 && image_index > 0.8)
        {
            sound = 1
            scrsound(snbmobwn2impact0, 50, 0.5, 0.8)
        }
        if (sound == 1 && image_index > 4.5)
        {
            sound = 2
            scrsound(snbmobwn2slide0, 50, 0.5, 0.7)
        }
        if (sound == 2 && image_index > 7)
        {
            sound = 3
            scrsound(snbmobwn2slide0, 50, 0.5, 1)
        }
        if (sound == 3 && image_index > 8)
        {
            sound = 4
            scrsound(sncutblanket22, 50, 0.5, 1)
        }
    }
}
if (state == 0)
{
    if (pattern < 1)
    {
        if (spd > 0.5)
            spd -= max(0.25, (spd / 10))
        else if (spd < -0.5)
            spd += max(0.25, (spd / 10))
        else
            spd = 0
    }
    else
        spd = 0
    scrmovcol(spd, dir)
    if (pattern < 0)
    {
        image_speed = 0.1
        scrspr8dir(dir, sbmobwn2i0, sbmobwn2i1, sbmobwn2i2, sbmobwn2i3, sbmobwn2i4)
        ptimer = 1 + (1 - hp / maxhp) * 4
        pattern += 0.05
    }
    else if (pattern < 1)
    {
        timer1 = 0
        timer2 = 0
        timer3 = 0
        timer4 = 0
        timer5 = 0
        timer6 = 0
        timer7 = 0
        if (angle_difference(dir, idir) > 18)
        {
            var ad = angle_difference(dir, idir)
            dir -= ((min(abs(ad), 9)) * sign(ad))
        }
        else if (scrdistview(x, y, player.x, player.y) > 640)
            pattern = choose(1, 1, 1, 1, 3)
        else if (scrdistview(x, y, player.x, player.y) > 256)
            pattern = choose(2, 3)
        else if (instance_number(objbmobwn2pd) > 38)
            pattern = choose(6, 6, 6)
        else
            pattern = choose(2, 3, 4, 5, 7)
    }
    if (pattern == 1)
    {
        if (timer1 == 0)
        {
            dir = idir + (choose(-20, 20))
            timer1 = 1
        }
        else if (timer1 < 5)
        {
            dir = idir + (angle_difference(dir, idir)) / 3
            state = 2
            timer1 += 1
            if (scrdistview(x, y, player.x, player.y) < 192)
            {
                state = 0
                timer1 = 3
            }
        }
        else
            pattern = -0.1
    }
    else
        timer1 = 0
    if (pattern == 2)
    {
        if (timer2 == 0)
        {
            state = 3
            swipe = 1
            dir = idir
            image_index = 0
            if ((hp / maxhp) > 0.6)
                timer2 = 3
            else if (scrdist(self, player) < 128 && instance_number(objbmobwn2pd) > 5)
                timer2 = 1
            else
                timer2 = 2
        }
        else if (timer2 == 1)
        {
            dir = idir
            image_index = 0
            state = 1
            if ((hp / maxhp) < 0.4)
                timer2 = 2
            else
                timer2 = 3
        }
        else if (timer2 == 2)
        {
            dir = idir
            image_index = 0
            state = 4
            timer2 = 3
        }
        else
            pattern = -1
    }
    else
        timer2 = 0
    if (pattern == 3)
    {
        if (timer3 == 0)
        {
            dir = idir
            image_index = 0
            state = 4
            if ((hp / maxhp) > 0.6)
                timer3 = 3
            else
                timer3 = 1
        }
        else if (timer3 == 1)
        {
            dir = idir
            image_index = 0
            state = 3
            if (scrdist(self, player) < 128)
                timer3 = 2
            else
                timer3 = 3
        }
        else if (timer3 == 2)
        {
            dir = idir
            image_index = 0
            state = 1
            timer3 = 3
        }
        else
            pattern = -1
    }
    if (pattern == 4)
    {
        if (timer4 < 4)
        {
            dir = idir
            image_index = 0
            if (timer4 == 0)
            {
                state = 3
                timer4 = 1
            }
            else if (timer4 == 1)
            {
                state = 3
                swipe = 1
                if (instance_number(objbmobwn2pd) > 5)
                    timer4 = choose(2, 3)
                else
                    timer4 = 3
            }
            else if (timer4 == 2)
            {
                state = 1
                timer4 = 3
            }
            else if (timer4 == 3)
            {
                state = 3
                timer4 = 4
            }
        }
        else
            pattern = -1
    }
    if (pattern == 5)
    {
        if (timer5 == 0)
        {
            state = 5
            dir = idir
            image_index = 0
            timer5 = 1
        }
        else if (timer5 == 1)
        {
            state = 1
            image_index = 0
            timer5 = 2
        }
        else
            pattern = -1
    }
    else
        timer5 = 0
    if (pattern == 6)
    {
        if (timer6 == 0)
        {
            dir = idir
            image_index = 0
            state = 1
            timer6 = 1
        }
        else if (timer6 == 1)
        {
            dir = idir
            image_index = 0
            state = 4
            timer6 = 2
        }
        else
            pattern = -1
    }
    if (pattern == 7)
    {
        if (timer7 == 0)
        {
            state = 4.5
            dir = (point_direction(x, y, rmcx, rmcy)) + (irandom_range(-30, 30))
            image_index = 0
            timer7 = 1
        }
        else if (timer7 == 1)
        {
            state = 3
            dir = idir
            image_index = 0
            timer7 = 2
        }
        else
            pattern = -1
    }
    if (state == 1)
    {
        if (!instance_exists(objbmobwn2pd))
            state = 0
    }
}
if (state == 1)
{
    scrspr8dir(dir, sbmobwn2r0, sbmobwn2r1, sbmobwn2r2, sbmobwn2r3, sbmobwn2r4)
    scrmovcol(spd, dir)
    spd += ((-spd) / 2)
    if (image_index < 1)
    {
        if (image_index < 0.1)
            sound = 0
        image_speed = 0.1
        splash = 0
        if (sound == 0 && image_index > 0.8)
        {
            sound = 1
            scrsound(snbmobwn2roar0, 50, 1, 1)
        }
    }
    else if (image_index < 2)
    {
        image_speed = 0.1
        if (splash != 1)
        {
            splash = 1
            spd = 2
        }
        if (sound == 1 && image_index > 1.8)
        {
            sound = 2
            scrsound(snbmobwn2roar1, 50, 1, 1)
        }
    }
    else if (image_index < 3)
    {
        image_speed = 0.04
        if (image_index < 2.2)
            objplayerview.shaket = 12
        if (splash != 2)
        {
            splash = 2
            spd = 16
            with (objbmobwn2pd)
            {
                expl = (-(scrdist(self, other))) / 576
                if (expl < -1)
                    timer = 0
                else
                    expl += random_range(-0.1, 0.1)
            }
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.1
        if (startroar == 1)
            image_speed = (1/30)
    }
    else
    {
        state = 0
        startroar = 0
    }
}
if (state == 2)
{
    scrspr8dir(dir, sbmobwn2w0, sbmobwn2w1, sbmobwn2w2, sbmobwn2w3, sbmobwn2w4)
    scrmovcol(spd, dir)
    if ((timer1 % 2) == 0)
    {
        if (image_index < (2 - image_speed))
        {
            if (spd < 2)
                spd += 0.1
            if (image_speed != 0.1)
            {
                image_speed = 0.1
                scrsound(snbmobwn0step, 10, 1, 1)
                scrsound(snbmobwn2step0, 10, 0.5, 1)
            }
        }
        else
        {
            image_speed = 0
            state = 0
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        if (spd < 2)
            spd += 0.1
        if (image_speed != 0.1)
        {
            image_speed = 0.1
            scrsound(snbmobwn0step, 10, 1, 0.8)
            scrsound(snbmobwn2step0, 10, 0.5, 0.8)
        }
    }
    else
    {
        image_speed = 0
        state = 0
    }
}
if (state == 3)
{
    if (image_index < (3 - image_speed))
        scrspr8dir(dir, sbmobwn2sw0, sbmobwn2sw1, sbmobwn2sw2, sbmobwn2sw3, sbmobwn2sw4)
    else
        scrspr4dir2(dir, sbmobwn2sw0, sbmobwn2sw2, sbmobwn2sw4)
    if (scrdist(self, player) > 128 && swipe == 0)
    {
        dshspd = 18
        dshspd = (scrdist(self, player)) * 3.5 / 64
    }
    else if (dshspd < 0)
    {
        if (swipe == 0)
        {
            if (image_index >= (2 - image_speed) && image_index < 3)
                image_index = 3
        }
        else
            dshspd = clamp(((point_distance(x, y, rmcx, rmcy)) * 3.5 / 64), 8, 24)
    }
    scrmovcol(spd, dir)
    if (image_index < 2)
    {
        if (image_index < 0.2)
            sound = 0
        image_speed = 0.2
        spd += ((-spd) / 12)
        dshspd = -1
    }
    else if (image_index < 3)
    {
        image_speed = 0.2
        spd += ((dshspd - spd) / 2)
    }
    else if (image_index < 5)
    {
        image_speed = 0.2
        spd += ((-spd) / 12)
    }
    else if (image_index < 7)
    {
        image_speed = 0.6
        spd += ((dshspd * 2 / 3 - spd) / 8)
    }
    else if (image_index < 8)
    {
        image_speed = 0.4
        spd += ((-spd) / 3)
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.2
        spd += ((-spd) / 4)
    }
    else
        state = 0
    var ad90 = abs(angle_difference(90, dir))
    var ad270 = abs(angle_difference(270, dir))
    if (image_index < 3)
        prevface = facing
    else if (image_index < 9 && ad90 > 5 && ad270 > 5)
    {
        ad = (angle_difference(dir, idir)) / (image_index * 20)
        dir -= ((min(abs(ad), 5)) * sign(ad))
    }
    if (sound == 0 && image_index > 1.5)
    {
        sound = 1
        scrsound(sncutblanket23, 50, 1, 1)
    }
    if (sound == 1 && image_index > 3)
    {
        sound = 2
        scrsound(snbmobwn2swipe0, 50, 1, 1)
    }
    if (sound == 2 && image_index > 5)
    {
        sound = 3
        scrsound(snbmobwn2swipe1, 50, 1, 1)
    }
    if (sound == 3 && image_index > 6)
    {
        sound = 4
        scrsoundgain(snbmobwn2swipe0, 50, 0, 1000)
    }
}
else
    swipe = 0
if (state == 4)
{
    scrmovcol(spd, dir)
    if (image_index < 2)
    {
        image_speed = 0.2
        spd += ((-spd) / 12)
        jump = 0
        z = 0
        vel = 0
        zaccl = 0.6
        splash = 0
    }
    else if (image_index < 7)
    {
        image_speed = 0
        if (splash == 0)
        {
            splash = 1
            objplayerview.shaket = 4
            part_particles_create(pssw, x, y, ptslj, 1)
            scrptdust0(x, y, 463, 16, 32)
            scrsound(sncutblanket23, 50, 1, 1)
        }
        if (z > 16)
        {
            vel -= zaccl
            z = clamp((z + vel), 0, 999)
            zaccl += 0.02
            if (vel > 0)
                image_index = 2.5
            else if (vel > -3)
                image_index = 3.5
            else if (vel > -6)
                image_index = 4.5
            else if (vel > -10)
                image_index = 5.5
            else
                image_index = 6.5
        }
        else if (jump == 0)
        {
            jump = 1
            spd = clamp(((scrdist(self, player)) / 64), 2, 999)
            z = 240
            vel = 10
        }
        else
        {
            image_index = 7
            z = 0
        }
    }
    else if (image_index < 8)
    {
        image_speed = 0.1
        spd += ((-spd) / 4)
        if (splash == 1)
        {
            splash = 2
            objplayerview.shaket = 12
            scrsound(snmobau32, 10, 1, 1)
            scrsound(snbmobwn2impact0, 50, 1, 1)
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.2
        spd = 0
    }
    else
        state = 0
    if (image_index > 2 && image_index < 7)
        scrspr4dir2(dir, sbmobwn2sl0, sbmobwn2sl2, sbmobwn2sl4)
    else
        scrspr8dir(dir, sbmobwn2sl0, sbmobwn2sl1, sbmobwn2sl2, sbmobwn2sl3, sbmobwn2sl4)
}
if (state == 4.5)
{
    scrmovcol(spd, dir)
    if (image_index < 2)
    {
        image_speed = 0.2
        spd += ((-spd) / 12)
        jump = 0
        z = 0
        vel = 0
        zaccl = 0.6
        splash = 0
    }
    else if (image_index < 6)
    {
        image_speed = 0
        if (splash == 0)
        {
            splash = 1
            objplayerview.shaket = 4
            part_particles_create(pssw, x, y, ptslj, 1)
            scrptdust0(x, y, 463, 16, 32)
            scrsound(sncutblanket23, 50, 1, 1)
        }
        if (jump == 0)
        {
            jump = 1
            spd = clamp(((point_distance(x, y, rmcx, rmcy)) / 32), 12, 999)
            z = 240
            vel = 10
        }
        else if (z > 16)
        {
            vel -= zaccl
            z = clamp((z + vel), 0, 999)
            zaccl += 0.02
            if (vel > 0)
                image_index = 2.5
            else if (vel > -3)
                image_index = 3.5
            else if (vel > -6)
                image_index = 4.5
            else
                image_index = 5.5
        }
        else
        {
            image_index = 6
            z = 0
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.2
        if (splash == 1)
        {
            splash = 2
            objplayerview.shaket = 4
        }
        spd += ((-spd) / 4)
    }
    else
        state = 0
    if (image_index > 2 && image_index < 6)
        scrspr4dir2(dir, sbmobwn2j0, sbmobwn2j2, sbmobwn2j4)
    else
        scrspr8dir(dir, sbmobwn2j0, sbmobwn2j1, sbmobwn2j2, sbmobwn2j3, sbmobwn2j4)
}
if (state == 5)
{
    scrspr8dir(dir, sbmobwn2st0, sbmobwn2st1, sbmobwn2st2, sbmobwn2st3, sbmobwn2st4)
    if (image_index < 1)
    {
        image_speed = 0.2
        if (image_index == 0)
            scrsound(snbmobwn2step1, 50, 1, 1)
    }
    else if (image_index < 2)
    {
        image_speed = 0.15
        splash = 0
    }
    else if (image_index < 3)
    {
        image_speed = 0.1
        if (splash == 0)
        {
            splash = 1
            stomp = 1
            objplayerview.shaket = 8
            var stmpx = x + (lengthdir_x(12, dir))
            var stmpy = y + (lengthdir_y(8, dir))
            instance_create_layer(stmpx, stmpy, "instances", objbmobwn2pdb)
            part_particles_create(pssw, stmpx, stmpy, ptsp, 1)
            scrsound(snbmobwn2stomp0, 50, 1, 1)
        }
    }
    else if (image_index < (image_number - image_speed))
        image_speed = 0.2
    else
        state = 0
}
if (z > 16 || state == 7)
    hit = -2
else if (hit <= 0)
    hit = 0
if (hit > 0)
{
    var hitspd = scrmobhurt(6, 7, 0)
    if (hitspd > 0)
        spd = -6
    else
        spd = -2
    scrsound(snbmobwn2spread0, 50, 1, 1)
}
if (state == 6)
{
    scrspr8dir(dir, sbmobwn2h0, sbmobwn2h1, sbmobwn2h2, sbmobwn2h3, sbmobwn2h4)
    scrmovcol(spd, dir)
    spd += ((-spd) / 12)
    if (image_index < 1)
        image_speed = 0.4
    else if (image_index < (image_number - image_speed))
        image_speed = 0.2
    else
    {
        state = 0
        pattern = -0.2
    }
}
if (state == 7)
{
    scrspr4dir(dir, sbmobwn2d1, sbmobwn2d3)
    if (image_index < 2)
    {
        image_speed = 0.2
        splash = 0
    }
    else if (image_index < 3)
    {
        image_speed = 0.2
        if (splash == 0)
        {
            splash = 1
            objplayerview.shaket = 8
            part_type_scale(ptsp, 0.5, 0.5)
            part_particles_create(pssw, x, y, ptsp, 1)
            sound = 0
            scrsound(sncutblanket21, 50, 1, 1)
        }
    }
    else if (image_index < 4)
        image_speed = 0.025
    else if (image_index < 5)
    {
        image_speed = 0.1
        if (sound == 0)
        {
            sound = 1
            scrsound(snbmobwn2gore0, 50, 1, 1)
        }
    }
    else if (image_index < 6)
        image_speed = 0.05
    else if (image_index < 7)
    {
        image_speed = 0.2
        if (splash == 1)
        {
            splash = 2
            objplayerview.shaket = 16
            splat = 0.5
            part_type_scale(ptsp, 1, 1)
            part_particles_create(pssw, x, y, ptsp, 1)
            scrsound(snmobau0_sboom, 20, 1, 1)
            scrsound(snbmobwn2impact0, 50, 1, 1)
            scrsoundgain(sncutblanket21, 50, 0, 2000)
        }
    }
    else if (image_index < 8)
        image_speed = 0.1
    else if (image_index < 9.5)
        image_speed = 0.2
    else
        image_speed = 0
    if (splat >= 0.5 && splat < 1)
        splat += ((1 - splat) / 4)
}
if (stomp > 0)
{
    var stompdist = stomp * 64 * 6 / 60
    var stompdir = irandom(360)
    stmpx = x + (lengthdir_x(stompdist, stompdir))
    stmpy = y + (lengthdir_y((stompdist * 2 / 3), stompdir))
    var pd = instance_create_layer(stmpx, stmpy, "instances", objbmobwn2pd)
    pd.nosplash = 1
    stomp += 1
    if (stomp > 60)
        stomp = -1
}
else
    stomp = 0
