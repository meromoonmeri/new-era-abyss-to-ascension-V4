function scritemcheck(argument0) //gml_Script_scritemcheck
{
    if (screquip(argument0) == 2)
    {
        if (global.equipitem[0][0] == argument0)
            return 2;
        else
        {
            for (var k = 0; k <= 3; k++)
            {
                for (var l = 0; l <= 2; l++)
                {
                    if (global.invitem[k][l] == argument0)
                        return 1;
                }
            }
        }
    }
    else if (screquip(argument0) == 3)
    {
        if (global.equipitem[1][0] == argument0)
            return 3;
        else
        {
            for (k = 0; k <= 3; k++)
            {
                for (l = 0; l <= 2; l++)
                {
                    if (global.invitem[k][l] == argument0)
                        return 1;
                }
            }
        }
    }
    else if (screquip(argument0) == 4)
    {
        if (global.equipitem[2][0] == argument0)
            return 4;
        else
        {
            for (k = 0; k <= 3; k++)
            {
                for (l = 0; l <= 2; l++)
                {
                    if (global.invitem[k][l] == argument0)
                        return 1;
                }
            }
        }
    }
    else if (screquip(argument0) == 5)
    {
        if (global.equipitem[3][0] == argument0)
            return 5;
        else
        {
            for (k = 0; k <= 3; k++)
            {
                for (l = 0; l <= 2; l++)
                {
                    if (global.invitem[k][l] == argument0)
                        return 1;
                }
            }
        }
    }
    else if (screquip(argument0) == 6)
    {
        if (global.equipitem[3][0] == argument0)
            return 6;
        else
        {
            for (k = 0; k <= 3; k++)
            {
                for (l = 0; l <= 2; l++)
                {
                    if (global.invitem[k][l] == argument0)
                        return 1;
                }
            }
        }
    }
    else
    {
        for (k = 0; k <= 3; k++)
        {
            for (l = 0; l <= 2; l++)
            {
                if (global.invitem[k][l] == argument0)
                    return 1;
            }
        }
    }
}

