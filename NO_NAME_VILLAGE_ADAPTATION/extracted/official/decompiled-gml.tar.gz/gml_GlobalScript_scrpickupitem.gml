function scrpickupitem(argument0) //gml_Script_scrpickupitem
{
    if scritemcheck(0)
    {
        objplayer.item = argument0
        return 1;
    }
    else
        scrtbox(0, [[0, 394, "I can't carry anymore!"]])
}

