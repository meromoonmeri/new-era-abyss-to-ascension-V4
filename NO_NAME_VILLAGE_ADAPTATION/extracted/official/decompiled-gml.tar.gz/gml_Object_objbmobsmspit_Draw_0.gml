draw_sprite_ext(sbmobsmspitshad, sindex, x, y, 1, 1, 0, c_white, salpha)
draw_sprite_ext(sbmobsmspit, 0, x, (y - z), 1, 1, 0, c_white, alpha)
