function scrptdust1(argument0, argument1, argument2, argument3, argument4) //gml_Script_scrptdust1
{
    if (ford <= 0)
    {
        var scrpt1 = part_type_create()
        var scrpt2 = part_type_create()
        if (!variable_global_exists("psdust1"))
            global.psdust1 = -1
        if (!variable_global_exists("psdust0shad"))
            global.psdust0shad = -1
        if (global.psdust1 == -1)
        {
            global.psdust1 = part_system_create()
            part_system_depth(global.psdust1, (layer_get_depth("shadows") - 1))
        }
        if (global.psdust0shad == -1)
        {
            global.psdust0shad = part_system_create()
            part_system_depth(global.psdust0shad, layer_get_depth("shadows"))
        }
        part_type_sprite(scrpt1, argument2, 0, 0, 1)
        part_type_sprite(scrpt2, 929, 0, 0, 1)
        part_type_alpha3(scrpt1, 0.5, 0.4, 0)
        part_type_alpha3(scrpt2, 0.25, 0.2, 0)
        part_type_size(scrpt1, 0.8, 0.8, 0.01, 0)
        part_type_size(scrpt2, 0.8, 0.8, 0.01, 0)
        part_type_speed(scrpt1, argument3, argument3, 0, 0)
        part_type_speed(scrpt2, argument3, argument3, 0, 0)
        part_type_direction(scrpt1, (argument4 - 30), (argument4 + 30), 0, 0)
        part_type_direction(scrpt2, (argument4 - 30), (argument4 + 30), 0, 0)
        part_type_life(scrpt1, 10, 20)
        part_type_life(scrpt2, 10, 20)
        part_particles_create(global.psdust1, argument0, argument1, scrpt1, 1)
        part_particles_create(global.psdust0shad, argument0, argument1, scrpt2, 1)
    }
}

