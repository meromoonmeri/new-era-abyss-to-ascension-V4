if (splat > 0)
    draw_sprite_ext(sbmobwn2dsplash, 0, x, y, splat, splat, 0, 0x000001, 1)
if (z > 0)
{
    var shadsize = clamp((1 - z / 200), 0.5, 1)
    draw_sprite_ext(sbmobwn2shad, 0, x, y, shadsize, shadsize, 0, -1, 1)
}
if (state >= 0 && state < 7 && image_index < 6)
{
    var vttcx = 0
    var vttcy = 0
    if (facing == 1)
    {
        vttcx = x - sprite_xoffset + ttcx * 4
        vttcy = y - sprite_yoffset + ttcy * 4
    }
    else
    {
        vttcx = x - sprite_xoffset + sprite_width - ttcx * 4
        vttcy = y - sprite_yoffset + ttcy * 4
    }
    var vtthoriz = (tthoriz + 1) * 2
    var vttvert = (ttvert + 1) * 2
    var vttprevdist = (point_distance(vttcx, vttcy, ttcprevx, ttcprevy)) / 16
    var vttd = point_direction(vttcx, vttcy, ttcprevx, ttcprevy)
    var vad0 = angle_difference(vttd, (tt0c + 90))
    var vad1 = angle_difference(vttd, (tt1c + 90))
    var vad2 = angle_difference(vttd, (tt2c + 90))
    var vad3 = angle_difference(vttd, (tt3c + 90))
    var vad4 = angle_difference(vttd, (tt4c + 90))
    var vad5 = angle_difference(vttd, (tt5c + 90))
    var vtt0ct = tt0c + (lerp(0, vad0, clamp((vttprevdist / (clamp(abs(vad0 / 15), 1, 6))), 0, 1)))
    tt0ct += ((vtt0ct - tt0ct) / 12)
    var vtt1ct = tt1c + (lerp(0, vad1, clamp((vttprevdist / (clamp(abs(vad1 / 15), 1, 6))), 0, 1)))
    tt1ct += ((vtt1ct - tt1ct) / 12)
    var vtt2ct = tt2c + (lerp(0, vad2, clamp((vttprevdist / (clamp(abs(vad2 / 15), 1, 6))), 0, 1)))
    tt2ct += ((vtt2ct - tt2ct) / 12)
    var vtt3ct = tt3c + (lerp(0, vad3, clamp((vttprevdist / (clamp(abs(vad3 / 15), 1, 6))), 0, 1)))
    tt3ct += ((vtt3ct - tt3ct) / 12)
    var vtt4ct = tt4c + (lerp(0, vad4, clamp((vttprevdist / (clamp(abs(vad4 / 15), 1, 6))), 0, 1)))
    tt4ct += ((vtt4ct - tt4ct) / 12)
    var vtt5ct = tt5c + (lerp(0, vad5, clamp((vttprevdist / (clamp(abs(vad5 / 15), 1, 6))), 0, 1)))
    tt5ct += ((vtt5ct - tt5ct) / 12)
    var vadtr0 = 1 + vttprevdist / 2 * (angle_difference(vttd, (tt0ct + 90))) / 180
    var vadtr1 = 1 + vttprevdist / 2 * (angle_difference(vttd, (tt1ct + 90))) / 180
    var vadtr2 = 1 + vttprevdist / 2 * (angle_difference(vttd, (tt2ct + 90))) / 180
    var vadtr3 = 1 + vttprevdist / 2 * (angle_difference(vttd, (tt3ct + 90))) / 180
    var vadtr4 = 1 + vttprevdist / 2 * (angle_difference(vttd, (tt4ct + 90))) / 180
    var vadtr5 = 1 + vttprevdist / 2 * (angle_difference(vttd, (tt5ct + 90))) / 180
    draw_sprite_ext(sbmobwn2tt, (1 + global.time * 0.09), (vttcx - 8 / vtthoriz), (vttcy - 12 / vttvert - z), 0.6, vadtr0, tt0ct, -1, alpha)
    draw_sprite_ext(sbmobwn2tt, (3 + global.time * 0.092), (vttcx + 8 / vtthoriz), (vttcy - 16 / vttvert - z), 0.9, vadtr1, tt1ct, -1, alpha)
    draw_sprite_ext(sbmobwn2tt, (4 + global.time * 0.094), (vttcx - 12 / vtthoriz), (vttcy + 4 / vttvert - z), 0.65, vadtr2, tt2ct, -1, alpha)
    draw_sprite_ext(sbmobwn2tt, (7 + global.time * 0.096), (vttcx + 12 / vtthoriz), (vttcy - 4 / vttvert - z), 0.95, vadtr3, tt3ct, -1, alpha)
    draw_sprite_ext(sbmobwn2tt, (5 + global.time * 0.098), (vttcx - 16 / vtthoriz), (vttcy + 12 / vttvert - z), 0.7, vadtr4, tt4ct, -1, alpha)
    draw_sprite_ext(sbmobwn2tt, (0 + global.time * 0.1), (vttcx + 16 / vtthoriz), (vttcy + 12 / vttvert - z), 1, vadtr5, tt5ct, -1, alpha)
}
draw_sprite_ext(sprite_index, image_index, x, (y - z), (facing * 1), 1, 0, -1, alpha)
if (flash > 0)
{
    shader_set(shflash)
    draw_sprite_ext(sprite_index, image_index, x, (y - z + ford * 12 + changey), (facing * image_xscale), image_yscale, 0, -1, flash)
    shader_reset()
}
