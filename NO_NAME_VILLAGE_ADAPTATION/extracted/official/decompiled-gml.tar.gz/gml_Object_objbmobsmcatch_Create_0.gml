image_speed = 0
scrsplash(x, y, sbmobsmsplash1, 0)
spd = 0.2
deccl = 16
dir = scrdir(self, objbmobsm)
pcatch = 0
splash = 0
timer = scrdist(self, objbmobsm)
