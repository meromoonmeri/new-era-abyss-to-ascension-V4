draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, 0, c_white, image_alpha)
if (global.season == 2)
{
    shader_set(shcolreplace)
    shader_set_uniform_f(range, 1)
    shader_set_uniform_f(colmatch, 0.11372549019607843, 0.7529411764705882, 0.8235294117647058)
    shader_set_uniform_f(colreplace, 0.8392156862745098, 0.6039215686274509, 0.3058823529411765)
    draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, 0, c_white, image_alpha)
    shader_reset()
    shader_set(shcolreplace)
    shader_set_uniform_f(range, 1)
    shader_set_uniform_f(colmatch, 0.09019607843137255, 0.6274509803921569, 0.6862745098039216)
    shader_set_uniform_f(colreplace, 0.8392156862745098, 0.44313725490196076, 0.3058823529411765)
    draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, 0, c_white, image_alpha)
    shader_reset()
}
if (flash > 0)
{
    shader_set(shflash)
    draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, 0, c_white, flash)
    shader_reset()
}
