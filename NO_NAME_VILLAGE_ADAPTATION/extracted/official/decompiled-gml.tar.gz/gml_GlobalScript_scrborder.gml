function scrborder(argument0) //gml_Script_scrborder
{
    var w = camera_get_view_width(view_camera[0])
    var h = camera_get_view_height(view_camera[0])
    var b = h / 15
    draw_set_color(c_black)
    draw_set_alpha(argument0)
    draw_rectangle(0, 0, w, b, 0)
    draw_rectangle(0, h, w, (h - b), 0)
    draw_set_alpha(1)
}

