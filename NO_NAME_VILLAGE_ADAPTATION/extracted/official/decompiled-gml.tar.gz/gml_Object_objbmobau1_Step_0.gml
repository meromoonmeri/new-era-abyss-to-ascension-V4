var accl = 0.2
if (z >= 0)
{
    z += vel
    vel -= accl
    part_system_depth(ps, (-y))
    part_particles_create(ps, x, (y - z), pt, 1)
}
