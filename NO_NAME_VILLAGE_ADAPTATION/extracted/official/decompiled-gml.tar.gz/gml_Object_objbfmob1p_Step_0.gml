if (state == 0)
{
    depth = (-y)
    if (z > 0)
    {
        zvel -= 0.3
        z += zvel
    }
    else
        state = 1
}
if (state == 1)
{
    if layer_exists("water")
        depth = layer_get_depth("water") + 4
    if (image_index < (image_number - 0.5))
        image_speed = 0.2
    else
        image_speed = 0
}
