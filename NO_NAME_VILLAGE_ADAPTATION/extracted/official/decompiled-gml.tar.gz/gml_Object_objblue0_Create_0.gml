depth = (-y)
