if (xscale == 0)
{
    draw_set_font(font)
    var _Widest = 0
    var _Size = array_length_1d(text)
    for (var i = 0; i < _Size; i++)
    {
        var _Width = string_width(text[i][0])
        if (_Widest < _Width)
            _Widest = _Width
    }
    xscale = max(_Width / 20 + 3.2)
}
if (yscalemax == 0)
    yscalemax = 3 + 3 * ((array_length_1d(text) - 1) * 0.8)
if (objplayer.state == 5 || objplayer.state == 6)
    state = -1
if (state == 1)
{
    if (yscale < yscalemax)
        yscale += 1
    else
        state = 0
}
else if (state == 0)
{
    yscale = yscalemax
    bxscale = xscale - 0.8
    if (caninput == true)
    {
        if (by < (48 * bar))
            by += 24
        else if (by > (48 * bar))
            by -= 24
        if scrinput("upp")
        {
            if (bar > 0)
            {
                bar -= 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
        if scrinput("downp")
        {
            if (bar < (array_length_1d(text) - 1))
            {
                bar += 1
                scrsound(snclick0, 50, 0.5, 1)
            }
        }
        if scrinput("actionp")
            select = 1
        else if scrinput("actionr")
        {
            state = -1
            scrsound(snclick1, 50, 0.5, 1.2)
        }
        if scrinput("runp")
        {
            state = -1
            scrsound(snclick1, 50, 0.5, 0.8)
        }
    }
    else if (!scrinput("action"))
        caninput = true
}
else if (state == -1)
{
    if (yscale > 0)
        yscale -= 1
    else
    {
        objplayer.caninput = true
        instance_destroy()
    }
}
