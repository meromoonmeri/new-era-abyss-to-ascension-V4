function scrregequip(argument0) //gml_Script_scrregequip
{
    if (scritemcheck(argument0) > 0)
    {
        if (scritemcheck(argument0) == 2)
        {
            global.equipitem[0][0] = global.equipitem[3][0]
            global.equipitem[3][0] = argument0
        }
        else if (scritemcheck(argument0) == 1)
        {
            for (var k = 0; k <= 3; k++)
            {
                for (var l = 0; l <= 2; l++)
                {
                    if (global.invitem[k][l] == argument0)
                    {
                        global.invitem[k][l] = global.equipitem[3][0]
                        global.equipitem[3][0] = argument0
                    }
                }
            }
        }
    }
}

