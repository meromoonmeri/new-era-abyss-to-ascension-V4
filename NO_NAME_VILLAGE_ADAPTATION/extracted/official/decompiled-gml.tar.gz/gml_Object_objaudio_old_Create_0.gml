if (!variable_global_exists("music"))
    global.music = 1
if (!variable_global_exists("sound"))
    global.sound = 1
music = -1
sound = -1
boss = false
pausenoise = false
