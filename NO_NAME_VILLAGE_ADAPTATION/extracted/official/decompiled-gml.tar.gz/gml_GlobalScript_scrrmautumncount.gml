function scrrmautumncount() //gml_Script_scrrmautumncount
{
    var autumncount = 0
    if (global.mapgrid[1][4] > 0)
        autumncount += 1
    if (global.mapgrid[2][3] > 0)
        autumncount += 1
    if (global.mapgrid[2][4] > 0)
        autumncount += 1
    if (global.mapgrid[2][5] > 0)
        autumncount += 1
    if (global.mapgrid[3][2] > 0)
        autumncount += 1
    if (global.mapgrid[3][3] > 0)
        autumncount += 1
    if (global.mapgrid[3][4] > 0)
        autumncount += 1
    if (global.mapgrid[3][5] > 0)
        autumncount += 1
    if (global.mapgrid[3][6] > 0)
        autumncount += 1
    if (global.mapgrid[4][3] > 0)
        autumncount += 1
    if (global.mapgrid[4][4] > 0)
        autumncount += 1
    if (global.mapgrid[4][5] > 0)
        autumncount += 1
    return autumncount;
}

