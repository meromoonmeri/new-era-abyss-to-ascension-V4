event_inherited()
mob = -1
hit = -2
state = 0
dir = 0
dist = 0
z = 280
spd = 60
timer1 = 0
alpha = 1
salpha = 0
sindex = 0
