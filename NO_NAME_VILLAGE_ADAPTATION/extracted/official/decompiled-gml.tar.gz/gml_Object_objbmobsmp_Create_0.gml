image_speed = 0.2
fl = 0
dir = 0
spd = 6
z = 12
vel = 8
noncol = false
size = 1.5
shalpha = 0.1
if (!variable_global_exists("ptwater0"))
{
    global.ptwater0 = part_system_create()
    part_system_depth(global.ptwater0, ((-y) - z * vel - 4))
}
if (!variable_global_exists("ptwater1"))
{
    global.ptwater1 = part_system_create()
    part_system_depth(global.ptwater1, ((-y) - z * vel))
}
pt0 = part_type_create()
pt1 = part_type_create()
pt2 = part_type_create()
part_type_sprite(pt0, 2650, 0, 0, 1)
part_type_scale(pt0, 4, 4)
part_type_size(pt0, 1, 1, -0.05, 0)
part_type_alpha2(pt0, 1, 0)
part_type_life(pt0, 5, 10)
part_type_sprite(pt1, 60, 0, 0, 1)
part_type_scale(pt1, 4, 4)
part_type_size(pt1, 1, 1, -0.01, 0)
part_type_gravity(pt1, 0.06, 270)
part_type_life(pt1, 10, 20)
part_type_death(pt1, 1, pt2)
part_type_sprite(pt2, 1828, 0, 0, 1)
part_type_scale(pt2, 4, 4)
part_type_size(pt2, 1, 1, -0.02, 0)
part_type_speed(pt2, 1, 1.2, 0, 0)
part_type_direction(pt2, 0, 360, 0, 0)
part_type_gravity(pt2, 0.1, 270)
part_type_alpha3(pt2, 1, 0.6, 0)
part_type_life(pt2, 10, 35)
