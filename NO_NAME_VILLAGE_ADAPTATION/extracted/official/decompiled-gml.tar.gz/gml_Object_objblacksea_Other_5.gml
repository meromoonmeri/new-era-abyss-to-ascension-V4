if surface_exists(blacksea)
    surface_free(blacksea)
if part_system_exists(part_system)
{
    part_particles_clear(part_system)
    part_system_destroy(part_system)
    part_emitter_destroy(part_system, part_emitter)
    part_type_destroy(part_type)
}
if part_system_exists(part_system2)
{
    part_particles_clear(part_system2)
    part_system_destroy(part_system2)
    part_emitter_destroy(part_system2, part_emitter2)
    part_type_destroy(part_type2)
}
if part_system_exists(ps)
{
    part_particles_clear(ps)
    part_system_destroy(ps)
    part_emitter_destroy(ps, pe)
    part_type_destroy(pt)
}
instance_destroy()
