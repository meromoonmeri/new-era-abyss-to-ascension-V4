function scrview(argument0, argument1, argument2) //gml_Script_scrview
{
    objplayerview.target = -4
    objplayerview.targetx = argument0
    objplayerview.targety = argument1
    if (argument2 > 0)
    {
        objplayerview.x = argument0
        objplayerview.y = argument1
    }
    return point_distance(objplayerview.x, objplayerview.y, argument0, argument1);
}

