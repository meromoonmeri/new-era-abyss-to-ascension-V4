if (sprite != -4)
{
    sprite_index = sprite
    image_index = random(image_number)
    sprite = -4
}
if (watershad != -4)
{
    if layer_exists("undermarsh")
    {
        var shad = layer_sprite_create("undermarsh", x, y, watershad)
        layer_sprite_xscale(shad, (image_xscale * 4))
        layer_sprite_yscale(shad, (image_yscale * 4))
    }
    watershad = -4
}
if (shadshad != -4)
{
    if layer_exists("shadows")
    {
        var shadow = layer_sprite_create("shadows", x, y, shadshad)
        layer_sprite_xscale(shadow, (image_xscale * 4))
        layer_sprite_yscale(shadow, (image_yscale * 4))
    }
    shadshad = -4
}
