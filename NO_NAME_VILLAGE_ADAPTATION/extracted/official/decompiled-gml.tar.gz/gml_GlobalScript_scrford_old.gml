function scrford_old() //gml_Script_scrford_old
{
    if (x >= 0 && x < room_width && y >= 0 && y <= room_height)
    {
        if (scrlocation(room) != 2)
        {
            if (scrlocation(room) != 0.5 && (!layer_exists("blue1")))
            {
                if (global.season != 3 && global.season != 6)
                {
                    if (ford == 0)
                    {
                        if (layer_exists("water0") || layer_exists("water1") || layer_exists("water"))
                        {
                            var groundcheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("ground")), x, y)
                            var grasscheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass0")), x, y)
                            if (groundcheck <= 0 && grasscheck <= 0)
                            {
                                if (room != rm83)
                                {
                                    ford = 1
                                    scrsplash(x, y, ssplash0, 0)
                                }
                                else if (!(place_meeting(x, y, objrm830)))
                                {
                                    ford = 1
                                    scrsplash(x, y, ssplash0, 0)
                                }
                                else
                                {
                                    canrun = true
                                    ford = 2
                                }
                            }
                            else
                                ford = 0
                        }
                    }
                    else if (ford == 1)
                    {
                        groundcheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("ground")), x, y)
                        grasscheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass0")), x, y)
                        if (groundcheck > 0 || grasscheck > 0)
                        {
                            if (!(position_meeting(x, y, objdpuddle)))
                            {
                                ford = 0
                                canrun = true
                                scrsplash(x, y, ssplash0, 1)
                            }
                            else
                                canrun = false
                        }
                        else
                        {
                            canrun = false
                            if (room == rm83)
                            {
                                if place_meeting(x, y, objrm830)
                                {
                                    canrun = true
                                    ford = 2
                                }
                            }
                        }
                    }
                    else if (ford == 2)
                    {
                        if (!(place_meeting(x, y, objrm830)))
                            ford = 1
                    }
                }
                else if (scrlocation(room) != 2 && scrlocation(room) != 3)
                {
                    if (ford == 0)
                    {
                        if layer_exists("grass1")
                        {
                            var grasscheck1 = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass1")), x, y)
                            var grasscheck0 = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass0")), x, y)
                            groundcheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("ground")), x, y)
                            if (grasscheck0 > 0 || grasscheck1 > 0 || groundcheck > 0)
                                ford = 1
                        }
                    }
                    else if (ford == 1)
                    {
                        if layer_exists("grass1")
                        {
                            grasscheck1 = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass1")), x, y)
                            grasscheck0 = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass0")), x, y)
                            groundcheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("ground")), x, y)
                            if (grasscheck0 <= 0 && grasscheck1 <= 0 && groundcheck <= 0)
                                ford = 0
                        }
                        else
                            ford = 0
                    }
                }
                else
                    ford = 0
            }
            else if layer_exists("blue1")
            {
                if (ford == 0)
                {
                    if layer_exists("water")
                    {
                        var grass1check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass1")), x, y)
                        var grass0check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass0")), x, y)
                        if (grass1check <= 0 && grass0check <= 0)
                        {
                            scrsplash(x, y, ssplash0, 1)
                            ford = 2
                        }
                        else
                            ford = 0
                    }
                }
                else if (ford == 1)
                {
                    var bluecheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("blue0")), x, y)
                    if (bluecheck > 0)
                    {
                        if (!(position_meeting(x, y, objdpuddle)))
                        {
                            scrsplash(x, y, ssplash0, 1)
                            ford = 2
                            canrun = true
                        }
                    }
                    else
                        canrun = false
                }
                else if (ford == 2)
                {
                    grass1check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass1")), x, y)
                    grass0check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass0")), x, y)
                    bluecheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("blue0")), x, y)
                    if (grass1check > 0 || grass0check > 0)
                    {
                        if (!(position_meeting(x, y, objdpuddle)))
                        {
                            scrsplash(x, y, ssplash0, 1)
                            canrun = true
                            ford = 0
                        }
                    }
                    else if (bluecheck <= 0)
                    {
                        scrsplash(x, y, ssplash0, 1)
                        ford = 1
                    }
                }
            }
            else if (ford == 0)
            {
                if (layer_exists("water0") || layer_exists("water1") || layer_exists("water"))
                {
                    grass1check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass1")), x, y)
                    grass0check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass0")), x, y)
                    if (grass1check <= 0 && grass0check <= 0)
                    {
                        scrsplash(x, y, ssplash0, 1)
                        ford = 2
                    }
                    else
                        ford = 0
                }
            }
            else if (ford == 1)
            {
                groundcheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("ground")), x, y)
                if (groundcheck > 0)
                {
                    if (!(position_meeting(x, y, objdpuddle)))
                    {
                        scrsplash(x, y, ssplash0, 1)
                        ford = 2
                        canrun = true
                    }
                }
                else
                    canrun = false
            }
            else if (ford == 2)
            {
                grass1check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass1")), x, y)
                grass0check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("grass0")), x, y)
                groundcheck = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("ground")), x, y)
                if (grass1check > 0 || grass0check > 0)
                {
                    if (!(position_meeting(x, y, objdpuddle)))
                    {
                        scrsplash(x, y, ssplash0, 1)
                        canrun = true
                        ford = 0
                    }
                }
                else if (groundcheck == 0)
                {
                    scrsplash(x, y, ssplash0, 1)
                    ford = 1
                }
            }
        }
        else if (ford == 0)
        {
            if (layer_exists("water0") || layer_exists("water1"))
            {
                var water0check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("water0")), x, y)
                var wall1check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("wall1")), x, y)
                if (water0check != 0 && wall1check == 0)
                {
                    ford = 1
                    scrsplash(x, y, ssplash0, 0)
                }
                else
                    ford = 0
            }
        }
        else if (ford == 1)
        {
            water0check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("water0")), x, y)
            wall1check = tilemap_get_at_pixel(layer_tilemap_get_id(layer_get_id("wall1")), x, y)
            if (water0check == 0 || wall1check == 1)
            {
                ford = 0
                canrun = false
                scrsplash(x, y, ssplash0, 1)
            }
            else
                canrun = true
        }
    }
}

