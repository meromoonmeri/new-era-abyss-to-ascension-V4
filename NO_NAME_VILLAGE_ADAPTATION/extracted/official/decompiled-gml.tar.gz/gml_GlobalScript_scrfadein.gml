function scrfadein(argument0) //gml_Script_scrfadein
{
    with (objplayer)
        caninput = false
    if (objplayerview.lat < 1)
    {
        objplayerview.la = 1
        objplayerview.latt = argument0
    }
    else
    {
        objplayerview.latt = 0.025
        return 1;
    }
}

