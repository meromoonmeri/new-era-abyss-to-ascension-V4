event_inherited()
sprite = 2428
watershad = 2002
shadshad = 934
