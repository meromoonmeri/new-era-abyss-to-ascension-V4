draw_sprite_ext(sprite_index, 0, x, (y - z), image_xscale, image_yscale, 0, -1, 1)
