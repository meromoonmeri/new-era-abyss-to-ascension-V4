mpause = 0
