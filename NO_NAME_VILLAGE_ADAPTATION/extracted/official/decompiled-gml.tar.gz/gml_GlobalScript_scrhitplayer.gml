function scrhitplayer(argument0, argument1, argument2, argument3) //gml_Script_scrhitplayer
{
    if instance_exists(argument0)
    {
        if (argument0.iframe > 0)
            return;
        if (argument0 != objft0)
            objplayer.hp -= argument1
        else
            objft0.hp -= argument1
        argument0.iframe = 1
        argument0.state = 6
        argument0.dir = argument2
        argument0.caninput = false
        argument0.image_index = 0
        objplayerview.shaket = argument3
        return 1;
    }
}

