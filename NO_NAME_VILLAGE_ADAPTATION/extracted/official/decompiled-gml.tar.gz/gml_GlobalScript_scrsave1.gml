function scrsave1(argument0, argument1) //gml_Script_scrsave1
{
    scrsave(argument0, argument1)
    ini_open("NoNameVillage.ini")
    var sav = "save" + string(argument1)
    if (global.autosave == 1 || argument0 == 1)
    {
        if (argument0 == 0)
            ini_write_real(sav, "room", room)
        else
        {
            room_goto(ini_read_real(sav, "room", 10))
            if variable_global_exists("roomgoto")
                global.roomgoto = ini_read_real(sav, "room", -4)
        }
        if (argument0 == 0)
            ini_write_real(sav, "positionx", objplayer.x)
        else
            objplayer.x = ini_read_real(sav, "positionx", 544)
        if (argument0 == 0)
            ini_write_real(sav, "positiony", objplayer.y)
        else
            objplayer.y = ini_read_real(sav, "positiony", 516)
        if (argument0 == 0)
            ini_write_real(sav, "direction", objplayer.dir)
        else
            objplayer.dir = ini_read_real(sav, "direction", 0)
        if (argument0 == 0)
            ini_write_real(sav, "hp", objplayer.hp)
        else
            objplayer.hp = ini_read_real(sav, "hp", objplayer.maxhp)
        if (argument0 == 0)
            ini_read_real(sav, "heals", objplayer.healcount)
        else
            objplayer.healcount = ini_read_real(sav, "heals", objplayer.heallvl)
    }
    ini_close()
}

