if (room == rm31)
{
    with (objplayerview)
    {
        if (y > 3072)
            shaket = 8
    }
    bsalpha = clamp(((room_height - objplayer.y) / 576), 0, 1)
    if (event == 0 && objplayer.y < 3072)
    {
        event = 1
        part_emitter_stream(ps, pe, pt, -30)
    }
}
if surface_exists(blacksea)
{
    surface_set_target(blacksea)
    gpu_set_blendmode(bm_normal)
    draw_set_color(c_black)
    draw_set_alpha(0.75 + objblacksea.bsalpha * 0.25)
    draw_rectangle(0, 0, room_width, room_height, false)
    gpu_set_blendmode(bm_subtract)
    draw_set_color(c_white)
    with (objplayer)
        screllipserg(x, y, 0, 0, (256 + 256 * (1 - other.bsalpha)), (128 + 128 * (1 - other.bsalpha)), 8421504, 0, 0.4, 0)
    with (objoldman)
    {
        screllipserg(x, y, 0, 0, 512, 256, 8421504, 0, objblacksea.charalph, 0)
        if (sprite_index == sommi0)
            draw_sprite_ext(sommi0l, 0, x, y, 1, 1, 0, -1, 0.5)
        if (sprite_index == sommw0)
            draw_sprite_ext(sommw0l, image_index, x, y, 1, 1, 0, -1, 0.5)
    }
    gpu_set_blendmode(bm_normal)
    with (objoldman)
    {
        screllipserg(x, y, 0, 0, 512, 256, 8421504, 0, objblacksea.charalph, 0)
        if (sprite_index == sommi0)
            draw_sprite_ext(sommi0l, 0, x, y, 1, 1, 0, -1, 1)
        if (sprite_index == sommw0)
            draw_sprite_ext(sommw0l, image_index, x, y, 1, 1, 0, -1, 1)
    }
    gpu_set_blendmode(bm_normal)
    draw_set_alpha(1)
    surface_reset_target()
}
with (objplayer)
{
    if (state == 13)
    {
        if (image_index > 3)
        {
            if (objblacksea.dust != 0)
            {
                objblacksea.dust = 0
                scrtrail(x, y, 1240, 0, 1)
            }
        }
        else if (image_index > 2)
        {
            if (objblacksea.dust != 1)
            {
                objblacksea.dust = 1
                scrtrail(x, y, 1240, 0, 1)
            }
        }
        else if (image_index > 1)
        {
            if (objblacksea.dust != 2)
            {
                objblacksea.dust = 2
                scrtrail(x, y, 1240, 0, 1)
            }
        }
        else if (image_index > 0)
        {
            if (objblacksea.dust != 3)
            {
                objblacksea.dust = 3
                scrtrail(x, y, 1240, 0, 1)
            }
        }
    }
}
with (objoldman)
{
    if (state == 4)
    {
        if (image_index > 3)
        {
            if (objblacksea.dust != 0)
            {
                objblacksea.dust = 0
                scrtrail(x, y, 1240, 0, 0.5)
            }
        }
        else if (image_index > 2)
        {
            if (objblacksea.dust != 1)
            {
                objblacksea.dust = 1
                scrtrail(x, y, 1240, 0, 0.5)
            }
        }
        else if (image_index > 1)
        {
            if (objblacksea.dust != 2)
            {
                objblacksea.dust = 2
                scrtrail(x, y, 1240, 0, 0.5)
            }
        }
        else if (image_index > 0)
        {
            if (objblacksea.dust != 3)
            {
                objblacksea.dust = 3
                scrtrail(x, y, 1240, 0, 0.5)
            }
        }
    }
    else if (state == 3)
    {
        if (objblacksea.dust != 4)
        {
            objblacksea.dust = 4
            scrtrail(x, y, 1240, 0, 0.8)
        }
    }
}
if (objplayerview.y > 3200)
{
    if (soundtimer0 < 1)
        soundtimer0 += (1/120)
    if (soundtimer1 < 1)
        soundtimer1 += (1/120)
}
else
{
    if (soundtimer0 > 0.2)
        soundtimer0 += 0.006666666666666667
    if (soundtimer1 > 0)
        soundtimer0 += (1/120)
}
if (stopsound == 0)
{
    audio_sound_gain(snbs0, (soundtimer0 * global.sound), 0)
    var yscale = clamp(((objplayerview.y - 3492) / 1500), 0, 1)
    audio_sound_gain(snbs1, (yscale * soundtimer1 * global.sound), 0)
}
else
{
    audio_sound_gain(snbs0, 0, 1000)
    audio_sound_gain(snbs1, 0, 1000)
}
