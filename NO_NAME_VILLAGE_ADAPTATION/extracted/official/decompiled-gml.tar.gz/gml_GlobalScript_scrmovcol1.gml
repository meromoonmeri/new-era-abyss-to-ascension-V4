function scrmovcol1(argument0, argument1) //gml_Script_scrmovcol1
{
    var lendirx = lengthdir_x(argument0, argument1)
    var lendiry = lengthdir_y(argument0, argument1)
    var scrspd = argument0
    if (object_index == objplayer || object_index == objfollower)
        scrspd = spd
    var newdir = 0
    var col = ds_list_create()
    ds_list_add(col, 435)
    if (fl == 0)
        ds_list_add(col, 447)
    else
        ds_list_add(col, 39)
    for (var cn = 0; cn < ds_list_size(col); cn++)
    {
        if instance_place((x + (lengthdir_x((scrspd * 2), argument1))), (y + (lengthdir_y((scrspd * 2), argument1))), ds_list_find_value(col, cn))
        {
            lendirx = 0
            lendiry = 0
            var slidecol = false
            var sdir = 0
            while (sdir <= 80)
            {
                var n = -1
                while (n <= 1)
                {
                    newdir = sdir * n + argument1
                    var targetx = lengthdir_x((argument0 * ((90 - sdir) / 90)), newdir)
                    var targety = lengthdir_y((argument0 * ((90 - sdir) / 90)), newdir)
                    if (!(place_meeting((x + targetx), (y + targety), ds_list_find_value(col, cn))))
                    {
                        lendirx = targetx
                        lendiry = targety
                        slidecol = true
                        break
                    }
                    else
                    {
                        n += 2
                        continue
                    }
                }
                if (slidecol == true)
                    break
                else
                {
                    sdir += 10
                    continue
                }
            }
        }
    }
    x += lendirx
    y += lendiry
    ds_list_destroy(col)
}

