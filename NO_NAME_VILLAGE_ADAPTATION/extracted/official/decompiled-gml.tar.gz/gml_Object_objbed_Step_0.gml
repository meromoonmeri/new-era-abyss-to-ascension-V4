if (interact == true)
{
    if (objplayer.stage == 0.53)
    {
        if scritemcheck(6)
            state = 4
        else
            scrtbox(0, [[0, 394, "I should find something to keep myself busy until dinner."]])
    }
    else if (objplayer.stage >= 1.5 && objplayer.stage <= 1.53)
    {
        if scritemcheck(6)
            state = 4
        else
            scrtbox(0, [[0, 394, "Let me find that book first before I go to bed."]])
    }
    else
    {
        state = 4
        timer = 0
    }
}
event_inherited()
if (state == 0)
{
    sprite_index = sbed
    image_speed = 0
    image_index = 0
}
if (state == 1)
{
    objplayerview.target = self
    with (objplayer)
    {
        caninput = false
        alpha = 0
        x = 0
        y = 0
    }
    with (objstage)
        ds_list_destroy(persistentrooms)
    sprite_index = sbedup
    if (timer1 == -1)
    {
        image_index = 0
        image_speed = 0
    }
    else if (timer1 < 120)
        timer1 += 1
    else if (image_index < 3)
        image_speed = 0.1
    else if (image_index < 4)
    {
        if (pause2 == true && image_index > 3.5)
            image_speed = 0
        else
            image_speed = 0.025
    }
    else if (image_index < (image_number - 0.5))
    {
        if (image_speed != 0.2)
        {
            image_speed = 0.2
            scrsound(sncloth1, 50, 1, 1)
        }
    }
    else if (pause1 == true)
        image_speed = 0
    else
        image_speed = 0.1
}
if (state == 2)
{
    sprite_index = sbedoff
    if (image_index > 1 && image_index < 2 && timer2 != 1)
    {
        timer2 = 1
        scrsound(sncloth0, 50, 1, 1)
    }
    if (image_index > 4 && image_index < 5 && timer2 != 2)
    {
        timer2 = 2
        scrsound(snpfs, 10, 0.75, 1)
    }
    if (image_index < 5)
        image_speed = 0.3
    else
        image_speed = 0.1
}
if (state == 3)
{
    sprite_index = sbedtidy
    if (image_index > 3 && image_index < 4 && timer3 != 1)
    {
        timer3 = 1
        scrsound(sncloth0, 50, 0.5, 1)
    }
    if (image_index > 5 && image_index < 6 && timer3 != 2)
    {
        timer3 = 2
        scrsound(sncloth1, 50, 1, 1)
    }
    if (image_index > 9 && image_index < 10 && timer3 != 3)
    {
        timer3 = 3
        scrsound(snpfs, 50, 0.2, 1)
    }
    if (image_index > 11 && image_index < 12 && timer3 != 4)
    {
        timer3 = 4
        scrsound(snpfs, 50, 0.2, 1)
    }
    if (image_index < 1)
        image_speed = 0.1
    else if (image_index < (image_number - image_speed))
        image_speed = 0.2
    else
    {
        objplayerview.target = 100
        objplayer.x = x + 140
        objplayer.y = y + 124
        objplayer.dir = 225
        objplayer.alpha = 1
        objplayer.fl = 0
        objplayer.caninput = true
        state = 0
    }
}
if (state == 4)
{
    objplayerview.target = self
    objplayer.caninput = false
    objplayer.alpha = 0
    sprite_index = sbedon
    if (image_index > 0 && image_index < 1 && timer3 != 1)
    {
        timer3 = 1
        scrsound(sncloth0, 50, 1, 1)
    }
    if (image_index > 3 && image_index < 4 && timer3 != 2)
    {
        timer3 = 2
        scrsound(sncloth1, 50, 1, 1)
    }
    if (image_index < (image_number - 0.5))
        image_speed = 0.2
    else
    {
        image_speed = 0
        if (scritemcheck(6) == 1)
        {
            state = 5
            image_index = 0
            while (scritemcheck(6) == 1)
                scrdeleteitem(6)
        }
        else if (scr9slice((x + 112), (y + 40), [[box[1]], [box[2]]]) == -1)
        {
            image_index = 0
            if (optboxselect == 0)
            {
                state = 6
                image_index = 0
            }
            else if (optboxselect == 1)
                state = 7
            else
            {
                state = 1
                pause1 = false
                image_index = 4
                image_speed = 0.2
            }
            optboxselect = -1
            optbox = 0
        }
    }
}
if (state == 5)
{
    sprite_index = sbedread
    var book = 0
    if (objplayer.stage < 1)
        book = 1
    else if (objplayer.stage < 2)
        book = 2
    else
        state = 6
    if (image_index < 1)
    {
        image_speed = (1/30)
        timer5 = 0
    }
    else if (image_index < (image_number - 1))
    {
        if (image_index < 2 && timer5 == 0)
        {
            timer5 = 1
            scrsound(sncloth1, 50, 1, 1)
        }
        else if (image_index < 3 && timer5 == 1)
        {
            timer5 = 2
            scrsound(snmenu0, 50, 1, 1)
        }
        image_speed = 0.2
    }
    else if (image_index < (image_number - 0.5))
        image_speed = 0.016666666666666666
    else
    {
        image_speed = 0
        if (state5 < 1)
        {
            if scrfadein(0.025)
            {
                state5 = 1
                room_goto(rmempty)
                if (book == 1)
                    instance_create_layer(0, 0, "instances", objcutbook1)
                if (book == 2)
                    instance_create_layer(0, 0, "instances", objcutbook2)
            }
        }
    }
}
if (state == 6)
{
    sprite_index = sbedsleep
    if (timer == 0)
    {
        scrtimetofadein(60, 0.01)
        if (image_index < 1)
            image_speed = 0.05
        else if (image_index < (image_number - 0.5))
            image_speed = 0.1
        else
            image_speed = 0
    }
    else if (timer == 1)
    {
        with (objstage)
            ds_list_destroy(persistentrooms)
        ds_map_clear(global.svrm)
        scrdeleteitem(6)
        with (objplayer)
        {
            hp = maxhp
            healcount = heallvl
        }
        timer = 2
        with (objsteamstats)
            check_sleep = 1
    }
    else if (timer == 2)
        scrtimetofadeout(120, 0.02)
    else if (timer < 120)
        timer += 1
    else
    {
        timer = 0
        state = 1
    }
}
b71y -= ((b71y - b71yt) / 5)
b72y -= ((b72y - b72yt) / 5)
b73y -= ((b73y - b73yt) / 5)
b74y -= ((b74y - b74yt) / 5)
if (state == 7)
{
    image_index = image_number - 0.5
    blur += ((25 - blur) / 12)
    fx_set_parameter(fxblur, "g_Radius", blur)
    if (select7 == -1)
        b7t = clamp((b7t + 0.2), 0, 4)
    else if (select7 == -2)
    {
        if (b7t > 0)
            b7t = clamp((b7t - 0.2), 0, 4)
        else
            state = 4
    }
    if (b7t >= 1)
        b71yt = 0
    else
        b71yt = 972
    if (b7t >= 2)
        b72yt = 0
    else
        b72yt = 972
    if (b7t >= 3)
        b73yt = 0
    else
        b73yt = 972
    if (b7t >= 4)
        b74yt = 0
    else
        b74yt = 972
    if (select7 < 0)
    {
        confirm7 = 0
        if (b7t >= 4)
        {
            if (scrinput("upp") && row7 > 0)
            {
                row7 -= 1
                scrsound(snclick0, 50, 0.8, random_range(0.5, 1.5))
            }
            if (scrinput("downp") && row7 < 3)
            {
                row7 += 1
                scrsound(snclick0, 50, 0.8, random_range(0.5, 1.5))
            }
            if scrinput("runp")
            {
                select7 = -2
                scrsound(snclick0, 50, 0.8, random_range(0.5, 1.5))
            }
            if scrinput("actionp")
            {
                select7 = row7
                scrsound(snclick0, 50, 0.8, random_range(0.5, 1.5))
            }
        }
    }
    else if (confirm7 < 2)
    {
        if (scrinput("leftp") && confirm7 < 1)
        {
            confirm7 += 1
            scrsound(snclick0, 50, 0.8, random_range(0.5, 1.5))
        }
        if (scrinput("rightp") && confirm7 > 0)
        {
            confirm7 -= 1
            scrsound(snclick0, 50, 0.8, random_range(0.5, 1.5))
        }
        if scrinput("runp")
        {
            select7 = -1
            scrsound(snclick0, 50, 0.8, random_range(0.5, 1.5))
        }
        if scrinput("actionp")
        {
            confirm7 += 2
            scrsound(snclick0, 50, 0.8, random_range(0.5, 1.5))
        }
    }
    else if scrinput("actionr")
    {
        if (confirm7 == 3)
        {
            ini_open("NoNameVillage.ini")
            if ini_section_exists("save" + string(select7))
                ini_section_delete("save" + string(select7))
            ini_close()
            scrsave1(0, select7)
        }
        select7 = -1
        scrsound(snclick0, 50, 0.8, random_range(0.5, 1.5))
    }
}
else
{
    if (state != 0)
    {
        fx_set_parameter(fxblur, "g_Radius", blur)
        blur += ((-blur) / 12)
    }
    select7 = -1
}
