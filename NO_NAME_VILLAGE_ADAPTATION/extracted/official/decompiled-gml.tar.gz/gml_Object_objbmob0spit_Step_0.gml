event_inherited()
if (z > 0)
{
    z += vvel
    vvel -= vaccl
    chit = 2
    if (!(position_meeting((x + (lengthdir_x((spd * 40), dir))), (y + (lengthdir_y((spd * 40), dir))), objallcol)))
    {
        x += lengthdir_x(spd, dir)
        y += lengthdir_y(spd, dir)
    }
    else
        z = -1
    if (hit == true)
        z = -1
}
else if (splash == 0)
{
    chit = 0
    objplayerview.shaket = 6
    scrsplash(x, y, ssplash0, 0)
    scrsound(snbmob0rocks0, 50, 1, random_range(0.7, 1))
    if (z == -1)
    {
        repeat (3)
        {
            var proj = instance_create_depth(x, y, depth, objbmob0spit0)
            proj.dir = dir + 180 + (irandom_range(-45, 45))
        }
    }
    else
    {
        repeat (3)
        {
            proj = instance_create_depth(x, y, depth, objbmob0spit0)
            proj.dir = dir + (irandom_range(-180, 180))
        }
    }
    with (objbmob0)
    {
        part_type_size(rock0, 0.4, 0.6, 0, 0)
        part_particles_create(part_system0, other.x, other.y, rock0, 1)
        part_type_size(rock0, 0.8, 1.2, 0, 0)
        part_type_size(rock1, 0.4, 0.6, 0, 0)
        part_particles_create(part_system1, other.x, other.y, rock1, 1)
        part_type_size(rock1, 0.8, 1.2, 0, 0)
        part_type_size(rock1, 0.4, 0.6, 0, 0)
        part_particles_create(part_system2, other.x, other.y, rock2, 1)
        part_type_size(rock2, 0.8, 1.2, 0, 0)
        part_type_size(ptw, 0.5, 0.5, 0.01, 0)
        part_particles_create(part_system2, other.x, other.y, ptw, 1)
        part_type_size(ptw, 1, 1, 0.01, 0)
    }
    part_system_depth(ps, ((-y) - 32))
    part_particles_create(ps, other.x, other.y, ptssp, 1)
    splash = 1
    z = 0
}
else if (spd > 0)
    spd += ((-spd) / 8)
else if (fadet > 0)
    fadet -= 1
else
    instance_destroy()
