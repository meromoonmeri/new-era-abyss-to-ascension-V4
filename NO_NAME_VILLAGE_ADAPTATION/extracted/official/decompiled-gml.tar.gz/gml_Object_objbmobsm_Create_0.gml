event_inherited()
mobname = "Adult Flatfrog"
image_speed = 0
mob = 3
state = -3
poise = 1
gbp = 150
level = 3
maxhp = 40
hp = maxhp
dmg = 1.5
aggro = 0
instance_create_layer(x, y, "watershadows", objbmobsmshad)
retreat = 0
timern1 = 0
timer01 = 0
timer02 = 0
timer03 = 0
timer04 = 0
timer05 = 0
awaydir = 0
awaydist = 0
dir1 = 0
dir1diff = 0
timer1 = 0
timer2 = 0
timer3 = 0
dir3 = 0
timer5 = 0
catch5 = 0
catchyvel = 6
event5 = 0
hitout = -1
timer6 = 0
timer7 = 0
timer8 = 0
timer85 = 0
timer9 = 0
event0 = 0
event1 = 0
part_system = part_system_create()
part_system_depth(part_system, (-room_height))
part_type2 = part_type_create()
part_type21 = part_type_create()
part_type22 = part_type_create()
part_type_sprite(part_type2, 501, 1, 1, 1)
part_type_color1(part_type2, 0)
part_type_alpha2(part_type2, 1, 1)
part_type_speed(part_type2, 6, 12, 0, 0)
part_type_direction(part_type2, 80, 100, 0, 0)
part_type_gravity(part_type2, 0.6, 270)
part_type_life(part_type2, 45, 45)
part_type_death(part_type2, 1, part_type21)
part_type_sprite(part_type21, 2425, 1, 1, 0)
part_type_life(part_type21, 15, 15)
part_type_death(part_type21, 1, part_type22)
part_type_sprite(part_type22, 501, 0, 0, 1)
part_type_alpha2(part_type22, 1, 1)
part_type_color1(part_type22, 0)
pssw = part_system_create()
part_system_depth(pssw, ((-room_height) * 2))
ptsw = part_type_create()
part_type_sprite(ptsw, 1041, 0, 0, 0)
part_type_scale(ptsw, 4, 4)
part_type_size(ptsw, 0.2, 0.3, 0.1, 0)
part_type_alpha3(ptsw, 0.6, 1, 0)
part_type_life(ptsw, 30, 30)
