function scrtextsounds() //gml_Script_scrtextsounds
{
}

