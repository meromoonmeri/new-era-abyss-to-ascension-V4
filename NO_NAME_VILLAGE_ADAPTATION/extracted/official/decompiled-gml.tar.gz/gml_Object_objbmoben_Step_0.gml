event_inherited()
with (objrm53)
    caninteract = false
if (state == -1)
{
    if (image_index == 0)
        image_speed = 0
    else if (image_index < 2)
        image_speed = 0.1
}
if (state == -2)
{
    scrspr8dir(dir, sbmobenc0, sbmobenc1, sbmobenc2, sbmobenc3, sbmobenc4)
    x = objrm53.x + 78
    prevx = x
    y = objrm53.y + 4
    prevy = y
    z = 380
    prevz = z
    if (image_index < 2)
        image_speed = 0.2
    else if (image_index < 3)
    {
        image_speed = 0.4
        with (objbmobencb1)
            instance_destroy()
        if (sound == 0)
        {
            sound = 1
            scrsound(snbmobenclap0, 50, 1, 1)
            scrsound(snbmobencharge0, 50, 1, 1)
        }
    }
    else if (image_index < 4)
    {
        image_speed = 0
        dir = idir
        if (!instance_exists(objbmobencb1))
        {
            var p = instance_create_layer(x, y, "instances", objbmobencb1)
            p.ct = 60
        }
        else
        {
            with (objbmobencb1)
            {
                x = (x + other.x + (lengthdir_x(12, other.dir))) / 2
                y = (y + other.y + (lengthdir_y(12, other.dir))) / 2
                z = other.z + 20
                if (state == 2)
                    other.image_index = 4
            }
        }
    }
    else if (image_index < 6)
        image_speed = 0.2
    else if (image_index < (image_number - image_speed))
        image_speed = (1/30)
    else
        image_index = 0
}
if (state == -3)
{
    dir = 271
    sprite_index = sbmobenbfall
    with (objplayerview)
    {
        target = -4
        targetx = other.x
        targety = other.y - other.z
        if (spd <= 2.5 && other.image_index < 1)
            other.image_index = 1
    }
    with (objbmobencb1)
    {
        if (cancel == 0)
            cancel = 2
    }
    with (objplayer)
        caninput = false
    var vpx = objplayer.x + (lengthdir_x(64, scrdir(objrm53, objplayer)))
    var vpy = objplayer.y + (lengthdir_y(64, scrdir(objrm53, objplayer)))
    if (image_index > 2 && image_index < 5)
        scrmovenpc(objplayer, vpx, vpy)
    else
        objplayer.dir = scrdir(objplayer, objrm53)
    if (image_index < 1)
        image_speed = 0
    else if (image_index < 3)
    {
        if (image_index < (1 + image_speed))
        {
            prevx = x
            prevz = z
        }
        image_speed = 0.15
        var v = (image_index - 1) / 2
        var v1 = (-(cos(pi * v / 2))) + 1
        var v1z = -1.2 * (cos(pi * v / 2)) + 1
        x = prevx + -60 * v1
        z = prevz + -32 * v1z
    }
    else if (image_index < 7)
    {
        if (image_index < (3 + image_speed))
        {
            prevx = x
            prevy = y
            prevz = z
            objplayerview.shaket = 6
            scrsound(snbmobenbell1, 50, 1, 1)
            with (objrm53)
            {
                hit = 0.5
                scrsplash(x, (y - 4), sbmobsmsplash0, 4)
            }
        }
        image_speed = 0.2
        v = (image_index - 3) / 4
        var v3 = (-(cos(pi * v / 2))) + 1
        var v3z = clamp((3 * (power(abs(v - 0.35), 3)) - 0.1), -1, 1)
        x = prevx + 36 * v3
        y = prevy + 136 * v3
        z = prevz - prevz * v3z
    }
    else
    {
        if (image_index < 7.5)
        {
            objplayerview.shaket = 8
            part_system_depth(ps, ((-y) - 16))
            part_system_depth(ps, ((-y) - 4))
            part_particles_create(ps, x, (y - 4), ptj, 1)
            scrsplash(x, (y - 4), sbmobenjsplash2, 0)
            scrsound(snsplash1, 9, 1, 1)
        }
        x = prevx + 36
        y = prevy + 136
        z = 0
        image_index = 7.5
        image_speed = 0
    }
}
if (state == 0)
{
    if (pattern < 0)
    {
        scrspr8dir(dir, sbmobeni0, sbmobeni1, sbmobeni2, sbmobeni3, sbmobeni4)
        if (objplayer.hp > 0)
            pattern += (phase / 60)
    }
    else if (pattern < 1)
    {
        if (phase == 1)
        {
            if (scrdist(self, objplayer) > 192)
                pattern = 11
            else
            {
                pattern = choose(12, 13)
                if (prevpat == 12)
                    pattern = 13
                if (prevpat == 13)
                    pattern = 12
                if (prevpat == -1)
                    pattern = 12
            }
        }
        if (phase == 2)
        {
            if (scrdist(self, objplayer) < 192)
            {
                pattern = choose(21, 22)
                if (prevpat == 21)
                    pattern = 22
                if (prevpat == 22)
                    pattern = 21
                if (prevpat == -1)
                    pattern = choose(21, 25)
            }
            else
            {
                pattern = choose(23, 24)
                if (prevpat == 23)
                    pattern = 24
                if (prevpat == 24)
                    pattern = 23
                if (prevpat == -1)
                    pattern = choose(21, 25)
            }
        }
        if (phase == 3)
        {
            if (prevpat == -1)
                pattern = choose(35, 36)
            else if (scrdist(self, objplayer) < 192)
            {
                pattern = choose(32, 34)
                if (prevpat == 32)
                    pattern = 34
                if (prevpat == 34)
                    pattern = 33
            }
            else
            {
                pattern = choose(31, 33)
                if (prevpat == 31)
                    pattern = 33
                if (prevpat == 33)
                    pattern = 31
            }
        }
        if (phase == 4)
        {
            state = 13
            dir = 270
            image_index = 0
        }
        prevpat = 0
    }
    var fpat = floor(pattern)
    if (fpat == 11)
    {
        if (pattern < 11.1)
        {
            dir = idir
            image_index = 0
            state = 2
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 12)
    {
        if (pattern < 12.1)
        {
            dir = idir + 180
            image_index = 0
            state = 6
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 13)
    {
        if (pattern < 13.1)
        {
            dir = idir
            image_index = 0
            state = 3
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 14)
    {
        if (pattern < 14.1)
        {
            dir = idir
            image_index = 0
            state = 5
            if (scrdist(self, objplayer) < 192)
                pattern += 0.1
            else
                pattern += 0.2
        }
        else if (pattern < 14.2)
        {
            dir = idir
            image_index = 0
            state = 2
            pattern += 0.2
        }
        else if (pattern < 14.3)
        {
            dir = idir
            image_index = 0
            state = 3
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 15)
    {
        if (pattern < 15.1)
        {
            dir = idir
            image_index = 0
            state = 9
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 21)
    {
        if (pattern < 21.1)
        {
            dir = idir
            image_index = 0
            state = 9
            pattern += 0.1
        }
        else if (pattern < 21.2)
        {
            dir = idir
            image_index = 0
            state = 3
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 22)
    {
        if (pattern < 22.1)
        {
            dir = idir + 180
            image_index = 0
            state = 6
            pattern += 0.1
        }
        else if (pattern < 22.2)
        {
            dir = idir
            image_index = 0
            state = 2
            pattern += 0.2
            if (random(1) < 0.5)
                cbt = 1
        }
        else
            pattern = -1
    }
    if (fpat == 23)
    {
        if (pattern < 23.1)
        {
            dir = idir
            image_index = 0
            state = 5
            pattern += 0.1
        }
        else if (pattern < 23.2)
        {
            if (scrdist(self, objplayer) < 256 || scrdist(objrm53, self) > 576)
                pattern += 0.1
            else
            {
                dir = idir
                image_index = 0
                state = 5
                pattern += 0.1
            }
        }
        else if (pattern < 23.3)
        {
            dir = idir
            image_index = 0
            if (scrdist(self, objplayer) < 256)
                state = 3
            else
                state = 2
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 24)
    {
        if (pattern < 24.1)
        {
            dir = idir
            image_index = 0
            state = 2
            pattern += 0.1
            if (scrdist(self, player) > 192)
                pattern += 0.1
        }
        else if (pattern < 24.2)
        {
            dir = idir
            image_index = 0
            state = 9
            pattern += 0.2
        }
        else if (pattern < 24.3)
        {
            dir = idir + 180
            image_index = 0
            state = 5
            pattern += 0.1
        }
        else if (pattern < 24.4)
        {
            dir = idir
            image_index = 0
            if (scrdist(self, player) < 256)
                state = 3
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 25)
    {
        if (pattern < 25.1)
        {
            dir = idir
            image_index = 0
            state = 8
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 31)
    {
        if (pattern < 31.1)
        {
            dir = idir
            image_index = 0
            state = 2
            pattern += 0.1
            if (random(1) < 0.5)
                cbt = 1
        }
        else if (pattern < 31.2)
        {
            dir = idir
            image_index = 0
            if (scrdist(self, player) < 256)
                state = 9
            else
                state = 3
            pattern += 0.1
        }
        else if (pattern < 31.3)
        {
            if (scrdist(objrm53, objplayer) > 640)
                pattern += 0.1
            else
            {
                dir = idir
                image_index = 0
                state = 7
                pattern += 0.1
            }
        }
        else
            pattern = -1
    }
    if (fpat == 32)
    {
        if (pattern < 32.1)
        {
            dir = idir
            image_index = 0
            state = 3
            pattern += 0.1
        }
        else if (pattern < 32.2)
        {
            dir = idir + 180
            image_index = 0
            state = 6
            pattern += 0.1
        }
        else if (pattern < 32.3)
        {
            dir = idir
            image_index = 0
            state = 8
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 33)
    {
        if (pattern < 33.1)
        {
            dir = idir
            image_index = 0
            state = 5
            pattern += 0.1
        }
        else if (pattern < 33.2)
        {
            if (scrdist(self, objplayer) < 256 || scrdist(objrm53, self) > 576)
                pattern += 0.1
            else
            {
                dir = idir
                image_index = 0
                state = 5
                pattern += 0.1
            }
        }
        else if (pattern < 33.3)
        {
            dir = idir
            image_index = 0
            if (scrdist(self, objplayer) < 256)
                state = 3
            else
                state = 2
            pattern += 0.1
        }
        else if (pattern < 33.4)
        {
            if (scrdist(self, objplayer) < 256)
                pattern += 0.1
            else
            {
                dir = idir + 180
                image_index = 0
                state = 6
                pattern += 0.1
            }
        }
        else
            pattern = -1
    }
    if (fpat == 34)
    {
        if (pattern < 34.1)
        {
            dir = idir + 180
            image_index = 0
            state = 6
            pattern += 0.1
        }
        else if (pattern < 34.2)
        {
            if (scrdist(objrm53, objplayer) > 640)
                pattern += 0.1
            else
            {
                dir = idir
                image_index = 0
                state = 7
                pattern += 0.1
            }
        }
        else if (pattern < 34.3)
        {
            dir = idir
            image_index = 0
            state = 2
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 35)
    {
        if (pattern < 35.1)
        {
            dir = idir
            image_index = 0
            state = 8
            pattern += 0.1
        }
        else if (pattern < 35.2)
        {
            dir = idir
            image_index = 0
            if (scrdist(objrm53, objplayer) > 640)
                state = 7
            else
                state = 2
            pattern += 0.1
        }
        else if (pattern < 35.3)
        {
            dir = idir
            image_index = 0
            if (scrdist(self, player) < 256)
                state = 3
            pattern += 0.1
        }
        else
            pattern = -1
    }
    if (fpat == 36)
    {
        if (pattern < 36.1)
        {
            dir = idir
            image_index = 0
            state = 9
            pattern += 0.1
        }
        else if (pattern < 36.2)
        {
            dir = idir
            image_index = 0
            state = 5
            pattern += 0.1
        }
        else if (pattern < 36.3)
        {
            dir = idir
            image_index = 0
            state = 3
            pattern += 0.1
        }
        else
            pattern = -1
    }
}
else
    prevpat = floor(pattern)
if (state == 1)
{
}
if (state == 2)
{
    scrspr8dir(dir, sbmobenc0, sbmobenc1, sbmobenc2, sbmobenc3, sbmobenc4)
    if (image_index < 2)
    {
        image_speed = 0.2
        if (prevpat != 0)
            image_speed = 0.4
        spd += ((-spd) / 4)
    }
    else if (image_index < 3)
    {
        image_speed = 0.4
        with (objbmobencb1)
            instance_destroy()
        spd = 0
        if (sound == 0)
        {
            sound = 1
            scrsound(snbmobenclap0, 50, 1, 1)
            scrsound(snbmobencharge0, 50, 1, 1)
        }
    }
    else if (image_index < 4)
    {
        image_speed = 0
        dir = idir
        if (!instance_exists(objbmobencb1))
        {
            p = instance_create_layer(x, y, "instances", objbmobencb1)
            var vpp = 1
            if (prevpat != 0)
                vpp = 2
            p.ct = 40 / vpp
        }
        else
        {
            with (objbmobencb1)
            {
                x = (x + other.x + (lengthdir_x(12, other.dir))) / 2
                y = (y + other.y + (lengthdir_y(12, other.dir))) / 2
                if (state == 2)
                {
                    other.image_index = 4
                    other.spd = -6
                }
            }
        }
    }
    else if (image_index < 6)
    {
        image_speed = 0.2
        spd += ((-spd) / 4)
        if (cbt > 0)
        {
            dir = idir
            state = 4
            image_index = 0
            image_speed = 0
            objplayerview.shaket = 0
            with (objbmobencb1)
            {
                instance_destroy()
                part_system_destroy(ps)
            }
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.1
        spd = 0
    }
    else
        state = 0
    scrmovcol(spd, dir)
}
else
    cbt = 0
if (state == 3)
{
    scrspr8dir(dir, sbmobenp0, sbmobenp1, sbmobenp2, sbmobenp3, sbmobenp4)
    if (image_index < 1)
    {
        image_speed = 0.1
        if (prevpat != 0)
            image_speed = 0.4
        spd = 0
        dir = idir
        ct = 0
        prevx = 0
        prevy = 0
    }
    else if (image_index < 2)
    {
        image_speed = (1/30)
        if (prevpat != 0)
            image_speed = (1/30)
        if (sound == 0)
        {
            sound = 1
            scrsound(snbmobencharge1, 50, 1, 1)
        }
        if ((image_index - 1) > ct)
        {
            var t = image_index - 1
            ct += 0.14285714285714285
            if (t > 0.3)
            {
                part_system_depth(ps, (-y))
                part_type_scale(ptsp, 4, (4 + t * 4))
                if (random(1) < 0.1)
                    part_type_scale(ptsp, 4, (4 + t * 18))
                part_type_orientation(ptsp, 0, 360, 0, 0, 0)
                part_particles_create(ps, (x + facing * ptx * 4), (y - pty * 4), ptsp, 1)
                scrsound(snbmobenmetal0, 50, 1, (0.9 + ct * 0.1))
            }
        }
        var ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 5)) * sign(ad) / 3)
        if (sound == 1 && image_index > 1.9)
        {
            sound = 2
            scrsound(snbmobenpunch0, 50, 1, 1)
        }
    }
    else if (image_index < 3)
    {
        if (image_speed != 0.2)
        {
            image_speed = 0.2
            scrsplash(x, y, sbmobenjsplash2, 0)
            scrsplash(x, y, sbmobendsplash2, 0)
            prevx = x
            prevy = y
            targetx = x
            targety = y
            dist3 = 320
            var c = ds_list_create()
            ds_list_add(c, 394)
            ds_list_add(c, 114)
            wcol = 0
            if collision_line(x, y, (x + (lengthdir_x(dist3, dir))), (y + (lengthdir_y(dist3, dir))), objallcol, 1, 0)
                wcol = 1
            ds_list_destroy(c)
        }
        var ii = clamp((image_index - 2 + image_speed), 0, 1)
        var d = clamp((1 - (power((1 - (power((ii + 0), 5))), 0.05)) + 0.01), 0, 1)
        x = prevx + (lengthdir_x((d * dist3), dir))
        y = prevy + (lengthdir_y((d * dist3), dir))
        spd = point_distance(targetx, targety, x, y)
        if (wcol > 0)
        {
            c = ds_list_create()
            ds_list_add(c, 394)
            ds_list_add(c, 114)
            if collision_line(targetx, targety, x, y, objallcol, 0, 0)
            {
                x = targetx
                y = targety
                prevx = x
                prevy = y
                targetx = x
                targety = y
                image_index = 3
            }
            ds_list_destroy(c)
        }
        ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 1)) * sign(ad))
        if (ct > 0)
        {
            ct = 0
            part_system_clear(ps)
            var rdir = irandom(360)
            repeat (3)
            {
                part_type_scale(ptsp, 8, 25)
                part_type_size(ptsp, 1, 1, -0.3, 0)
                part_type_orientation(ptsp, rdir, rdir, 0, 0, 0)
                part_particles_create(ps, (x + facing * ptx * 4), (y - pty * 4), ptsp, 1)
                rdir += (180 + irandom(60))
            }
        }
    }
    else if (image_index < 5)
    {
        if (image_index < 4)
            image_speed = 0.4
        else
            image_speed = 0.1
        if (spd == 0)
            spd = point_distance(targetx, targety, x, y)
        else if (spd > 32)
            spd /= 2
        else if (image_index < 4)
            spd *= 0.9
        else
            spd *= 0.6
        ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 5)) * sign(ad) / 2)
        var dsp0 = (clamp((spd - 64), 0, 64)) / 64
        var dsp1 = dsp0 * 0.8 + 0.2
        if (spd > 16)
        {
            scrsplash1(dx, dy, sbmobendsplash2, 0, (1 - (clamp((dsp1 / 4), 0, 0.25))), 1)
            dx += lengthdir_x(16, point_direction(dx, dy, x, y))
            dy += lengthdir_y(16, point_direction(dx, dy, x, y))
        }
    }
    else if (image_index < (image_number - image_speed))
        image_speed = 0.1
    else
        state = 0
    scrmovcol(spd, dir)
    if (spd > 10 || image_index < 3)
    {
        var vcol = false
        if (image_index >= 2 && image_index < 3)
        {
            var wd = point_direction(x, y, targetx, targety)
            v = 18
            for (var w = 0; w < (spd + v * 2); w += v)
            {
                var wx = x + (lengthdir_x(w, wd))
                var wy = y + (lengthdir_y(w, wd))
                d = (point_distance(prevx, prevy, wx, wy)) / dist3
                var vlife = (1 - d) * 0.5 + 0.75 + (random_range(-0.1, 0.1))
                var vscale = (1 - d) * 0.5 + 0.5
                part_type_size(ptdsp, (vscale + (random_range(-0.1, 0.3))), (vscale + (random_range(-0.1, 0.3))), 0.01, 0)
                part_type_life(ptdsp, (20 * vlife), (20 * vlife))
                part_particles_create(ps, wx, wy, ptdsp, 1)
                if (place_meeting(wx, wy, objplayer) && objplayer.iframe <= 0)
                    vcol = true
            }
        }
        targetx = x
        targety = y
        if (image_index > 2)
        {
            if (!instance_exists(self))
                return;
            var vptdir = (round(dir / 45)) * 45
            if (vptdir == 360)
                vptdir = 0
            var vptface = -1
            if (vptdir > 90 && vptdir <= 270)
                vptface = 1
            var vptspr = 326
            var vptxscl = 3
            if (vptdir == 90 || vptdir == 270)
            {
                vptspr = 2637
                vptxscl = 4
            }
            else if (vptdir == 0 || vptdir == 180)
            {
                vptspr = 2328
                vptxscl = 2
            }
            else if (vptdir == 45 || vptdir == 135)
                vptface *= -1
            part_type_sprite(ptsh, vptspr, 1, 1, 0)
            part_type_scale(ptsh, (vptxscl * vptface), 4)
            part_type_speed(ptsh, 0, 0, 1, 0)
            part_type_direction(ptsh, (dir - 180), (dir - 180), 0, 0)
            part_particles_create(ps, x, (y - z), ptsh, 1)
        }
        if (vcol == true && image_index > 2)
        {
            with (objplayer)
            {
                objplayerview.shaket = 12
                dir = other.dir + 180
                caninput = false
                state = 6
                image_index = 0
                if scrmovcol(other.spd, other.dir)
                    scrmovcol((-other.spd), other.dir)
            }
            if (timer3 == 0)
            {
                timer3 = 1
                p = instance_create_layer(x, y, "instances", objbmobencb1)
                p.type = "attach"
                p.z = 40
                p.dir = dir
                p.zvel = 2
                objplayer.hp -= 0.5
                p.bstate = state
                scrsound(snpattack1s, 50, 1, 0.8)
                scrsound(snbmobenpunch0, 50, 1, 0.8)
            }
        }
        if (timer3 > 0)
        {
            with (objplayer)
            {
                dir = other.dir + 180
                caninput = false
                state = 6
                image_index = 0
                x = other.x
                y = other.y
            }
        }
    }
    else
        timer3 = 0
}
else
    timer3 = 0
if (state == 4)
{
    scrspr8dir(dir, sbmobent0, sbmobent1, sbmobent2, sbmobent3, sbmobent4)
    if (image_index < 1)
    {
        image_speed = 0.2
        spd += ((-spd) / 2)
        ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 5)) * sign(ad))
    }
    else if (image_index < 3)
    {
        if (image_speed != 0.25)
        {
            image_speed = 0.25
            spd = 6
            scrsound(snbmobenthrow0, 50, 1, 1)
            scrsoundgain(snbmobenthrow2, 50, 0.1, 200)
        }
        ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 5)) * sign(ad))
    }
    else if (image_index < 5)
    {
        if (image_speed != 0.2)
        {
            image_speed = 0.2
            var b = instance_create_layer(x, y, "instances", objbmobencb1)
            b.type = "throw"
            scrsound(snbmobenthrow1, 50, 1, 1)
            scrsoundgain(snbmobenthrow2, 50, 1, 1000)
        }
    }
    else if (image_index < (image_number - image_speed))
        image_speed = 0.1
    else
        state = 0
    scrmovcol(spd, dir)
    spd += ((-spd) / 12)
}
if (state == 5)
{
    scrspr8dir(dir, sbmobend0, sbmobend1, sbmobend2, sbmobend3, sbmobend4)
    if (image_index < 1)
    {
        image_speed = 0.2
        if (prevpat == 0)
            image_speed = 0.4
        prevx = 0
        prevy = 0
    }
    else if (image_index < 2)
    {
        if ((prevx + prevy) == 0)
        {
            image_speed = 0.1
            if (prevpat == 0)
                image_speed = 0.25
            prevx = x
            prevy = y
            var vdist = 256
            targetx = x + (lengthdir_x(vdist, dir))
            targety = y + (lengthdir_y(vdist, dir))
            var dist = (point_distance(objrm53.x, objrm53.y, targetx, targety)) / 64
            var distadj = clamp(((dist - 5) / 5), 0, 1)
            var diradj = (angle_difference(dir, scrdir(self, objrm53))) * distadj
            dir -= diradj
            var s = 0
            var n = angle_difference(dir, scrdir(self, objrm53))
            if (n <= 0)
                n = -1
            else
                n = 1
            while scrcolline(x, y, targetx, targety)
            {
                s = n * (abs(s) + 5)
                targetx = x + (lengthdir_x(vdist, (dir + s)))
                targety = y + (lengthdir_y(vdist, (dir + s)))
                if (abs(s) > 180)
                {
                    targetx = objplayer.x
                    targety = objplayer.y
                    break
                }
                else
                    continue
            }
            dir += s
            if (angle_difference(dir, scrdir(self, objrm53)) < 0)
                dir = (floor(dir / 45)) * 45
            else
                dir = (ceil(dir / 45)) * 45
        }
    }
    else if (image_index < 3)
    {
        image_speed = 0.4
        ashad = 0
        if (sound == 0)
        {
            sound = 1
            scrsound(snbmobendash0, 50, 1, 1)
        }
    }
    else if (image_index < 5)
    {
        if (image_speed > 0)
        {
            image_speed = 0
            objplayerview.shaket = 4
            c = ((scrdist(self, player)) / 64 - 4) / 3 * 1.5 + 1.5
            spd = 64 * c
            if (abs(dir - idir) < 90)
                spd = 192
            scrsplash(x, y, sbmobenjsplash2, 0)
            scrsplash(x, y, sbmobendsplash2, 0)
            dx = x
            dy = y
        }
        ashad = 1
        var const = 0.9
        ad = angle_difference(dir, point_direction(x, y, targetx, targety))
        var curve = clamp(((image_index - 3) / 2), 0, 1)
        if (spd < 30)
            scrsplash(x, y, ssplash0, 4)
        if (spd > 10)
            image_index = 3.5
        else if (spd > 0)
        {
            const = 0.7
            if (ad > 0)
                scrspr8dir((dir + 45), sbmobend0, sbmobend1, sbmobend2, sbmobend3, sbmobend4)
            else
                scrspr8dir((dir - 45), sbmobend0, sbmobend1, sbmobend2, sbmobend3, sbmobend4)
            image_index = 4.5
        }
        else
            image_index = 5
        scrmovcol1(spd, dir)
        dsp0 = (clamp((spd - 64), 0, 64)) / 64
        dsp1 = dsp0 * 0.8 + 0.2
        if (spd > 32)
        {
            repeat (2)
            {
                part_type_size(ptdsp, (1 - (clamp((dsp0 / 4), 0, 0.25))), (1 - (clamp((dsp0 / 4), 0, 0.25))), 0.01, 0)
                part_type_life(ptdsp, 20, 20)
                part_particles_create(ps, x, y, ptdsp, 1)
                dx += lengthdir_x(16, point_direction(dx, dy, x, y))
                dy += lengthdir_y(16, point_direction(dx, dy, x, y))
            }
            if ((sound % 5) == 0)
                scrsound(snbmobenssplash0, 20, clamp(((spd - 16) / 48), 0, 1), random_range(0.8, 1))
            sound += 1
        }
        if (spd > 64)
            spd = 64
        else if (spd > 0.1)
            spd *= const
        else
            spd = 0
        dir -= ((min(abs(ad), (10 + curve * 1))) * sign(ad) / (2 - curve))
    }
    else if (image_index < (image_number - image_speed))
        image_speed = 0.2
    else if (place_meeting(x, y, objrm53) || place_meeting(x, y, objtreecol))
        image_index = 0
    else
        state = 0
}
if (state == 6)
{
    scrspr8dir(dir, sbmobenj0, sbmobenj1, sbmobenj2, sbmobenj3, sbmobenj4)
    if (image_index < 2)
    {
        if (image_index < image_speed)
        {
            dist = (point_distance(objrm53.x, objrm53.y, targetx, targety)) / 64
            distadj = clamp(((dist - 5) / 5), 0, 1)
            diradj = (angle_difference(dir, scrdir(self, objrm53))) * (distadj / 2)
            dir -= diradj
            prevx = x
            prevy = y
            vdist = 64 * (random_range(8, 12))
            targetx = x + (lengthdir_x(vdist, dir))
            targety = y + (lengthdir_y(vdist, dir))
            s = 0
            n = sign(angle_difference(dir, scrdir(self, objrm53)))
            if (n <= 0)
                n = -1
            else
                n = 1
            while scrcolline(x, y, targetx, targety)
            {
                s = n * (abs(s) + 5)
                targetx = x + (lengthdir_x(vdist, (dir + s)))
                targety = y + (lengthdir_y(vdist, (dir + s)))
                if (abs(s) > 180)
                {
                    targetx = objplayer.x
                    targety = objplayer.y
                    break
                }
                else
                    continue
            }
            dir = point_direction(x, y, targetx, targety)
        }
        image_speed = 0.1
        if (prevpat == 0)
            image_speed = 0.2
        if (spd > 0)
            scrmovcol(spd, dir)
        spd += ((0 - spd) / 8)
    }
    else if (image_index < 3)
    {
        image_speed = 0.4
        if (sound == 0)
        {
            sound = 1
            scrsound(sncutblanket23, 50, 1, 1)
        }
    }
    else if (image_index < 7)
    {
        if (image_speed != 0)
        {
            image_speed = 0
            objplayerview.shaket = 4
            part_system_depth(ps, (-y))
            part_particles_create(ps, x, y, ptj, 1)
            scrsplash(x, y, sbmobenjsplash2, 0)
            timer = 0
            zt = 0.1
        }
        if (zt < 0.25)
            image_index = 3.5
        else if (zt < 0.47)
            image_index = 4.5
        else if (zt < 0.85)
            image_index = 5.5
        else
            image_index = 6.5
        if (zt < 1)
            zt += 0.02
        else
            image_index = 7
        var zheight = 256
        if (zt < 0.466)
            z = (clamp((1.3 * (power((1 - (power((-1.8 * zt + 1), 3.5))), 0.25)) - 0.3), 0, 1)) * zheight
        else
            z = (clamp((1.5 * (power((1 - (power((1.7 * zt - 0.7), 2.7))), 0.25)) - 0.5), 0, 1)) * zheight
        var zdist = point_distance(prevx, prevy, targetx, targety)
        x = prevx + (lengthdir_x((zt * zdist), dir))
        y = prevy + (lengthdir_y((zt * zdist), dir))
        if (((zt - 0.35) * 6) > timer && timer < 6)
        {
            timer += 1
            var pdir = dir
            var pdist = (sin(pi * (zt - 0.4) * 2.5)) * 64 * 1.5
            d = (timer % 2) * 2 - 1
            p = instance_create_layer((x + (lengthdir_x(pdist, (pdir + d * 90)))), (y + (lengthdir_y(pdist, (pdir + d * 90)))), "instances", objbmobencb1)
            p.type = "delay"
            p.z = z + 64
            p.target = -4
            p.targx = x + (lengthdir_x(clamp(((scrdist(p, objplayer)) / 2), 0, 192), scrdir(p, objplayer)))
            p.targy = y + (lengthdir_y(clamp(((scrdist(p, objplayer)) / 2), 0, 192), scrdir(p, objplayer)))
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        if (image_speed != 0.1)
        {
            image_speed = 0.1
            scrsplash(x, y, sbmobenjsplash2, 0)
        }
        z = 0
    }
    else
    {
        state = 0
        dir += 180
    }
}
if (state == 7)
{
    scrspr8dir(dir, sbmobenj0, sbmobenj1, sbmobenj2, sbmobenj3, sbmobenj4)
    var aimdist = 1.7
    if (jb == 0)
    {
        if (image_index < 2)
        {
            if (image_index < image_speed)
            {
                prevx = x
                prevy = y
                var mpdist = (scrdist(self, objplayer)) * aimdist
                var mpdir = scrdir(self, objplayer)
                dir = scrdir(self, objplayer)
                targetx = x + (lengthdir_x(mpdist, mpdir))
                targety = y + (lengthdir_y(mpdist, mpdir))
            }
            image_speed = 0.1
            if (prevpat == 0)
                image_speed = 0.2
            if (spd > 0)
                scrmovcol(spd, dir)
            spd += ((0 - spd) / 8)
        }
        else if (image_index < 3)
        {
            image_speed = 0.4
            if (sound == 0)
            {
                sound = 1
                scrsound(sncutblanket23, 50, 1, 1)
                scrsound(snbmobenjcharge0, 50, 1, 1)
            }
        }
        else if (image_index < 7)
        {
            if (image_speed != 0)
            {
                image_speed = 0
                objplayerview.shaket = 4
                part_system_depth(ps, (-y))
                part_particles_create(ps, x, y, ptj, 1)
                scrsplash(x, y, sbmobenjsplash2, 0)
                timer = 0
                zt = 0.1
                with (objbmobencb1)
                    instance_destroy()
            }
            if (zt < 0.25)
                image_index = 3.5
            else if (zt < 0.47)
                image_index = 4.5
            else if (zt < 0.85)
                image_index = 5.5
            else
                image_index = 6.5
            zheight = 256
            if (zt < 0.466)
                z = (clamp((1.3 * (power((1 - (power((-1.8 * zt + 1), 3.5))), 0.25)) - 0.3), 0, 1)) * zheight
            else
                z = (clamp((1.5 * (power((1 - (power((1.7 * zt - 0.7), 2.7))), 0.25)) - 0.5), 0, 1)) * zheight
            zdist = point_distance(prevx, prevy, targetx, targety)
            ad = angle_difference(dir, idir)
            dir -= ((min(abs(ad), (5 / (zt * 5)))) * sign(ad) / (zdist / 64))
            x = prevx + (lengthdir_x((zt * zdist), dir))
            y = prevy + (lengthdir_y((zt * zdist), dir))
            zt += ((0.7 - zt) / 40)
            if (!instance_exists(objbmobencb1))
            {
                p = instance_create_layer(x, (y - z), "instances", objbmobencb1)
                p.type = "jump"
                p.x = x
                p.y = y
                p.z = z + 20
            }
            else
            {
                with (objbmobencb1)
                {
                    x = other.x
                    y = other.y
                    z = other.z
                    if (state >= 1)
                    {
                        other.jb = 1
                        other.image_index = 3
                    }
                }
            }
        }
    }
    else if (image_index < 7)
    {
        var sratio = 0.1
        if (image_index == 3)
        {
            scrsound(snbmobenjshoot0, 50, 1, 1)
            vdist = 384
            targetx = x + (lengthdir_x(vdist, dir))
            targety = y + (lengthdir_y(vdist, dir))
            s = 0
            n = 1
            while scrcolline(x, y, targetx, targety)
            {
                n = (-n)
                s = n * (abs(s) + 5)
                targetx = x + (lengthdir_x(vdist, (dir + s)))
                targety = y + (lengthdir_y(vdist, (dir + s)))
                if (abs(s) > 180)
                {
                    targetx = objplayer.x
                    targety = objplayer.y
                    break
                }
                else
                    continue
            }
            d = point_direction(x, y, targetx, targety)
            pdist = vdist / 9
            dir = d
            prevx = x + (lengthdir_x(pdist, d))
            prevy = y + (lengthdir_y(pdist, d))
            zt = sratio
        }
        if (zt < 0.25)
            image_index = 3.5
        else if (zt < 0.47)
            image_index = 4.5
        else if (zt < 0.85)
            image_index = 5.5
        else
            image_index = 6.5
        if (zt < 1)
            zt += 0.02
        else
            image_index = 7
        zheight = 256
        if (zt < 0.466)
            z = (clamp((1.3 * (power((1 - (power((-1.8 * zt + 1), 3.5))), 0.25)) - 0.3), 0, 1)) * zheight
        else
            z = (clamp((1.5 * (power((1 - (power((1.7 * zt - 0.7), 2.7))), 0.25)) - 0.5), 0, 1)) * zheight
        zdist = point_distance(prevx, prevy, targetx, targety)
        x = prevx + (lengthdir_x((zt * zdist), dir))
        y = prevy + (lengthdir_y((zt * zdist), dir))
    }
    else if (image_index < (image_number - image_speed))
    {
        if (image_speed != 0.1)
        {
            image_speed = 0.1
            scrsplash(x, y, sbmobenjsplash2, 0)
        }
        z = 0
    }
    else
    {
        state = 0
        dir += 180
    }
}
else
    jb = 0
if (state == 8)
{
    scrspr8dir(dir, sbmobenr0, sbmobenr1, sbmobenr2, sbmobenr3, sbmobenr4)
    var roar = 0
    if (image_index < 1)
    {
        image_speed = 0.1
        if (prevpat == 0)
            image_speed = 0.2
        dir = (round(dir / 45)) * 45
    }
    else if (image_index < 2)
    {
        image_speed = 0.05
        if (prevpat == 0)
            image_speed = 0.1
    }
    else if (image_index < 3)
        image_speed = 0.4
    else if (image_index < 4)
    {
        image_speed = 0.025
        objplayerview.shaket = 10
        roar = 1
        var i = image_index - 3
        var lay = i * 4
        pdist = (floor(lay + 1)) * 128
        rdir = dir * (floor(lay) * 700)
        s = 1
        if ((global.time % 8) == 0)
        {
            repeat (2)
            {
                pdir = (lay % 1) * 180
                pdir = rdir + s * pdir
                pdist += irandom_range(-96, 0)
                s = (-s)
                var vcancel = 0
                var px = x + (lengthdir_x(pdist, pdir))
                var py = y + (lengthdir_y((pdist * 0.6), pdir))
                var a = 0
                if (a < ds_list_size(pcol))
                {
                    var cl = collision_line(x, y, px, py, ds_list_find_value(pcol, a), true, false)
                    if instance_exists(cl)
                    {
                    }
                    else
                    {
                        a += 1
                        while (a < ds_list_size(pcol))
                        {
                            var cl = collision_line(x, y, px, py, ds_list_find_value(pcol, a), true, false)
                            if instance_exists(cl)
                                break
                            else
                            {
                                a += 1
                                continue
                            }
                        }
                    }
                }
                if instance_exists(cl)
                {
                    vcancel = 1
                    vpx = x
                    vpy = y
                    vdist = point_distance(x, y, px, py)
                    var vdir = point_direction(x, y, px, py)
                    w = 0.1
                    while (!(position_meeting(vpx, vpy, cl)))
                    {
                        vpx = x + (lengthdir_x((vdist * w), vdir))
                        vpy = y + (lengthdir_y((vdist * w), vdir))
                        w += 0.1
                        if (w > 1)
                            break
                        else
                            continue
                    }
                    if variable_struct_exists(cl, "hit")
                        cl.hit += 0.5
                    px = vpx
                    py = vpy
                }
                p = instance_create_layer(px, py, "instances", objbmobencb1)
                p.type = "delay"
                p.state = 2
                p.timer = 0
                p.ct = 0
                p.cancel = vcancel
                scrsplash(px, py, smobsm2splash, 0)
            }
        }
        if (sound == 0)
        {
            sound = 1
            audio_stop_sound(snbmobenroar0)
            scrsoundgain(snbmobenroar0, 50, 1, 0)
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.1
        if (sound == 1)
        {
            sound = 2
            scrsoundgain(snbmobenroar0, 50, 0, 1000)
        }
    }
    else
    {
        audio_stop_sound(snbmobenroar0)
        state = 0
    }
    if (roar > 0)
    {
        if (((global.time % 5) / roar) == 0)
        {
            part_particles_create(psr0, x, (y - 80), ptr0, 1)
            if (random(1) < 0.4)
                scrsplash(x, y, sbmobsmsplash0, 4)
            if (random(1) < 0.1)
                scrsplash(x, y, sbmobsmsplash0, 2)
        }
    }
}
if (state == 9)
{
    scrspr8dir(dir, sbmobens0, sbmobens1, sbmobens2, sbmobens3, sbmobens4)
    if (image_index < 1)
    {
        image_speed = 0.2
        if (prevpat == 0)
            image_speed = 0.4
        dir = (round(dir / 45)) * 45
    }
    else if (image_index < 2)
    {
        image_speed = 0.1
        if (prevpat == 0)
            image_speed = 0.2
    }
    else if (image_index < 3)
        image_speed = 0.4
    else if (image_index < 4)
    {
        if (image_speed != 0.05)
        {
            image_speed = 0.05
            objplayerview.shaket = 10
            scrsplash(x, y, smobsm2splash, 0)
        }
        if ((global.time % 10) == 0)
        {
            pdist = irandom_range(96, 192)
            s = 1
            repeat (2)
            {
                scrsound(snbmobenmetal0, 50, 1, random_range(0.9, 1.1))
                pdir = (image_index - 3) * 180
                pdir = dir + s * pdir
                p = instance_create_layer((x + (lengthdir_x(pdist, pdir))), (y + (lengthdir_y(pdist, pdir))), "instances", objbmobencb1)
                p.type = "delay"
                p.z = irandom_range(32, 64)
                p.target = -4
                p.targx = p.x + (irandom_range(-96, 96))
                p.targy = p.y + (irandom_range(-64, 64))
                s = (-s)
            }
        }
    }
    else if (image_index < (image_number - image_speed))
        image_speed = 0.1
    else
        state = 0
}
if (state == 0)
{
    staterev = -1
    revrange = random_range(-1, 1)
}
else if (rev < maxsrev && state != 10 && hp > 0)
{
    if (staterev < floor(image_index) && random(1) < (1/30))
    {
        staterev += 1
        rev += 1
    }
}
maxsrev = (1 - hp / hpmax[phase]) * hpmax[phase]
if (rev > prev)
{
    if (prev == 0)
    {
        ppx = 3592
        ppy = 1800
        pbx = 3604
        pby = 1352
    }
    prev = rev
    with (objrmbloom)
        picture += 1
}
if (state == 10)
{
    with (objplayer)
    {
        caninput = false
        inv = 1
    }
    scrspr8dir(dir, sbmobenkd0, sbmobenkd1, sbmobenkd2, sbmobenkd3, sbmobenkd4)
    image_index = 4
    image_speed = 0
    if (timer < 1)
        timer += 0.016666666666666666
    else if (timer < 2)
    {
        if (!instance_exists(objbmobeneye))
            instance_create_layer(x, y, "instances", objbmobeneye)
        else if (objbmobeneye.ended >= 1)
        {
            timer = 2
            revframe = rev
            phase = clamp((phase + 1), 1, 5)
            with (objbmobeneye)
                instance_destroy()
            with (objbmobenshatter0)
                instance_destroy()
            with (objbmobenshatter1)
                instance_destroy()
            with (objplant00)
                sprite_index = swnplant0
            with (objplant03)
                sprite_index = swnplant3
            with (objplant04)
                sprite_index = swnplant4
            with (objplant05)
                sprite_index = swnplant5
            with (objplant06)
                sprite_index = swnplant6
            with (objplant07)
                sprite_index = swnplant7
            with (objplant08)
                sprite_index = swnplant8
            with (objplant09)
                sprite_index = swnplant9
            with (objplant10)
                sprite_index = swnplant90
            with (objplant12)
                sprite_index = swnplant92
            with (objplant13)
                sprite_index = swnplant93
            with (objplant14)
                sprite_index = swnplant94
            scrsoundgain(snbmobenrewind0, 50, 0.5, 500)
            scrsoundgain(snbmobenrewind1, 50, 1, 200)
        }
    }
    else if (timer < 3)
    {
        if (timer < 2.1)
        {
            var rr = 1 - revframe / rev
            t = clamp(rr, 0.1, 0.8)
            timer += (0.05 * t)
            maxhp = hpmax[phase]
        }
        else if (revframe > 0)
        {
            timer = 2
            revframe -= 1
            hp = maxhp * (1 - revframe / rev)
            objplayer.x = ppx
            objplayer.y = ppy
            objplayer.dir = 90
            x = pbx
            y = pby
            dir = 270
            with (objbmobeneye)
            {
                x = other.x
                y = other.y
            }
            with (objbmobeneye)
                instance_destroy()
            if (revframe == 5)
                scrsound(snbmobenrewind2, 50, 1, 200)
        }
        else
        {
            timer = 3
            revframe = -1
            rev = 0
            prev = 0
            sprite_delete(global.srev)
            global.srev = -1
            with (objbmobeneye)
                open = 0
            shatter = 0
            audio_stop_sound(snbmobenrewind0)
            audio_stop_sound(snbmobenrewind1)
            audio_stop_sound(snbmobenrewind2)
        }
    }
    else
    {
        if (phase < 4)
            state = 8
        else
            state = 0
        pattern = -1
        objplayer.caninput = true
    }
}
if (phase == 4)
    hvyamr = 1
if (hvyamr == 1)
{
    if (state >= 1 && state <= 9)
        hvyamr = 2
}
else if (hvyamr == 2)
{
    if (state == 0)
        hvyamr = 0
}
if (hit > 0 && z < 16)
{
    audio_stop_sound(snbmobenroar0)
    objplayerview.shaket = 8
    hp = clamp((hp - hit), 0.1, 9999)
    hit = 0
    if (hvyamr == 0 || hp < 1)
    {
        with (objbmobencb1)
        {
            if (state == 0)
                cancel = 1
        }
        objplayerview.shaket = 12
        state = 12
        scrsound(snpattack1s, 50, 1, 1)
        image_index = 0
        z = 0
        dir = objplayer.dir - 180
        if (dir < 0)
            dir += 360
        spd = 32
        hvyamr = 1
    }
}
if (state == 12)
{
    scrspr8dir(dir, sbmobenkd0, sbmobenkd1, sbmobenkd2, sbmobenkd3, sbmobenkd4)
    var pause = 0
    if (image_index < 1)
    {
        if (image_speed != 0.5)
        {
            image_speed = 0.5
            scrsplash(x, y, sbmobenjsplash2, 3)
            scrsplash(x, y, sbmobendsplash2, 0)
        }
        spd = 32
    }
    else if (image_index < 2)
    {
        if (image_speed != 0.45)
        {
            image_speed = 0.45
            scrsplash(x, y, sbmobendsplash2, 0)
        }
        spd = 8
    }
    else if (image_index < 3)
    {
        if (image_speed != 0.25)
        {
            image_speed = 0.25
            scrsplash(x, y, sbmobendsplash2, 0)
        }
        spd = 6
    }
    else if (image_index < 4)
    {
        if (image_speed != 0.5)
        {
            image_speed = 0.5
            scrsplash(x, y, sbmobendsplash2, 0)
        }
        spd = 4
    }
    else if (hp < 1)
    {
        image_speed = 0
        state = 10
        timer = 0
    }
    else if (image_index < 5)
    {
        if (image_speed != 0.25)
            image_speed = 0.25
        spd = 0
    }
    else if (image_index < (6 - image_speed))
    {
        image_speed = 0.2
        spd = 0
    }
    else
    {
        state = 0
        pattern = 0
        prevpat = -1
    }
    if (pause == 0)
        scrmovcol1((-spd), dir)
}
if (state == 13)
{
    dir = 270
    scrspr8dir(dir, sbmobenr0, sbmobenr1, sbmobenr2, sbmobenr3, sbmobenr4)
    roar = 0
    if (image_index < 1)
    {
        image_speed = 0.1
        if (prevpat == 0)
            image_speed = 0.2
        dir = (round(dir / 45)) * 45
        if (sound == 0)
        {
            sound = 1
            scrsound(snbmobenbreathein0, 50, 1, 1)
        }
    }
    else if (image_index < 2)
    {
        image_speed = 0.025
        if (prevpat == 0)
            image_speed = 0.1
    }
    else if (image_index < 3)
        image_speed = 0.4
    else if (image_index < 3.5)
    {
        image_speed = (1/120)
        objplayerview.shaket = 10
        roar = 1
        i = (image_index - 3) * 2
        pdist = i * 64 * 18
        var vpi = floor((pi * (power(100, floor(i * 120)))) % 100)
        pdir = 360 * (vpi / 100)
        px = x + (lengthdir_x(pdist, pdir))
        py = y + (lengthdir_y((pdist * 0.6), pdir))
        vcancel = 0
        if collision_line(x, y, px, py, objrm53, true, false)
        {
            vcancel = 1
            vpx = x
            vpy = y
            vdist = point_distance(x, y, px, py)
            vdir = point_direction(x, y, px, py)
            w = 0.1
            while (!(position_meeting(vpx, vpy, objrm53)))
            {
                vpx = x + (lengthdir_x((vdist * w), vdir))
                vpy = y + (lengthdir_y((vdist * w), vdir))
                w += 0.1
                if (w > 1)
                    break
                else
                    continue
            }
            objrm53.hit += 0.5
            px = vpx
            py = vpy
        }
        if (sound == 1)
        {
            sound = 2
            scrsound(snbmobenroar1, 50, 1, 1)
            instance_create_layer(3608, 1328, "Below", objbmobencrater)
        }
        with (objbmobencrater)
            image_alpha = other.image_index - 3
        p = instance_create_layer(px, py, "instances", objbmobencb1)
        p.type = "final"
        p.timer = 0
        p.ct = 0
        p.z = 0
        scrsplash(px, py, smobsm2splash, 0)
    }
    else if (image_index < (image_number - image_speed))
    {
        if (image_speed != 0)
        {
            image_speed = 0
            p = instance_create_layer(x, y, "instances", objbmobencb1)
            p.type = "combine"
            p.ct = 0
            p.z = 320
        }
    }
    if (roar > 0)
    {
        if (((global.time % 5) / roar) == 0)
        {
            part_particles_create(psr0, x, (y - 80), ptr0, 1)
            if (random(1) < 0.4)
                scrsplash(x, y, sbmobsmsplash0, 4)
            if (random(1) < 0.1)
                scrsplash(x, y, sbmobsmsplash0, 2)
        }
    }
}
if (state == 13.1)
{
    dir = 270
    scrspr8dir(dir, sbmobens0, sbmobens1, sbmobens2, sbmobens3, sbmobens4)
    if (image_index < 1)
    {
        image_speed = 0.1
        if (prevpat == 0)
            image_speed = 0.4
        dir = (round(dir / 45)) * 45
    }
    else if (image_index < 2)
    {
        image_speed = 0.05
        if (prevpat == 0)
            image_speed = 0.2
    }
    else if (image_index < 3)
        image_speed = 0.4
    else if (image_index < 4)
    {
        if (image_speed != 0.025)
        {
            image_speed = 0.025
            image_index = 3.5
            objplayerview.shaket = 10
            scrsplash(x, y, smobsm2splash, 0)
        }
    }
    else if (image_index < (image_number - 0.5))
        image_speed = 0.1
    else
        image_speed = 0
}
