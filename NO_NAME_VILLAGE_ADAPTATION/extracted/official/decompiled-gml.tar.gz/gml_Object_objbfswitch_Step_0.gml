var malpha = 1 - alpha
if layer_exists("blueforest")
{
    fx_set_parameter(layer_get_fx("blueforest"), "g_AddCol", [0, (0.047 * malpha), (0.098 * malpha), (1 * malpha)])
    fx_set_parameter(layer_get_fx("blueforest"), "g_Distort1Scale2", (117 * malpha))
    fx_set_parameter(layer_get_fx("blueforest"), "g_Distort2Scale2", (10 * malpha))
}
if (start == true)
{
    if (!instance_exists(objbfpart))
        instance_create_layer(0, 0, "invisible", objbfpart)
    if (abs(alpha - alphat) > abs(alphatt))
    {
        with (objrm32ebg)
            alpha = other.alpha
        with (objrm32ebg2)
            alpha = other.alpha
        alpha += alphatt
    }
    else
    {
        with (objrm32ebg)
            alpha = other.alphat
        with (objrm32ebg2)
            alpha = other.alphat
        instance_destroy()
    }
}
