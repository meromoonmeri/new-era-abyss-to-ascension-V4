if (testd == -1)
    depth = layer_get_depth("grass0")
if (testd == 0)
    depth = layer_get_depth("shadows")
if (testd == 1)
    depth = layer_get_depth("Below")
if (testd == 2)
    depth = layer_get_depth("endwater")
if (testd == 3)
    depth = layer_get_depth("cliff")
if (testd == 4)
    depth = layer_get_depth("invisible")
if (testd == 5)
    depth = layer_get_depth("instances")
testx = x
testy = y
testa = image_alpha
if (state == 0)
{
    sprite_index = sbmobenend3
    x = 3608
    y = 1328
}
if (state == 1)
{
    sprite_index = sbmobenend2
    x = 3584
    y = 1344
    image_alpha = 1
}
