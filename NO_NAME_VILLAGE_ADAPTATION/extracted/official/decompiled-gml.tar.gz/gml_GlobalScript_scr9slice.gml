function scr9slice(argument0, argument1, argument2) //gml_Script_scr9slice
{
    if (optbox == 0)
    {
        if (!instance_exists(obj9slice0))
        {
            var box = instance_create_depth(argument0, argument1, -9999999, obj9slice0)
            box.text = argument2
            optbox = 1
            return true;
        }
    }
    else if (optbox == 1)
    {
        if instance_exists(obj9slice0)
        {
            if scrinput("actionp")
                optboxselect = obj9slice0.bar
        }
        else
        {
            optbox = 2
            return -1;
        }
    }
}

