if (image_index < (image_number - image_speed * 2))
{
    scrmovcol(spd, dir)
    image_speed = 0.2
}
else if (image_speed != 0)
{
    objplayerview.shaket = 6
    spd = 0
    image_speed = 0
}
