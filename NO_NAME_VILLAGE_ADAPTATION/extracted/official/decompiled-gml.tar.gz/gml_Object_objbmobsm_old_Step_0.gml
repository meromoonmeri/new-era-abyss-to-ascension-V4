event_inherited()
idir = scrdir(self, objplayerview.player)
var accl = 0.2
if (spd < maxspd)
    spd = clamp((spd + accl), 0, maxspd)
else if (spd > maxspd)
    spd = clamp((spd - accl), maxspd, 999)
if (state == 2 || (state == 4 && image_index < 2) || (state == 5 && image_index < 2))
    depth = 300
else
    depth = (-y) - 150
if (hp > 0)
{
    if (state != 2 || state != 3 || (state != 5 && image_index > 2))
    {
        if (hit != -1)
        {
            if (hit == 1)
            {
                flash = 0.5
                objplayer.shaket = 6
            }
            else if (hit == 2)
            {
                flash = 0.5
                objplayer.shaket = 8
            }
            hp -= (hit + hit * (max(0, (objplayer.weaponlvl - 1))) * 0.5)
            hit = -1
        }
        else if (flash == 0)
            hit = 0
    }
    else if (hit != -1)
    {
        if (hit == 2)
        {
            flash = 0.5
            objplayer.shaket = 8
            hp -= (hit + hit * (max(0, (objplayer.weaponlvl - 1))) * 0.5)
            hit = -1
        }
    }
    else if (flash == 0)
        hit = 0
}
else if (state != 9)
{
    if (flash == 0)
    {
        hit = 0
        state = 7
        image_index = 0
    }
}
if (state == -1)
{
    sprite_index = sbmobsmi0
    image_speed = 0.05
}
if (state == 1)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmobsmd3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmobsmd4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmobsmd3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmobsmd2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmobsmd1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmobsmd0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmobsmd1
    else
        sprite_index = sbmobsmd2
    if (image_index < 2)
        chit = 0
    else if (image_index < 4)
        chit = 2
    else
        chit = 0
    if (image_index < 1)
    {
        image_speed = 0.1
        dir = idir + 180
    }
    else if (image_index < 3.5)
    {
        if (image_speed != 0.2)
        {
            spd = 8
            maxspd = 8
            scrmovcol(200, dir)
            scrsplash(x, y, sbmobsmsplash0, 0)
            objplayerview.shaket = 8
            image_speed = 0.2
        }
        else
        {
            maxspd = 4
            scrmovcol(spd, dir)
        }
    }
    else
    {
        image_index = 0
        spd = 0
        state = choose(2, 3)
    }
}
if (state == 2)
{
    chit = 0
    image_speed = 0
    sprite_index = sbmobsmshad1
    if (scrdist(self, objplayerview.player) > 64)
    {
        alpha = 0
        maxspd = 12
        var ad = angle_difference(dir, idir)
        dir -= ((min(abs(ad), 10)) * sign(ad))
        scrslowdir(5)
        scrmovcol(spd, dir)
    }
    else
    {
        alpha = 1
        image_index = 0
        alpha = 1
        state = 4
    }
}
if (state == 3)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmobsmr3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmobsmr4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmobsmr3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmobsmr2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmobsmr1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmobsmr0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmobsmr1
    else
        sprite_index = sbmobsmr2
    if (image_index < 1)
        chit = 0
    else if (image_index < 2.5)
        chit = 2
    else
        chit = 0
    if (timer3 == 0)
    {
        image_index = 0
        spd = 0
        dir = idir
        timer3 = 1
    }
    else if (timer3 == 1)
    {
        if (image_index < 1)
        {
            image_speed = 0.02
            if (image_index < 0.33)
                spd = 2
            else if (image_index < (1 - image_speed))
            {
                if (splash3 != 1)
                {
                    scrsplash(x, y, sbmobsmsplash0, 0)
                    objplayerview.shaket = 6
                    splash3 = 1
                }
            }
            else
            {
                spd = 20
                image_index = 1
            }
        }
        else if (image_index < 2)
        {
            image_speed = 0.05
            maxspd = 24
            if (splash3 < 5)
                splash3 += 1
            else
            {
                splash3 = 1
                scrsplash(x, y, sbmobsmsplash0, 1)
                objplayerview.shaket = 6
            }
        }
        else if (image_index < 3)
        {
            spd = 4
            maxspd = 4
            image_speed = 0.1
        }
        else if (image_index < (image_number - image_speed))
        {
            image_speed = 0.025
            spd = 1
            maxspd = 2
            if (splash3 != 0)
            {
                scrsplash(x, y, sbmobsmsplash0, 0)
                splash3 = 0
            }
        }
        else
            timer3 = 2
    }
    else if (timer3 == 2)
    {
        image_index = 0
        timer3 = 0
        state = 5
    }
    scrmovcol(spd, dir)
}
if (state == 4)
{
    if (dir >= 0 && dir < 180)
        sprite_index = sbmobsme3
    else
        sprite_index = sbmobsme1
    if (image_index < 1)
        image_speed = 0.1
    else if (image_index < 2)
    {
        image_speed = 0.05
        if (image_index > 1.5 && splash4 != 1)
        {
            scrsplash(x, y, sbmobsmsplash0, 2)
            splash4 = 1
        }
    }
    else if (image_index < 4)
    {
        image_speed = 0.2
        if (splash4 != 2)
        {
            scrsplash(x, y, sbmobsmsplash0, 1)
            objplayerview.shaket = 8
            splash4 = 2
        }
        if (eat == 0)
        {
            if place_meeting(x, y, objplayer)
                eat = 2
            else
                eat = 1
        }
    }
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.02
        if (splash4 != 0)
        {
            scrsplash(x, y, sbmobsmsplash0, 0)
            objplayerview.shaket = 8
            splash4 = 0
        }
    }
    else
    {
        image_index = 0
        eat = 0
        state = 5
    }
    if (eat == 2)
    {
        objplayer.alpha = 0
        objplayer.state = -1
        objplayerview.target = -4
        if (image_index > 2 && image_index < 4)
            objplayerview.targety = y - 300 + 300 * (abs(image_index - 3))
    }
}
if (state == 5)
{
    if (dir >= 0 && dir < 180)
    {
        sprite_index = sbmobsmu3
        if (dir < 90)
            dir = 45
        else
            dir = 135
    }
    else
    {
        sprite_index = sbmobsmu1
        if (dir < 270)
            dir = 225
        else
            dir = 315
    }
    if (image_index < 2)
        chit = 0
    else if (image_index < 4)
        chit = 2
    else
        chit = 0
    if (image_index < (image_number - image_speed))
    {
        if (image_index < 1)
            image_speed = 0.2
        else if (image_index < 2)
        {
            image_speed = 0.05
            spd = 4
            maxspd = 4
            if (splash5 != 1)
            {
                scrsplash(x, y, sbmobsmsplash0, 1)
                splash5 = 1
            }
        }
        else if (image_index < 4)
        {
            image_speed = 0.2
            scrmovcol(spd, dir)
            if (splash5 != 2)
            {
                scrsplash(x, y, sbmobsmsplash0, 1)
                objplayerview.shaket = 6
                splash5 = 2
            }
        }
        else if (splash5 != 0)
        {
            scrsplash(x, y, sbmobsmsplash0, 1)
            objplayerview.shaket = 6
            splash5 = 0
        }
    }
    else
    {
        image_index = 0
        state = 0
    }
}
if (state == 6)
{
    if (dir >= 22.5 && dir < 67.5)
    {
        sprite_index = sbmobsms3
        dir = 45
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        sprite_index = sbmobsms4
        dir = 90
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        sprite_index = sbmobsms3
        dir = 135
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        sprite_index = sbmobsms2
        dir = 180
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        sprite_index = sbmobsms1
        dir = 225
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        sprite_index = sbmobsms0
        dir = 270
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        sprite_index = sbmobsms1
        dir = 315
    }
    else
    {
        sprite_index = sbmobsms2
        dir = 360
    }
    if (image_index < 2)
        image_speed = 0.1
    else if (image_index < (image_number - image_speed))
    {
        if (spit == 0)
        {
            spit = 1
            objplayerview.shaket = 6
            repeat (12)
            {
                var ball = instance_create_depth((x + (lengthdir_x(32, dir))), (y + (lengthdir_y(32, dir))), (-y), objbmobsmspit)
                ball.dir = dir + (irandom_range(-30, 30))
                ball.dist = irandom_range(128, 1024)
            }
        }
        image_speed = 0.2
    }
    else
    {
        spit = 0
        image_index = 0
        state = 0
    }
}
if (state == 7)
{
    if (dir >= 22.5 && dir < 67.5)
    {
        sprite_index = sbmobsmc3
        dir = 45
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        sprite_index = sbmobsmc4
        dir = 90
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        sprite_index = sbmobsmc3
        dir = 135
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        sprite_index = sbmobsmc2
        dir = 180
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        sprite_index = sbmobsmc1
        dir = 225
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        sprite_index = sbmobsmc0
        dir = 270
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        sprite_index = sbmobsmc1
        dir = 315
    }
    else
    {
        sprite_index = sbmobsmc2
        dir = 360
    }
    if (image_index < 2)
        image_speed = 0.2
    else if (image_index < 2.2)
    {
        if (tongue == 0)
        {
            tongue = 1
            objplayerview.shaket = 6
            for (var i = -1; i <= 1; i++)
                instance_create_depth((x + (lengthdir_x(800, (dir + 30 * i)))), (y + (lengthdir_y(800, (dir + 30 * i)))), depth, objbmobsmcatch)
        }
    }
    else if (image_index < 3)
    {
        if instance_exists(objbmobsmcatch)
            image_speed = 0
        else
        {
            image_index = 3
            objplayerview.shaket = 6
        }
    }
    else if (image_index < (image_number - image_speed))
        image_speed = 0.1
    else
    {
        image_index = 0
        tongue = 0
        state = 0
    }
}
if (state == 8)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = smobsm2i3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = smobsm2i4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = smobsm2i3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = smobsm2i2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = smobsm2i1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = smobsm2i0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = smobsm2i1
    else
        sprite_index = smobsm2i2
}
if (state == 0)
{
    nextstate = choose(1, 1, 6, 7)
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmobsmi3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmobsmi4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmobsmi3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmobsmi2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmobsmi1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmobsmi0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmobsmi1
    else
        sprite_index = sbmobsmi2
    if (image_index < 1)
        image_speed = 0.05
    else if (objplayer.state != -1)
    {
        image_index = 0
        if (nextstate != 1)
            dir = idir
        state = nextstate
    }
}
