function scrrmtravel(argument0) //gml_Script_scrrmtravel
{
    if (argument0 == 8)
    {
        x = 2760
        y = 1768
    }
    if (argument0 == 7)
    {
        x = 2880
        y = 2560
    }
    if (argument0 == 5)
    {
        x = 4448
        y = 1728
    }
    if (argument0 == 6)
    {
        x = 896
        y = 2752
    }
    if (argument0 == 4)
    {
        x = 3692
        y = 1444
    }
    if (argument0 == 33)
    {
        x = 2530
        y = 2388
    }
    if (argument0 == 1)
    {
        x = 2460
        y = 2040
    }
    if (argument0 == 54)
    {
        x = 1710
        y = 2888
    }
    if (argument0 == 2)
    {
        x = 2960
        y = 2216
    }
    if (argument0 == 41)
    {
        x = 2072
        y = 2524
    }
    if (argument0 == 44)
    {
        x = 3260
        y = 2276
    }
    if (argument0 == 12)
    {
        x = 3584
        y = 2752
    }
    if (argument0 == 19)
    {
        x = 2828
        y = 2120
    }
    if (argument0 == 42)
    {
        x = 3072
        y = 2880
    }
    if (argument0 == 27)
    {
        x = 2304
        y = 1792
    }
    if (argument0 == 32)
    {
        x = 3328
        y = 2112
    }
    if (argument0 == 47)
    {
        x = 2432
        y = 1600
    }
    if (argument0 == 15)
    {
        x = 2596
        y = 904
    }
    if (argument0 == 34)
    {
        x = 3072
        y = 3392
    }
    if (argument0 == 40)
    {
        x = 2952
        y = 1564
    }
    if (argument0 == 3)
    {
        x = 3904
        y = 2176
    }
    if (argument0 == 49)
    {
        x = 1536
        y = 1280
    }
    if (argument0 == 23)
    {
        x = 3872
        y = 992
    }
    if (argument0 == 16)
    {
        x = 3392
        y = 1408
    }
    if (argument0 == 38)
    {
        x = 2304
        y = 2496
    }
    if (argument0 == 29)
    {
        x = 2464
        y = 1920
    }
    if (argument0 == 13)
    {
        x = 2048
        y = 3168
    }
    if (argument0 == 22)
    {
        x = 2752
        y = 2048
    }
    if (argument0 == 30)
    {
        x = 1472
        y = 192
    }
    if (argument0 == 46)
    {
        x = 2368
        y = 4352
    }
    if (argument0 == 21)
    {
        x = 3872
        y = 1056
    }
    if (argument0 == 14)
    {
        x = 1408
        y = 448
    }
    if (argument0 == 36)
    {
        x = 896
        y = 4032
    }
    if (argument0 == 54)
        fl = 1
    else
        fl = 0
}

