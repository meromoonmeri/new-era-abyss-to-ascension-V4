mobname = "Backward Snail"
maxhp = objbmobau.maxhp
hp = objbmobau.hp
dir = 0
spd = 0
delay = 0
pcatch = false
