draw_sprite_ext(sbmobsm1pshad, 0, x, y, (4 * size), (4 * size), 0, -1, (shalpha / 2))
draw_sprite_ext(sprite_index, image_index, x, (y - z), 4, 4, 0, -1, 1)
