event_inherited()
sprite = 2480
watershad = 1679
shadshad = 679
