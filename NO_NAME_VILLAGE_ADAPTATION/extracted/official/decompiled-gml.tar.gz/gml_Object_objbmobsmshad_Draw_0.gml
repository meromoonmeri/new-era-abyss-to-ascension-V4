if (!instance_exists(objbmobsm))
    instance_destroy()
else
    draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, 0, -1, (alpha * objbmobsm.alpha))
