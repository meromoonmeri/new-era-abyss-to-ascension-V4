event_inherited()
work = 0
timer = 0
timer1 = 0
