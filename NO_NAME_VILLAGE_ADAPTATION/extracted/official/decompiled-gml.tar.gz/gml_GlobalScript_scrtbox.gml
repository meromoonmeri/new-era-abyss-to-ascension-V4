function scrtbox(argument0, argument1) //gml_Script_scrtbox
{
    if (timertt == 0)
    {
        if (!instance_exists(objtextbox))
        {
            var textboxcreate = instance_create_depth(objplayerview.x, objplayerview.y, 0, objtextbox)
            with (textboxcreate)
            {
                if (argument0 == -1 || argument0 == 1847)
                    tbox = 1847
                else if (argument0 == 0)
                    tbox = 1206
                else if (argument0 == 1)
                    tbox = 342
                else
                    tbox = 1206
                text = argument1
            }
            timertt += 1
        }
    }
    else if (object_index != objstage)
    {
        if (!instance_exists(objtextbox))
        {
            timer += 1
            timertt = 0
        }
    }
}

