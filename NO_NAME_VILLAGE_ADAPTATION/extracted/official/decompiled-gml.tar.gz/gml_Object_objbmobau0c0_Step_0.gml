if (largen >= 0)
    size0 += ((1 - size0) / 48)
if (largen >= 1)
    size1 += ((1 - size1) / 24)
if (delay > 0)
    delay -= 1
else if (alpha < 0)
{
    alpha += 0.016666666666666666
    largen = 0
}
else if (alpha < 0.5)
{
    alpha += 0.004166666666666667
    largen = 1
}
else if (alpha >= 1)
    instance_destroy()
else
    alpha = 3
var range = 16 * alpha
shakex1 = random_range((-range), range)
shakey1 = random_range((-range), range)
shakex2 = random_range((-range), range)
shakey2 = random_range((-range), range)
shakex3 = random_range((-range), range)
shakey3 = random_range((-range), range)
