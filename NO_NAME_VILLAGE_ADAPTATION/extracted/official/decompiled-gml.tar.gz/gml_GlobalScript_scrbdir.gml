function scrbdir(argument0) //gml_Script_scrbdir
{
    var bdir = argument0
    bdir = argument0 + 180
    if (bdir >= 360)
        bdir -= 180
    else if (bdir < 0)
        bdir += 180
    return bdir;
}

