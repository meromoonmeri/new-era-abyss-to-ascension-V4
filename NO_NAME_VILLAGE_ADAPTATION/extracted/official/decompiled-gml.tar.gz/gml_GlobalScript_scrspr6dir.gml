function scrspr6dir(argument0, argument1, argument2, argument3, argument4) //gml_Script_scrspr6dir
{
    if (argument0 >= 0 && argument0 < 60)
        sprite_index = argument3
    else if (argument0 >= 60 && argument0 < 120)
        sprite_index = argument4
    else if (argument0 >= 120 && argument0 < 180)
        sprite_index = argument3
    else if (argument0 >= 180 && argument0 < 240)
        sprite_index = argument2
    else if (argument0 >= 240 && argument0 < 300)
        sprite_index = argument1
    else
        sprite_index = argument2
}

