function scrcheckavailablecontrols(argument0) //gml_Script_scrcheckavailablecontrols
{
    if (argument0 == global.c_up || argument0 == global.c_down || argument0 == global.c_left || argument0 == global.c_right || argument0 == global.c_select || argument0 == global.c_back || argument0 == global.c_switch || argument0 == 27 || argument0 == 77 || argument0 == 73)
        return 0;
    else
        return 1;
}

