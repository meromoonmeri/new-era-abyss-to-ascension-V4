depth = (-y)
start = 0
sprite = 454
watershad = 385
shadshad = 1890
