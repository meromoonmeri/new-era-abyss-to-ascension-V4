scrsound(snbmobaut0, 100, 1, 1)
dir = scrdir(objbmobau, id)
fl = 0
spd = 130
turn = 5
maxcheck = 0
changedir = choose(-10, 10)
ptarg = false
target = 0
snatch = false
