function scrplayerrun(argument0, argument1) //gml_Script_scrplayerrun
{
    with (objplayerview.player)
    {
        objplayer.caninput = false
        controlinput = true
        state = -1
        dir = point_direction(objplayer.x, objplayer.y, argument0, argument1)
        image_speed = 0.036 * spd + 0.05
        if (spd > 7)
        {
            if (objplayerview.player == 100)
                scrspr8dir(dir, spr0, spr1, spr2, spr3, spr4)
            else
                scrspr8dir(dir, srr0, srr1, srr2, srr3, srr4)
        }
        else if (spd > 0.2)
        {
            if (objplayerview.player == 100)
                scrspr8dir(dir, spw0, spw1, spw2, spw3, spw4)
            else
                scrspr8dir(dir, srw0, srw1, srw2, srw3, srw4)
        }
        else if (objplayerview.player == 100)
            scrspr8dir(dir, spi0, spi1, spi2, spi3, spi4)
        else
            scrspr8dir(dir, sri0, sri1, sri2, sri3, sri4)
        if (scrmovcol(spd, dir) > 0)
            return 0.5;
        if (point_distance(x, y, argument0, argument1) > 128)
            spd += ((8 - spd) / 24)
        else if (point_distance(x, y, argument0, argument1) > 12)
            spd += ((0.1 - spd) / 24)
        else
        {
            spd = 0
            return 1;
        }
        if (spd > 6)
            scrptdust2(x, y, 463, dir, 32, 5, (spd * 2 / 100))
    }
}

