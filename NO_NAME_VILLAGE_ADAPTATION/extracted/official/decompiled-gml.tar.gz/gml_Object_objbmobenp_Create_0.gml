if position_meeting(x, y, objallcol)
    instance_destroy()
depth = (-room_height) * 4
image_speed = 0
fl = 0
pindex = irandom(7)
dist = 0
spd = 0
dir = 0
alpha = 0
timer = 0
shoot = 0
explode = 0
startx = x
starty = y
startz = 0
dud = false
pspd = 128
notrail = false
trail = 0
px = 0
py = 0
pz = 0
part_system = part_system_create()
part_system_depth(part_system, ((-room_height) * 4))
part_type = part_type_create()
part_type_sprite(part_type, 501, 1, 1, 1)
part_type_color3(part_type, 16777215, 16777215, 0)
part_type_speed(part_type, 12, 12, 0, 0)
part_type_direction(part_type, 65, 115, 0, 0)
part_type_gravity(part_type, 0.6, 270)
part_type_life(part_type, 20, 20)
part_type2 = part_type_create()
part_type22 = part_type_create()
part_type_sprite(part_type2, 501, 1, 1, 1)
part_type_color1(part_type2, 16777215)
part_type_alpha2(part_type2, 1, 0.4)
part_type_speed(part_type2, 6, 12, 0, 0)
part_type_direction(part_type2, 80, 100, 0, 0)
part_type_gravity(part_type2, 0.6, 270)
part_type_life(part_type2, 20, 20)
part_type_sprite(part_type22, 501, 0, 0, 1)
part_type_alpha2(part_type22, 0.8, 0)
part_type_color1(part_type22, 8421504)
part_type_life(part_type22, 60, 60)
