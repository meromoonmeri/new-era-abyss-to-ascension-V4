function scrtimetofadeout(argument0, argument1) //gml_Script_scrtimetofadeout
{
    objplayer.caninput = false
    if (timertt < argument0)
        timertt += 1
    else if (objplayerview.lat > 0)
    {
        objplayerview.la = 0
        objplayerview.latt = argument1
    }
    else
    {
        timer += 1
        timertt = 0
        objplayerview.latt = 0.025
    }
}

