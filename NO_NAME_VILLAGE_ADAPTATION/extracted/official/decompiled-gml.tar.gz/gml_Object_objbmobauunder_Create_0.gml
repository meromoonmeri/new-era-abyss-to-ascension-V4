alpha = 1
