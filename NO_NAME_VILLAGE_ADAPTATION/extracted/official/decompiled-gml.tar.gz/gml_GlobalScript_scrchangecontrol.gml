function scrchangecontrol(argument0, argument1) //gml_Script_scrchangecontrol
{
    var order = [65, 66, 67, 68, 69, 70, 71, 72, 72, 74, 75, 76, 76, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 37, 38, 40, 39, 9, 9, 16, 17, 18, 32]
    if (argument1 >= 0 && argument1 < array_length(order))
    {
        var n = argument1
        if (n == 40)
            n = 41
        return order[n];
    }
    return argument0;
}

