var player = objplayerview.player
depth = (-y)
if (state < 1)
{
    state += 0.011111111111111112
    repeat (4)
    {
        var sradius = clamp((1 - state), 0.2, 1)
        var rdist = (random(64) + random(64) + random(64) + random(64)) * sradius
        var rdir = random(360)
        part_particles_create(part_system, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), part_type, 1)
    }
}
else if (state < 2)
{
    state = 2
    image_alpha = 1
    scrsplash(x, y, smobsm2splash, 0)
    repeat (6)
    {
        rdist = random_range(32, 96)
        rdir = random(360)
        part_particles_create(global.psball0, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y(rdist, rdir))), wpt0, 1)
    }
}
else if (state < 3)
{
    state += 0.0016666666666666668
    image_speed = spd * 0.2
    if (floor(splash) != floor(image_index))
        splash = floor(image_index)
    if (splash == 1)
    {
        splash = 1.5
        scrsplash(x, y, ssplash0, 4)
        scrsound(snbmobaub0, 20, 1, 1)
        part_particles_create(global.psball, x, y, pt00, 1)
        var bslow = instance_create_layer(x, y, "shadows", objbmobaubslow)
        bslow.creator = id
    }
    if ((global.time % 1) == 0)
    {
        rdist = random_range(32, 96)
        rdir = dir + 180 + (random_range(-60, 60))
        part_particles_create(part_system, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), part_type, 1)
    }
    if (scrmovcol(spd, dir) != 1 && (!(instance_place(x, y, player))) && (!(instance_place(x, y, objmob))))
    {
        spd += ((2 - spd) / 60)
        var ad = (angle_difference(dir, scrdir(self, objplayerview.player))) / 360
        dir -= ((min(abs(ad), 10)) * sign(ad))
    }
    else
        state = 3
}
else if (state == 3)
{
    state = 4
    image_alpha = 0
    scrsound(snexplode2, 200, 1, 1)
    scrsplash(x, y, smobau2splash, 0)
    repeat (20)
    {
        rdist = random_range(32, 96)
        rdir = random(360)
        part_particles_create(global.psball0, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y(rdist, rdir))), wpt0, 1)
    }
    lastbslow = instance_create_layer(x, y, "shadows", objbmobaubslow)
    lastbslow.sprite_index = sbmobaubeslow
    lastbslow.creator = id
    var pcol = instance_place(x, y, player)
    if (pcol != noone && pcol.iframe <= 0)
    {
        if (player != objft0)
            objplayer.hp -= 3
        else
            objft0.hp -= 3
        pcol.iframe = 1
        pcol.state = 6
        pcol.dir = scrdir(pcol, self)
        pcol.caninput = false
        pcol.image_index = 0
        objplayerview.shaket = 16
    }
}
else if (!instance_exists(lastbslow))
    instance_destroy()
with (player)
{
    var pslow = instance_place(x, y, objbmobaubslow)
    if (pslow != noone)
        other.slow = pslow.creator
}
if (slow == id)
{
    slow = -4
    repeat (2)
    {
        rdist = random(16) + random(64)
        rdir = random(360)
        part_particles_create(part_system, (player.x + (lengthdir_x(rdist, rdir))), (player.y + (lengthdir_y((rdist / 2), rdir))), part_type, 1)
    }
    var aworms = 0
    aworms = player.spd / 4
    if (scrinput("runr") || scrinput("actionp"))
    {
        aworms = 8
        objplayerview.shaket = 4
        player.flash = 0.5
    }
    repeat aworms
        part_particles_create(global.psball0, player.x, player.y, wpt0, 1)
}
if (place_meeting(x, y, objphbox) && state >= 2 && state < 3)
    state = 3
