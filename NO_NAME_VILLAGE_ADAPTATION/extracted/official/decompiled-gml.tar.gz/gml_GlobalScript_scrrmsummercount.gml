function scrrmsummercount() //gml_Script_scrrmsummercount
{
    var summercount = 0
    if (global.mapgrid[5][3] > 0)
        summercount += 1
    if (global.mapgrid[5][4] > 0)
        summercount += 1
    if (global.mapgrid[6][3] > 0)
        summercount += 1
    if (global.mapgrid[6][4] > 0)
        summercount += 1
    if (global.mapgrid[6][5] > 0)
        summercount += 1
    if (global.mapgrid[7][3] > 0)
        summercount += 1
    if (global.mapgrid[7][4] > 0)
        summercount += 1
    if (global.mapgrid[7][5] > 0)
        summercount += 1
    if (global.mapgrid[8][2] > 0)
        summercount += 1
    if (global.mapgrid[8][3] > 0)
        summercount += 1
    if (global.mapgrid[8][4] > 0)
        summercount += 1
    if (global.mapgrid[8][5] > 0)
        summercount += 1
    return summercount;
}

