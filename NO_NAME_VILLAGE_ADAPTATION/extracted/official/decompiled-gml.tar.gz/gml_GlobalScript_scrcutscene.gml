function scrcutscene(argument0, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9) //gml_Script_scrcutscene
{
    if (!variable_global_exists("cutscenes"))
        global.cutscenes = ds_map_create()
    if (!(ds_map_exists(global.cutscenes, argument0)))
    {
        var sframe = ds_map_create()
        for (var sf = 0; sf < sprite_get_number(argument0); sf++)
            ds_map_add(sframe, sf, 0)
        ds_map_add(global.cutscenes, argument0, sframe)
    }
    var subframe = ds_map_find_value(global.cutscenes, argument0)
    var subsize = ds_map_size(subframe)
    var imgmax = sprite_get_number(argument0)
    var sprframe = floor(argument1 % imgmax)
    for (var i = 0; i < subsize; i++)
    {
        var falph = ds_map_find_value(subframe, i)
        var nalph = ds_map_find_value(subframe, ((i + 1) % imgmax))
        if (sprframe == i || (sprframe == ((i + 1) % imgmax) && nalph < 1))
            ds_map_replace(subframe, i, clamp((falph + argument8), 0, 1))
        else
            ds_map_replace(subframe, i, clamp((falph - argument8), 0, 1))
        var ifalph = ds_map_find_value(subframe, i)
        draw_sprite_ext(argument0, i, argument2, argument3, argument4, argument5, argument6, -1, (argument7 * ifalph))
    }
}

