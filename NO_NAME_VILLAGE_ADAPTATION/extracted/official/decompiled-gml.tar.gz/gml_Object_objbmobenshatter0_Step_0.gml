if (shatter == 0)
{
    sprite_index = sbmobenshatter00
    x = 4160
    y = 960
    image_xscale = -4
    image_yscale = 4
}
else if (shatter == 1)
{
    sprite_index = sbmobenshatter30
    x = 3136
    y = 960
    image_xscale = -4
    image_yscale = -4
}
else if (shatter == 2)
{
    sprite_index = sbmobenshatter20
    x = 3328
    y = 1408
    image_xscale = 4
    image_yscale = 4
}
else if (shatter == 3)
{
    sprite_index = sbmobenshatter10
    x = 4032
    y = 1088
    image_xscale = 4
    image_yscale = 4
}
else if (shatter == 4)
{
    sprite_index = sbmobenshatter10
    x = 3136
    y = 1024
    image_xscale = 4
    image_yscale = 4
}
else
{
    sprite_index = sbmobenshatter30
    x = 4096
    y = 1408
    image_xscale = -4
    image_yscale = 4
}
if (image_alpha < 0.8)
    image_alpha += 0.013333333333333334
else if (image_alpha < 1)
{
    image_alpha = 1
    var s = instance_create_depth(x, y, (-y), objbmobenshatter1)
    if (sprite_index == sbmobenshatter00)
    {
        s.sprite_index = sbmobenshatter01
        scrsplash(x, y, smobau2splash, 0)
    }
    if (sprite_index == sbmobenshatter10)
    {
        s.sprite_index = sbmobenshatter11
        scrsplash(x, y, smobsm2splash, 0)
    }
    if (sprite_index == sbmobenshatter20)
    {
        s.sprite_index = sbmobenshatter21
        scrsplash(x, y, smobau3splash, 0)
    }
    if (sprite_index == sbmobenshatter30)
    {
        s.sprite_index = sbmobenshatter31
        scrsplash(x, y, sbmobsmsplash0, 0)
    }
    s.image_xscale = image_xscale
    s.image_yscale = abs(image_yscale)
}
else if (scale < 1)
    scale += ((1 - scale) / 10)
