function scrrivermap(argument0) //gml_Script_scrrivermap
{
    if (argument0 == 32 || argument0 == 25 || argument0 == 47 || argument0 == 17 || argument0 == 15 || argument0 == 34 || argument0 == 50 || argument0 == 40 || argument0 == 8 || argument0 == 5 || argument0 == 54 || argument0 == 6 || argument0 == 44 || argument0 == 28 || argument0 == 12 || argument0 == 42)
        return 1;
}

