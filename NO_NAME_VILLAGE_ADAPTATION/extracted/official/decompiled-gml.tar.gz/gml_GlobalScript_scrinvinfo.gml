function scrinvinfo(argument0, argument1, argument2) //gml_Script_scrinvinfo
{
    var itemdesc = argument0
    var foldx = argument1
    var fold = argument2
    var name = ""
    var desc = -1
    var desc2 = -1
    var upgrade = -1
    switch itemdesc
    {
        case 0:
            break
        case 1:
            name = "Empty__Bucket"
            desc = "Stand__above__the__river\nand__press£"
            break
        case 2:
            name = "Full__Bucket"
            desc = "Water__for__dad's\nwork."
            break
        case 3:
            name = "Wooden__Sword"
            desc = "A__really,__REALLY, hard__stick__that never__breaks!"
            desc2 = "\nPress_£_to__attack\nHold_£_to__attack__down"
            upgrade = 1
            break
        case 4:
            name = "Monster__Tadpole"
            break
        case 5:
            name = "Child__Shirt"
            desc = "Had__the__same__shirt since__forever!"
            desc2 = "\nHold_$_to__sprint\nTap_$_to__dodge"
            upgrade = 1
            break
        case 6:
            name = "Book"
            desc = "\nRead__the__book__at__bed."
            break
        case 7:
            name = "Herb"
            break
        case 8:
            name = "Herb"
            break
        case 9:
            name = "Herb"
            break
        case 10:
            name = "Herb"
            break
        case 11:
            name = "Orphan__Bells"
            desc = "Small__bulbs__that glow__when__shaken.\nMakes__a__nice ring__too."
            desc2 = "\nPress&to__switch\n\nPress_£_to__shake."
            break
        case 12:
            name = "Blank__Paper"
            break
        case 13:
            name = "Calling__Shell"
            desc = "Suuuper__loud"
            desc2 = "Use__at__landmarks for__fast__travel\nCan__be__used__to__and from__the__village at__any__location"
            break
        case 14:
            name = "Black__Sea__Blob"
            desc = "Reg__found__it.\nNot__sure__how__or what__it__is\nBut__it's__cool!"
            desc2 = "\nPress_&_to__switch\n\nPress_£_to__throw"
            break
        case 15:
            name = "Rusted__Sword"
            desc = "Something__Ruben__made and__showed__off a__while__ago."
            break
        case 16:
            name = "Basket"
            desc = "This__was__left__in\nthat__shed.\nNot__something__to\nget__in__trouble,__right?"
            break
        case 17:
            name = "Spikes"
            desc = "Shedded__spikes.\nHurts__like__splinters."
            break
        case 18:
            name = "Tree__Berries"
            desc = "Not__edible.\nGives__stomach__aches.\nReg__confirms."
            break
        case 19:
            name = "Map"
            break
        case 20:
            name = "Homemade__Berries"
            desc = "Wait.\nDo__frogs__eat\nberries?"
            break
        case 21:
            name = "Large__Saw"
            desc = "Reg's__dad__calls__it\na__crosscut__saw.\nHe__already__has\nplenty."
            desc2 = "I'm__sure__he\nwon't__miss__one."
            break
        case 22:
            name = "Charged__Scales"
            desc = "Feels__funny.\nIt__also__makes__weird\nnoises__when__you__rub\ntwo__together."
            break
        case 23:
            name = "Explosive__Eggs"
            desc = "It's__surprisingly\ncold...\nWhich__only__makes\nit__scarier."
            break
        case 24:
            name = "Tapestry"
            desc = "A__portrait__of__Ruben.\nIt's__tradition__to\nweave__tapestries__of\nthe__deceased."
            break
        case 25:
            name = "Shovel"
            desc = "This__might__be__the\nonly__shovel__left.\nI__doubt__they'd\nmake__another."
            desc2 = "\nInteract__with__snow\npiles__to__dig."
            break
        case 26:
            name = "Lunch__Basket"
            desc = "Wish__there's__meat in__here"
            desc2 = "\n\nPress_#_to__heal"
            upgrade = 1
            break
        case 27:
            name = "Reg's__Dagger"
            desc = "A__pitch__black__dagger\nwith__three__sides.\nThere's__grooves__on__it,\nbut__I__can't__read__it."
            desc2 = "\nPress&to__switch\n\nPress_£_to__throw."
            break
        case 28:
            name = "Mystery__Fruit"
            desc = "Used__to__upgrade lunch__basket!"
            break
        case 29:
            name = "Sticky__Tar"
            desc = "Used__to__upgrade wooden__sword!"
            break
        case 30:
            name = "Tough__Threads"
            desc = "Used__to__upgrade child__shirt!"
            break
        case 31:
            break
        default:

    }

    var txtx = fold * sprite_get_width(sm13) * 2 + foldx + 988
    var txty = menuy + sinvinfo + 216
    var vc = -1
    var sep = sprite_get_height(sfont6x9id) + 12
    if (desc != -1)
    {
        draw_sprite_ext(sm13, 0, (foldx + 988), (menuy + sinvinfo + 216), (4 * fold), 4, 0, -1, 1)
        scrsfont(1187, txtx, (16 + txty), name, c_black, fa_center, fa_top, sep, 400, 1.2, 1.2)
        scrsfont(1187, txtx, (80 + txty), desc, vc, fa_center, fa_top, sep, 400, 1, 1)
    }
    if (desc2 != -1)
    {
        draw_sprite_ext(sm13, 0, (foldx + 988), (sprite_get_height(sm13) * 4 * 2 + menuy + sinvinfo + 216), (4 * fold), -4, 0, -1, 1)
        scrsfont(1187, txtx, (20 + sprite_get_height(sm13) * 4 + txty), desc2, vc, fa_center, fa_top, sep, 400, 1, 1)
    }
    if (upgrade == 1)
        scrsfont(1187, (24 + foldx + 988), (528 + txty), "Upgrade:", c_black, fa_left, fa_top, sep, 400, 1, 1)
}

