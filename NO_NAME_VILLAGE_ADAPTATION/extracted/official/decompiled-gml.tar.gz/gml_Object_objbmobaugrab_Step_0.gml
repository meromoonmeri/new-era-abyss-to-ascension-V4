var accl = 0.2
if (jump < 4)
{
    if (timer == 0)
    {
        timer = 1
        vel = 3
    }
    else if (timer == 1)
    {
        scrmovcol(spd, dir)
        if (z >= 0)
        {
            z += vel
            vel -= accl
            part_system_depth(ps, (-y))
            part_particles_create(ps, x, (y - z), pt, 1)
            if (spd != 3)
            {
                spd = 3
                scrsplash(x, y, ssplash0, 1)
            }
        }
        else
        {
            if (spd != 4)
            {
                spd = 4
                scrsplash(x, y, ssplash0, 1)
            }
            if (vel < 0)
            {
                vel += accl
                var ad = angle_difference(dir, scrdir(self, objplayerview.player))
                dir -= ((min(abs(ad), 2)) * sign(ad))
            }
            else
            {
                jump += 1
                timer = 0
                z = 0
                if (scrdistview(x, y, objplayerview.player.x, objplayerview.player.y) < 128)
                {
                    jump = 5
                    depth = (-y)
                    x = objplayerview.player.x
                    y = objplayerview.player.y
                }
            }
        }
    }
    if (psubt < 1)
    {
        if (z > 0)
            psubt += 1
        else
            psubt += 0.5
    }
    else
    {
        psubt = 0
        var rdist = irandom(128)
        var rdir = irandom(360)
        part_particles_create(ps, (x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), pt2, 1)
    }
}
else if (jump == 5)
{
    if (image_index < 4)
    {
        depth = layer_get_depth("shadows")
        image_speed = 0.15
        alpha = 1
    }
    else if (image_index < (image_number - image_speed))
    {
        if (grab < 0)
        {
            grab = 0
            image_speed = 0.2
            scrsplash(x, y, smobau2splash, 0)
            if instance_place(x, y, objplayerview.player)
            {
                grab = 5
                player = objplayerview.player
                with (player)
                {
                    x = other.x
                    y = other.y
                    other.depth = depth + 16
                    state = -1
                    objplayer.caninput = false
                    if (other.player == objplayer)
                    {
                        sprite_index = spci1
                        image_index = 0
                        image_speed = 0
                    }
                    else
                    {
                        sprite_index = sr507
                        image_index = 1
                        image_speed = 0
                    }
                }
            }
            with (objbmobau)
            {
                repeat (3)
                {
                    rdist = random_range(0, 64)
                    rdir = random(360)
                    part_particles_create(ps, (other.x + (lengthdir_x(rdist, rdir))), (other.y + (lengthdir_y((rdist / 2), rdir))), wpt0, 1)
                }
                repeat (10)
                {
                    rdist = random_range(0, 64)
                    rdir = random(360)
                    part_particles_create(ps, (other.x + (lengthdir_x(rdist, rdir))), (other.y + (lengthdir_y((rdist / 2), rdir))), wpt1, 1)
                }
            }
        }
        if (grab > 0 && image_index > 6)
        {
            image_speed = 0
            if (objplayerview.player == player)
            {
                if (flash <= 0 && (scrinput("actionp") || scrinput("runpp")))
                {
                    if (grab > 1)
                    {
                        grab -= 1
                        objplayerview.shaket = 6
                        flash = 0.5
                        player.flash = 0.5
                    }
                    else
                    {
                        grab -= 1
                        objplayerview.shaket = 12
                        flash = 1
                        player.flash = 1
                        player.state = 0
                        objplayer.caninput = true
                    }
                }
            }
        }
        else
            image_speed = 0.2
    }
    else
        instance_destroy()
}
else
    instance_destroy()
if (flash > 0)
    flash -= 0.05
