function scrsoundstop(argument0, argument1, argument2, argument3) //gml_Script_scrsoundstop
{
    if audio_is_playing(argument0)
    {
        audio_play_sound(argument0, argument1, 1)
        audio_sound_gain(argument0, 0, 0)
        audio_sound_gain(argument0, argument2, argument3)
    }
}

