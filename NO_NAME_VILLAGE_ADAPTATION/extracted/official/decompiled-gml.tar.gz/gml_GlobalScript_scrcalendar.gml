function scrcalendar(argument0, argument1) //gml_Script_scrcalendar
{
    if (!instance_exists(objcalendarcontrol))
    {
        var calendar = instance_create_layer(0, 0, "instances", objcalendarcontrol)
        calendar.rotation = argument0
        calendar.nextrotation = argument1
        with (objplayer)
            calendar = argument1
    }
}

