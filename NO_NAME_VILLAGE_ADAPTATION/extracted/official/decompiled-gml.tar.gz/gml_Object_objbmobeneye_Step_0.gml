if (open == 1)
{
    if (image_index < 3)
    {
        image_speed = 0.2
        if (sound == 0)
        {
            sound = 1
            scrsound(snbmobeneyeclose0, 50, 1, 1)
        }
    }
    else if (image_index < 4)
        image_speed = 0.05
    else if (image_index < 6)
    {
        image_speed = 0.2
        if (timer < 0)
            timer = 0
        if (sound == 1)
        {
            sound = 2
            scrsound(snbmobeneyeopen0, 50, 1, 1)
        }
    }
    else if (image_index < 6.5)
        image_speed = 0.016666666666666666
    else
    {
        image_speed = 0
        ended = 1
    }
}
else if (image_index > 3)
    image_speed = -0.2
else if (image_alpha > 0)
    image_alpha += ((0 - image_alpha) / 12)
if (image_index < 5)
{
    var v = image_index / 5
    t = (power(v, (1/3))) * 0.05
}
else if (image_index < 6)
{
    v = image_index - 5
    t = (power(v, (1/3))) * 0.15 + 0.05
}
else if (image_index < 7)
{
    v = image_index - 6
    t = (power(v, (1/3))) * 0.8 + 0.2
}
if (timer >= 0)
    timer += 1
var cd1 = 202
var cd2 = 64
var cd3 = 293
if (phase == 2)
{
    cd1 = 310
    cd2 = 110
    cd3 = -1
    cc1 = 2
    cc2 = 3
    cc3 = 0
}
if (phase == 3)
{
    cd1 = 120
    cd2 = 30
    cd3 = 260
    cc1 = 1
    cc2 = 1
    cc3 = 2
}
if (timer > 8)
{
    s0 += ((1 - s0) / 3)
    x0 += ((-16 - x0) / 60)
}
if (timer > 12)
{
    h1 += ((32 - h1) / 12)
    if (cd1 < 0)
        h1 = -1
    x1 = x + (lengthdir_x(290, (cd1 + h1)))
    y1 = y + (lengthdir_y(166, (cd1 + h1)))
    s10 += ((1 - s10) / 3)
    s11 += ((1 - s11) / 5)
    s12 += ((1 - s12) / 8)
}
if (timer > 18)
{
    h2 += ((16 - h2) / 12)
    if (cd2 < 0)
        h2 = -1
    x2 = x + (lengthdir_x(140, (cd2 + h2)))
    y2 = y + (lengthdir_y(82, (cd2 + h2)))
    s20 += ((1 - s20) / 3)
    s21 += ((1 - s21) / 5)
    s22 += ((1 - s22) / 8)
}
if (timer > 24)
{
    h3 += ((48 - h3) / 12)
    if (cd3 < 0)
        h3 = -1
    x3 = x + (lengthdir_x(242, (cd3 + h3)))
    y3 = y + (lengthdir_y(138, (cd3 + h3)))
    s30 += ((1 - s30) / 3)
    s31 += ((1 - s31) / 5)
    s32 += ((1 - s32) / 8)
}
