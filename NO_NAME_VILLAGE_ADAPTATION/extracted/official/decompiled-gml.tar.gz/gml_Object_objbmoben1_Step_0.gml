event_inherited()
if (spd > 0)
{
    if (scrdistview(trailx, traily, x, y) > 24)
    {
        trailx = x
        traily = y
        scrsnowtrail(x, y, spwtrail)
    }
}
if (state == -1)
{
    dir = 90
    if (timere1 == 0)
    {
        sprite_index = sbmoben1e0
        image_index = 0
        image_speed = 0
    }
    else if (timere1 == 1)
    {
        sprite_index = sbmoben1e0
        image_index = 1
        image_speed = 0
    }
    else
    {
        image_index = 0
        state = 3
    }
}
if (state == 0)
{
    if (pattern < 0)
    {
        image_index = 0
        image_speed = 0
        if (dir >= 22.5 && dir < 67.5)
            sprite_index = sbmoben1i3
        else if (dir >= 67.5 && dir < 112.5)
            sprite_index = sbmoben1i4
        else if (dir >= 112.5 && dir < 157.5)
            sprite_index = sbmoben1i3
        else if (dir >= 157.5 && dir < 202.5)
            sprite_index = sbmoben1i2
        else if (dir >= 202.5 && dir < 247.5)
            sprite_index = sbmoben1i1
        else if (dir >= 247.5 && dir < 292.5)
            sprite_index = sbmoben1i0
        else if (dir >= 292.5 && dir < 337.5)
            sprite_index = sbmoben1i1
        else
            sprite_index = sbmoben1i2
        pattern += 0.016666666666666666
        scrmovcol(spd, dir)
        spd += (-1 * spd / 4)
    }
    else if (pattern < 1)
    {
        if (nextpattern != -1)
            pattern = nextpattern
        else
            pattern = 1
        nextpattern = -1
    }
    else
    {
        if (pattern == 1)
        {
            if (timer1 == 0)
                timer1 = 1
            else if (timer1 < 15)
            {
                turn = angle_difference(scrdir(self, objrm53), scrdir(self, objplayer))
                if (point_distance(x, y, player.x, player.y) < 256 && prevpattern != 3)
                    pattern = 3
                if (scrdistview(objrm53.x, objrm53.y, x, y) < 320)
                    adjturn = 20
                else if (scrdistview(objrm53.x, objrm53.y, x, y) > 512)
                    adjturn = -20
                else
                    adjturn = 0
                dir1 = (point_direction(x, y, objrm53.x, objrm53.y)) + 90 * sign(turn) + adjturn * sign(turn)
                state = 1
                prevpattern = -1
                timer1 += 1
            }
            else
            {
                timer1 = 0
                nextpattern = 2
                pattern = -0.1
            }
        }
        else
            timer1 = 0
        if (pattern == 2)
        {
            if (timer2 == 0)
            {
                image_index = 0
                state = 2
                prevpattern = 2
                pattern = 1
            }
        }
        else
            timer2 = 0
        if (pattern == 3)
        {
            if (timer3 == 0)
            {
                image_index = 0
                state = 3
                prevpattern = 3
                pattern = 1
            }
        }
        else
            timer3 = 0
    }
}
if (state == 1)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmoben1m3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmoben1m4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmoben1m3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmoben1m2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmoben1m1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmoben1m0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmoben1m1
    else
        sprite_index = sbmoben1m2
    if scrmovcol(spd, dir)
    {
        var d1 = angle_difference(dir1, scrdir(self, objrm53))
        dir -= ((min(abs(d1), 15)) * sign(d1))
    }
    if collision_line(x, y, (x + (lengthdir_x(64, dir1))), (y + (lengthdir_y(64, dir1))), objtreecol, true, false)
    {
        d1 = angle_difference(dir1, scrdir(self, objrm53))
        dir -= ((min(abs(d1), 10)) * sign(d1))
    }
    var ad = angle_difference(dir, dir1)
    dir -= ((min(abs(ad), 5)) * sign(ad))
    if ((timer1 % 2) == 0)
    {
        if (image_index < (4 - image_speed))
        {
            spd += (-1 * (spd - 8) / 12)
            image_speed = 0.05 * spd
        }
        else
        {
            image_speed = 0
            state = 0
        }
        if (image_index > 3 && splash != 1)
        {
            splash = 1
            scrsplash(x, y, ssplash0, 1)
            scrsnowtrail(x, y, spwtrail)
        }
    }
    else
    {
        if (image_index < (image_number - image_speed))
        {
            spd += (-1 * (spd - 8) / 12)
            image_speed = 0.05 * spd
        }
        else
        {
            image_speed = 0
            state = 0
        }
        if (image_index > 7 && splash != 2)
        {
            splash = 2
            scrsplash(x, y, ssplash0, 1)
            scrsnowtrail(x, y, spwtrail)
        }
    }
}
else
    splash = 0
if (state == 2)
{
    if (dir2 >= 22.5 && dir2 < 67.5)
        sprite_index = sbmoben1tu3
    else if (dir2 >= 67.5 && dir2 < 112.5)
        sprite_index = sbmoben1tu4
    else if (dir2 >= 112.5 && dir2 < 157.5)
        sprite_index = sbmoben1tu3
    else if (dir2 >= 157.5 && dir2 < 202.5)
        sprite_index = sbmoben1tu2
    else if (dir2 >= 202.5 && dir2 < 247.5)
        sprite_index = sbmoben1tu1
    else if (dir2 >= 247.5 && dir2 < 292.5)
        sprite_index = sbmoben1tu0
    else if (dir2 >= 292.5 && dir2 < 337.5)
        sprite_index = sbmoben1tu1
    else
        sprite_index = sbmoben1tu2
    scrmovcol(spd, dir)
    if (image_index < 1)
    {
        image_speed = 0.2
        if ((image_index % 1) == 0)
            scrsplash(x, y, ssplash0, 1)
        ad = angle_difference(dir2, idir)
        dir2 -= ((min(abs(ad), 36)) * sign(ad))
        spd += (-1 * spd / 8)
    }
    else if (image_index < (image_number - image_speed))
    {
        dir2 = idir
        image_speed = 0.1
        if (timer2s != 1)
        {
            timer2s = 1
            var p = instance_create_layer((x + 78), y, "instances", objbmobenp1)
            p.dir = dir2
            p.height = 72
            p.spd = 1
            velheight = 8
        }
        spd += (-1 * (spd - 2) / 2)
    }
    else
        state = 0
}
else
{
    timer2s = 0
    dir2 = idir
}
if (state == 3)
{
    if (dir3 >= 22.5 && dir3 < 67.5)
        sprite_index = sbmoben1td3
    else if (dir3 >= 67.5 && dir3 < 112.5)
        sprite_index = sbmoben1td4
    else if (dir3 >= 112.5 && dir3 < 157.5)
        sprite_index = sbmoben1td3
    else if (dir3 >= 157.5 && dir3 < 202.5)
        sprite_index = sbmoben1td2
    else if (dir3 >= 202.5 && dir3 < 247.5)
        sprite_index = sbmoben1td1
    else if (dir3 >= 247.5 && dir3 < 292.5)
        sprite_index = sbmoben1td0
    else if (dir3 >= 292.5 && dir3 < 337.5)
        sprite_index = sbmoben1td1
    else
        sprite_index = sbmoben1td2
    scrmovcol(spd, dir3)
    if (image_index < 2)
    {
        image_speed = 0.2
        if ((image_index % 1) == 0)
            scrsplash(x, y, ssplash0, 1)
        if (timer3s != 1)
        {
            timer3s = 1
            var p2 = instance_create_layer(x, y, "instances", objbmobenp2)
            p2.height = 72
        }
        ad = angle_difference(dir3, idir)
        dir3 -= ((min(abs(ad), 36)) * sign(ad))
        spd += (-1 * spd / 8)
    }
    else if (image_index < (image_number - image_speed))
    {
        if ((image_index % 1) == 0)
            scrsplash(x, y, ssplash0, 1)
        with (objbmobenp2)
            shoot = 1
        spd += (-1 * (spd + 4) / 2)
        if (timer3s != 2)
        {
            timer3s = 2
            scrsplash(x, y, ssplash0, 1)
        }
    }
    else
        state = 0
}
else
{
    timer3s = 0
    dir3 = idir
}
if (state == 4)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmoben1tu3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmoben1tu4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmoben1tu3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmoben1tu2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmoben1tu1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmoben1tu0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmoben1tu1
    else
        sprite_index = sbmoben1tu2
}
if (state == 5)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmoben1td3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmoben1td4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmoben1td3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmoben1td2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmoben1td1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmoben1td0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmoben1td1
    else
        sprite_index = sbmoben1td2
}
if (hit != 0 && state != 6)
{
    if (objplayer.stage == 8.14)
        hp -= 1
    with (objbmobenp1)
        instance_destroy()
    with (objbmobenp2)
        instance_destroy()
    with (objbmobenp)
        dud = true
    flash = 1
    objplayerview.shaket = 8
    dir = idir
    image_index = 0
    state = 6
}
if (state == 6)
{
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmoben1k3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmoben1k4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmoben1k3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmoben1k2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmoben1k1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmoben1k0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmoben1k1
    else
        sprite_index = sbmoben1k2
    scrmovcol((-spd), dir)
    if (image_index < 1)
    {
        image_speed = 0.2
        spd += (-1 * (spd - 2) / 8)
    }
    else if (image_index < 3)
        spd += (-1 * (spd - 4) / 4)
    else if (image_index < (image_number - 0.5))
        spd += (-1 * spd / 8)
    else
    {
        spd = 0
        if (image_speed != 0)
        {
            image_speed = 0
            resett = 0
        }
    }
    if (resett >= 0)
    {
        if (resett < 1)
            resett += (1/120)
        else if (resett < 2)
        {
            resett = 2
            flash = 1
            if (scrdist(self, objplayer) < 128)
            {
                p = instance_create_layer(objplayer.x, objplayer.y, "instances", objbmobenp)
                p.shoot = 1
                p.notrail = true
            }
        }
        else if (resett < 3)
        {
            resett += 0.16666666666666666
            repeat (1)
            {
                var stack = (resett - 2) * 10
                var rdir = irandom(360)
                var rdist = irandom(64 * stack)
                p = instance_create_layer((x + (lengthdir_x(rdist, rdir))), (y + (lengthdir_y((rdist / 2), rdir))), "instances", objbmobenp)
                p.shoot = 1
                p.notrail = true
            }
        }
        else if (flash <= 0.5)
        {
            flash = 0
            resett = -1
            stage += 1
            objplayer.boss = self
            objplayer.showbosshp = true
            hp = maxhp
            state = 3
        }
    }
    if (stage > 1)
        state = 7
}
if (state == 7)
{
    hp = 0
    image_index = 4.5
    if (dir >= 22.5 && dir < 67.5)
        sprite_index = sbmoben1k3
    else if (dir >= 67.5 && dir < 112.5)
        sprite_index = sbmoben1k4
    else if (dir >= 112.5 && dir < 157.5)
        sprite_index = sbmoben1k3
    else if (dir >= 157.5 && dir < 202.5)
        sprite_index = sbmoben1k2
    else if (dir >= 202.5 && dir < 247.5)
        sprite_index = sbmoben1k1
    else if (dir >= 247.5 && dir < 292.5)
        sprite_index = sbmoben1k0
    else if (dir >= 292.5 && dir < 337.5)
        sprite_index = sbmoben1k1
    else
        sprite_index = sbmoben1k2
    if (splat == 0)
        image_speed = 0
    else if (splat < 4.5)
        splat += 0.2
    else
        image_speed = 0
}
if (calphat >= 0)
{
    if (calphat < 1)
    {
        calphat += (1/120)
        calpha0 += 0.0020833333333333333
    }
    else if (calphat < 2)
    {
        calphat += 0.016666666666666666
        if (calpha0 != 1)
        {
            calpha0 = 1
            objplayerview.shaket = 20
        }
        calpha1 += 0.004166666666666667
    }
    else if (calphat < 3)
    {
        calphat += (1/30)
        if (calpha1 != 1)
        {
            calpha1 = 1
            objplayerview.shaket = 20
        }
        calpha2 += (1/120)
    }
    else if (calpha2 != 1)
    {
        calpha2 = 1
        objplayerview.shaket = 20
    }
}
