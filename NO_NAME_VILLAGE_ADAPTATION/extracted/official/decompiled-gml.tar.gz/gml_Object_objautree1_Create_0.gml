depth = (-y)
start = 0
watershad = 1761
shadshad = 670
wnsprite = 2216
wnwatershad = 941
wnshadshad = 408
if layer_exists("watershadows")
{
    if (!layer_exists("watershad"))
        layer_create((layer_get_depth("watershadows") - 4), "watershad")
}
else
    layer_create((layer_get_depth("shadows") + 4), "watershad")
