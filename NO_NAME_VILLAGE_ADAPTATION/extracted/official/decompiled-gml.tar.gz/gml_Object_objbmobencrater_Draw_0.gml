if (state == 1)
    draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, 0, -1, image_alpha)
