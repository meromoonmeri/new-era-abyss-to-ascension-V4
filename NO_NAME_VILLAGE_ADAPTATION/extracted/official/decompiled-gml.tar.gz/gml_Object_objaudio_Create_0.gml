if (!variable_global_exists("music"))
    global.music = 1
if (!variable_global_exists("sound"))
    global.sound = 1
music = -1
sound = -1
newroom = 1
snpause = false
bgpause = 0
bgcheck = bgpause
mpause = 0
spause = 0
mcheck = -1
mdelay = 500
mvol = 1
boss = false
delay = 1
firstmusic = 1
season = -1
if (!variable_global_exists("bgswind"))
{
    global.bgswind = ds_list_create()
    ds_list_insert(global.bgswind, 0, 198)
}
bgswind = 198
bgwindvol = 1
if (!variable_global_exists("bgstree"))
{
    global.bgstree = ds_list_create()
    ds_list_insert(global.bgstree, 0, 198)
}
bgstree = 198
bgtreevol = 1
if (!variable_global_exists("bgswater"))
{
    global.bgswater = ds_list_create()
    ds_list_insert(global.bgswater, 0, 198)
}
bgswater = 198
bgwatervol = 1
if (!variable_global_exists("bgsseason"))
{
    global.bgsseason = ds_list_create()
    ds_list_insert(global.bgsseason, 0, 198)
}
bgsseason = 198
bgseasonvol = 1
if (!variable_global_exists("bgsindoor"))
{
    global.bgsindoor = ds_list_create()
    ds_list_insert(global.bgsindoor, 0, 198)
}
bgsindoor = 198
bgindoorvol = 1
if (!variable_global_exists("bgm"))
{
    global.bgm = ds_list_create()
    ds_list_insert(global.bgm, 0, 198)
    ds_list_insert(global.bgm, 1, 198)
}
bgm = 198
bgmm = 198
bgmvol = 1
