function scrsplash1(argument0, argument1, argument2, argument3, argument4, argument5) //gml_Script_scrsplash1
{
    if (objplayerview.at <= 0.1)
    {
        var splash = instance_create_depth(argument0, argument1, ((-argument1) + 12), objsplash)
        splash.splash = argument2
        splash.sprite_index = argument2
        splash.image_index = argument3
        splash.creator = self
        splash.xscale = argument4
        splash.yscale = argument4
        splash.image_speed = argument5 * image_speed
    }
}

