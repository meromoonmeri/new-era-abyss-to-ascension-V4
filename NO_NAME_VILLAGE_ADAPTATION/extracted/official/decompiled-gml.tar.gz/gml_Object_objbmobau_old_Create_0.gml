event_inherited()
if (!instance_exists(objbmobauview))
    instance_create_layer(objplayerview.x, objplayerview.y, "instances", objbmobauview)
state = -1
deflect = true
eventt = 0
balpha = 1
dir = 270
boss = true
aggro = 0
maxhp = 30
hp = maxhp
mdir = 0
delay0 = 0
pattern = 0
dist1 = 0
timer2 = 0
splash2 = 0
splash4 = 0
grabt = 0
grabdelay = 0
undersprite = -4
timer01 = 0
timer02 = 0
timer03 = 0
