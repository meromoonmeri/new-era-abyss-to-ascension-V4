event_inherited()
image_index = 0
image_speed = 0
rmx = 3548
rmy = 1212
state = -1
pattern = -1
timere1 = 0
timer1s = 0
timer4s = 0
