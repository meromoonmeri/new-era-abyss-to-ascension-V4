function scrsoundgain(argument0, argument1, argument2, argument3) //gml_Script_scrsoundgain
{
    if (!variable_global_exists("music"))
        global.music = 1
    if (!variable_global_exists("sound"))
        global.sound = 1
    if (!audio_is_playing(argument0))
    {
        audio_play_sound(argument0, argument1, 1)
        audio_sound_gain(argument0, 0, 0)
        audio_sound_gain(argument0, (argument2 * global.sound), argument3)
    }
    else
        audio_sound_gain(argument0, (argument2 * global.sound), argument3)
}

