if (ca >= 0 || ca < 1 || alpha >= 1)
{
    gpu_set_colorwriteenable(1, 0, 0, 1)
    draw_sprite_ext(sprite_index, 0, (x + shakex1), (y + shakey1), size1, size1, 0, c_white, alpha)
    gpu_set_colorwriteenable(1, 1, 1, 1)
}
if (ca >= 1 || ca < 2 || alpha >= 1)
{
    gpu_set_colorwriteenable(0, 1, 0, 1)
    draw_sprite_ext(sprite_index, 0, (x + shakex2), (y + shakey2), size1, size1, 0, c_white, alpha)
    gpu_set_colorwriteenable(1, 1, 1, 1)
}
if (ca >= 2 || ca < 3 || alpha >= 1)
{
    gpu_set_colorwriteenable(0, 0, 1, 1)
    draw_sprite_ext(sprite_index, 0, (x + shakex3), (y + shakey3), size1, size1, 0, c_white, alpha)
    gpu_set_colorwriteenable(1, 1, 1, 1)
}
if (ca < 3)
    ca += choose(0.2, 0.5, 0.8)
else
    ca = 0
