function scrplaceitem(argument0) //gml_Script_scrplaceitem
{
    if (screquip(argument0) == 2)
    {
        if (scritemcheck(argument0) != 2)
        {
            if (global.equipitem[0][0] == 0)
            {
                global.equipitem[0][0] = argument0
                return 1;
            }
            else if (scritemcheck(argument0) != 1)
            {
                for (var k = 0; k <= 2; k++)
                {
                    for (var l = 0; l <= 3; l++)
                    {
                        if (global.invitem[l][k] == 0)
                        {
                            global.invitem[l][k] = argument0
                            return 1;
                        }
                    }
                }
            }
        }
    }
    else if (screquip(argument0) == 3)
    {
        if (scritemcheck(argument0) != 3)
        {
            if (global.equipitem[1][0] == 0)
            {
                global.equipitem[1][0] = argument0
                return 1;
            }
            else if (scritemcheck(argument0) != 1)
            {
                for (k = 0; k <= 2; k++)
                {
                    for (l = 0; l <= 3; l++)
                    {
                        if (global.invitem[l][k] == 0)
                        {
                            global.invitem[l][k] = argument0
                            return 1;
                        }
                    }
                }
            }
        }
    }
    else if (screquip(argument0) == 4)
    {
        if (scritemcheck(argument0) != 4)
        {
            if (global.equipitem[2][0] == 0)
            {
                global.equipitem[2][0] = argument0
                return 1;
            }
            else if (scritemcheck(argument0) != 1)
            {
                for (k = 0; k <= 2; k++)
                {
                    for (l = 0; l <= 3; l++)
                    {
                        if (global.invitem[l][k] == 0)
                        {
                            global.invitem[l][k] = argument0
                            return 1;
                        }
                    }
                }
            }
        }
    }
    else if (screquip(argument0) == 5)
    {
        if (scritemcheck(argument0) != 5)
        {
            if (global.equipitem[3][0] == 0)
            {
                global.equipitem[3][0] = argument0
                return 1;
            }
            else if (scritemcheck(argument0) != 1)
            {
                for (k = 0; k <= 2; k++)
                {
                    for (l = 0; l <= 3; l++)
                    {
                        if (global.invitem[l][k] == 0)
                        {
                            global.invitem[l][k] = argument0
                            return 1;
                        }
                    }
                }
            }
        }
    }
    else if (screquip(argument0) == 6)
    {
        if (scritemcheck(argument0) != 6)
        {
            if (global.equipitem[3][0] == 0)
            {
                global.equipitem[3][0] = argument0
                return 1;
            }
            else if (scritemcheck(argument0) != 1)
            {
                for (k = 0; k <= 2; k++)
                {
                    for (l = 0; l <= 3; l++)
                    {
                        if (global.invitem[l][k] == 0)
                        {
                            global.invitem[l][k] = argument0
                            return 1;
                        }
                    }
                }
            }
        }
    }
    else
    {
        for (k = 0; k <= 2; k++)
        {
            for (l = 0; l <= 3; l++)
            {
                if (global.invitem[l][k] == 0)
                {
                    global.invitem[l][k] = argument0
                    return 1;
                }
            }
        }
    }
    return 0;
}

