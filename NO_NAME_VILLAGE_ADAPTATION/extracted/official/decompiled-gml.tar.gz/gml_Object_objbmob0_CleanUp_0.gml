if part_system_exists(part_system0)
{
    part_particles_clear(part_system0)
    part_system_destroy(part_system0)
    part_type_destroy(rock0)
}
if part_system_exists(part_system1)
{
    part_particles_clear(part_system1)
    part_system_destroy(part_system1)
    part_type_destroy(rock1)
}
if part_system_exists(part_system2)
{
    part_particles_clear(part_system2)
    part_system_destroy(part_system2)
    part_type_destroy(rock2)
}
