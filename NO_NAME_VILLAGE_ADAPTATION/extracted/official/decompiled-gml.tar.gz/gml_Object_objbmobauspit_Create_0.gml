scrsound(snbmobaup0, 20, 1, 1)
image_speed = 0.2
fl = 0
dir = 0
spd = 0
vel = 20
zaccl = 0.6
z = vel
noncol = false
start = 0
col = 0
alpha = 0
shadsize = 1
if (!variable_global_exists("ptwater0"))
{
    global.ptwater0 = part_system_create()
    part_system_depth(global.ptwater0, ((-y) - z * vel - 4))
}
part_system = part_system_create()
part_system_depth(part_system, layer_get_depth("shadows"))
part_type = part_type_create()
part_step = part_type_create()
part_death = part_type_create()
part_type_sprite(part_type, 1747, 0, 0, 0)
part_type_speed(part_type, 0.8, 4, 0, 0)
part_type_direction(part_type, 50, 130, 0, 0)
part_type_gravity(part_type, 0.4, 270)
part_type_life(part_type, 10, 10)
part_type_step(part_type, -2, part_step)
part_type_death(part_type, 1, part_death)
part_type_sprite(part_step, 1747, 1, 1, 0)
part_type_life(part_step, 10, 10)
part_type_sprite(part_death, 1302, 1, 1, 0)
part_type_alpha3(part_death, 1, 0.5, 0)
part_type_life(part_death, 10, 10)
pt0 = part_type_create()
part_type_sprite(pt0, 825, 0, 0, 1)
part_type_size(pt0, 1, 1, -0.01, 0)
part_type_life(pt0, 5, 10)
pt1 = part_type_create()
part_type_death(pt0, 1, pt1)
part_type_sprite(pt1, 714, 0, 0, 1)
part_type_size(pt1, 1, 1, -0.01, 0)
part_type_gravity(pt1, 0.06, 270)
part_type_life(pt1, 10, 20)
ptsp = part_type_create()
part_type_sprite(ptsp, 2521, 1, 1, 0)
part_type_alpha3(ptsp, 1, 1, 0)
part_type_life(ptsp, 20, 20)
pte = part_type_create()
part_type_sprite(pte, 1687, 1, 1, 0)
part_type_alpha3(pte, 1, 1, 0)
part_type_life(pte, 50, 50)
