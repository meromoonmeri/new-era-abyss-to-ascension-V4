event_inherited()
