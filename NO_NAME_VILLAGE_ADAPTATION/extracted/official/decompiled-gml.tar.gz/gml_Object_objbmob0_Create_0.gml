event_inherited()
mobname = "Ground Fish"
mob = 3
start = 0
boss = true
state = 5
maxhp = 20
hp = maxhp
hpthreshold = 0
level = 0
gbp = 20
target = 100
dmg = 0.5
timer0 = 0
sound = 0
oldstate = -1
timer1 = 0
trail1 = 0
maxspd = 8
spd = 0
timer2 = 0
timer3 = 0
dist = 0
timer4 = 0
hit4 = 0
timer5 = -1
timer6 = 0
targetx = 0
targety = 0
prevx = 0
prevy = 0
part_system0 = part_system_create()
part_system_depth(part_system0, layer_get_depth("shadows"))
rock0 = part_type_create()
part_type_sprite(rock0, 2106, 0, 0, 1)
part_type_size(rock0, 0.8, 1.2, 0, 0)
part_type_life(rock0, 240, 360)
part_type_alpha3(rock0, 1, 1, 0)
part_system1 = part_system_create()
part_system_depth(part_system1, (layer_get_depth("shadows") + 4))
rock1 = part_type_create()
part_type_sprite(rock1, 1592, 0, 0, 1)
part_type_size(rock1, 0.8, 1.2, 0, 0)
part_type_life(rock1, 240, 360)
part_type_alpha3(rock1, 1, 1, 0)
part_system2 = part_system_create()
part_system_depth(part_system2, (layer_get_depth("shadows") + 8))
rock2 = part_type_create()
part_type_sprite(rock2, 274, 0, 0, 1)
part_type_size(rock2, 0.8, 1.2, 0, 0)
part_type_life(rock2, 240, 360)
part_type_alpha3(rock2, 1, 1, 0)
ptsp = part_type_create()
part_type_sprite(ptsp, 2732, 1, 1, 0)
part_type_scale(ptsp, 4.5, 4.5)
part_type_life(ptsp, 40, 40)
ptw = part_type_create()
part_type_sprite(ptw, 2764, 1, 1, 0)
part_type_alpha3(ptw, 0.5, 0.5, 0)
part_type_size(ptw, 1.1, 1.2, 0.015, 0)
part_type_life(ptw, 30, 30)
ptdt0 = part_type_create()
part_type_sprite(ptdt0, 863, 0, 0, 1)
part_type_size(ptdt0, 0.6, 1.2, 0, 0)
part_type_alpha3(ptdt0, 1, 1, 0)
part_type_life(ptdt0, 240, 360)
ptdt1 = part_type_create()
part_type_sprite(ptdt1, 2564, 0, 0, 1)
part_type_size(ptdt1, 0.6, 1.2, 0, 0)
part_type_alpha3(ptdt1, 1, 1, 0)
part_type_life(ptdt1, 240, 360)
ptdt2 = part_type_create()
part_type_sprite(ptdt2, 1353, 0, 0, 1)
part_type_size(ptdt2, 0.6, 1.2, 0, 0)
part_type_alpha3(ptdt2, 1, 1, 0)
part_type_life(ptdt2, 240, 360)
ptdtd = part_type_create()
part_type_size(ptdtd, 0.8, 1.2, 0, 0)
part_type_alpha3(ptdtd, 1, 0.8, 0)
part_type_life(ptdtd, 30, 40)
ptdte = part_type_create()
part_type_scale(ptdte, 4, 4)
part_type_alpha3(ptdte, 1, 1, 0)
part_type_life(ptdte, 50, 50)
ps = part_system_create()
part_system_depth(ps, (-y))
sptrb = 0
ptrb = part_type_create()
part_type_sprite(ptrb, 1003, 0, 0, 1)
part_type_size(ptrb, 0.3, 1, 0, 0)
part_type_speed(ptrb, 4, 12, 0, 0)
part_type_direction(ptrb, 65, 115, 0, 0)
part_type_orientation(ptrb, 0, 360, 5, 0, 1)
part_type_gravity(ptrb, 0.4, 270)
part_type_life(ptrb, 30, 30)
ptrbd = part_type_create()
part_type_sprite(ptrbd, 1724, 0, 0, 1)
part_type_size(ptrb, 0.3, 1, 0, 0)
part_type_alpha3(ptrbd, 0.3, 0.3, 0)
part_type_life(ptrbd, 60, 100)
part_type_death(ptrb, 1, ptrbd)
ptrb2 = part_type_create()
part_type_sprite(ptrb2, 2177, 0, 0, 0)
part_type_size(ptrb2, 0.9, 1.1, 0, 0)
part_type_speed(ptrb2, 4, 12, 0, 0)
part_type_direction(ptrb2, 65, 115, 0, 0)
part_type_orientation(ptrb2, 0, 360, 5, 0, 1)
part_type_gravity(ptrb2, 0.4, 270)
part_type_life(ptrb2, 30, 30)
ptrb2d = part_type_create()
part_type_sprite(ptrb2d, 92, 0, 0, 0)
part_type_alpha3(ptrb2d, 1, 1, 0)
part_type_life(ptrb2d, 60, 100)
part_type_death(ptrb2, 1, ptrb2d)
ptrb3 = part_type_create()
part_type_sprite(ptrb3, 869, 0, 0, 0)
part_type_size(ptrb3, 0.9, 1.1, 0, 0)
part_type_speed(ptrb3, 4, 12, 0, 0)
part_type_direction(ptrb3, 65, 115, 0, 0)
part_type_orientation(ptrb3, 0, 360, 5, 0, 1)
part_type_gravity(ptrb3, 0.4, 270)
part_type_life(ptrb3, 30, 30)
ptrb3d = part_type_create()
part_type_sprite(ptrb3d, 659, 0, 0, 0)
part_type_alpha3(ptrb3d, 1, 1, 0)
part_type_life(ptrb3d, 60, 100)
part_type_death(ptrb3, 1, ptrb3d)
