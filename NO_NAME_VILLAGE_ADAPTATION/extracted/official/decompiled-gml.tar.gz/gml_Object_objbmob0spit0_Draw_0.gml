draw_self()
if (z > 0)
    draw_sprite(sbmob0p0, image_index, x, (y - z))
