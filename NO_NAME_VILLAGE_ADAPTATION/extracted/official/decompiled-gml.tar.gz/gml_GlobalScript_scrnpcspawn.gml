function scrnpcspawn(argument0, argument1, argument2) //gml_Script_scrnpcspawn
{
    if (!instance_exists(argument2))
        instance_create_layer(argument0, argument1, "instances", argument2)
    else
    {
        argument2.x = argument0
        argument2.y = argument1
    }
}

