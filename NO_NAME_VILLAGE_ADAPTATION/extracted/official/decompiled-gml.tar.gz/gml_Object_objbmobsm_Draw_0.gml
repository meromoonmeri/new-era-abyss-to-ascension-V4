if (shad != -4)
    draw_sprite(shad, 0, x, y)
if (ford == 1)
{
    if (facing == 1)
        draw_sprite_part_ext(sprite_index, image_index, 0, 0, sprite_width, (sprite_yoffset - 12), (x - sprite_xoffset), (y - sprite_yoffset + 12), 4, 4, c_white, alpha)
    else
        draw_sprite_part_ext(sprite_index, image_index, 0, 0, sprite_width, (sprite_yoffset - 12), (x - sprite_xoffset + sprite_width * 4), (y - sprite_yoffset + 12), -4, 4, c_white, alpha)
}
else
    draw_sprite_ext(sprite_index, image_index, x, y, (facing * 4), 4, 0, c_white, alpha)
if (flash > 0)
{
    shader_set(shflash)
    draw_sprite_ext(sprite_index, image_index, x, (y + ford * 12), (facing * 4), 4, 0, c_white, flash)
    shader_reset()
}
