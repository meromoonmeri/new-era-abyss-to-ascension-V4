fl = 0
z = 0
vel = 8
ps = part_system_create()
