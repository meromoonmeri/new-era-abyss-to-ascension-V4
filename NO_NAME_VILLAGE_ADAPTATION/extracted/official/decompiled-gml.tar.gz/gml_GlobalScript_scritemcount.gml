function scritemcount(argument0) //gml_Script_scritemcount
{
    if (scritemcheck(argument0) == 1)
    {
        for (var k = 0; k <= 3; k++)
        {
            var l = 0
            while (l <= 2)
            {
                if (global.invitem[k][l] == argument0)
                {
                    global.invitem[k][l] = 0
                    item += 1
                    break
                }
                else
                {
                    l++
                    continue
                }
            }
        }
    }
}

