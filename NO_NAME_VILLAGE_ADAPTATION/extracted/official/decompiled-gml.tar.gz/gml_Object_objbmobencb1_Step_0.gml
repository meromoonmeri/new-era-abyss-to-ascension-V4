depth = layer_get_depth("invisible")
if (cancel == 1)
{
    part_system_clear(ps)
    part_system_clear(ps1)
    part_system_depth(ps, (-y))
    var rdir = irandom(360)
    z = random_range(20, 128)
    repeat (2)
    {
        part_type_scale(ptsp, 8, 25)
        part_type_size(ptsp, 1, 1, -0.1, 0)
        part_type_orientation(ptsp, rdir, rdir, 0, 0, 0)
        part_particles_create(ps, x, (y - z), ptsp, 1)
        rdir += 180
    }
    cancel = 2
    destruct = 1
    return;
}
if (type == "cb1")
{
    if (cancel > 0 && state < 2)
    {
        cancel = -1
        state = 0
        timer = 1
    }
    if (state == 0)
    {
        if (timer < 1)
        {
            timer += (1 / ct)
            var s = timer * 20
            var dec = (-s) / 3
            part_type_speed(ptc, s, s, dec, 0)
            part_system_depth(ps, (-y))
            part_particles_create(ps, x, (y - z), ptc, 1)
            part_type_scale(ptsp, 5, (8 + timer * 12))
            part_type_size(ptsp, 0.6, 1.2, (-((0.1 + timer * 0.1))), 0)
            part_system_depth(ps1, ((-y) + 1))
            part_particles_create(ps1, x, (y - z), ptsp, 1)
            if (!audio_is_playing(snbmobenmetal0))
                scrsound(snbmobenmetal0, 50, 1, 0.9)
            else if (random(1) < (1/3))
                scrsound(snbmobenmetal0, 50, 1, (0.9 + timer * 0.1))
        }
        else if (timer < 2)
        {
            timer += 0.1
            rdir = irandom(360)
            if (timer <= 1.1)
            {
                repeat (2)
                {
                    part_type_scale(ptsp, 12, 25)
                    part_type_size(ptsp, 1, 1, -0.1, 0)
                    part_type_orientation(ptsp, rdir, rdir, 0, 0, 0)
                    part_particles_create(ps1, x, (y - z), ptsp, 1)
                    rdir += 180
                }
            }
        }
        else
        {
            part_system_clear(ps)
            if (target != noone)
            {
                targx = target.x + (irandom_range(-128, 128))
                targy = target.y + (irandom_range(-128, 128))
            }
            state = 1
            timer = -1
            if (cancel != 0)
                instance_destroy()
        }
    }
    if (state == 1)
    {
        if (timer < 0)
        {
            if (objbmoben.cbt == 0)
            {
                objplayerview.shaket = 12
                scrsound(snbmobenshoot0, 50, 1, 1)
            }
            timer = 0
        }
        else if (timer < 1)
        {
            timer += 0.1
            if (!instance_exists(self))
                return;
            var vptdir = (round((scrdir(self, objplayer)) / 45)) * 45
            if (vptdir == 360)
                vptdir = 0
            var vptface = -1
            if (vptdir > 90 && vptdir <= 270)
                vptface = 1
            var vptspr = 326
            var vptxscl = 3
            if (vptdir == 90 || vptdir == 270)
            {
                vptspr = 2637
                vptxscl = 4
            }
            else if (vptdir == 0 || vptdir == 180)
            {
                vptspr = 2328
                vptxscl = 2
            }
            else if (vptdir == 45 || vptdir == 135)
                vptface *= -1
            part_type_sprite(ptsh, vptspr, 1, 1, 0)
            part_type_scale(ptsh, (vptxscl * vptface), 4)
            part_type_speed(ptsh, 0, 0, 0.6, 0)
            part_type_direction(ptsh, (vptdir - 180), (vptdir - 180), 0, 0)
            part_particles_create(ps, x, (y - z), ptsh, 1)
            if (timer >= 0.7)
            {
                repeat (3)
                {
                    vptdir = 180 + (round((scrdir(self, objplayer)) / 45)) * 45
                    if (vptdir >= 360)
                        vptdir -= 360
                    var vptspd = 0
                    if (vptdir == 270)
                    {
                        vptdir = 90
                        vptspd = 12
                    }
                    else if (vptdir == 225)
                    {
                        vptdir = 135
                        vptspd = 16
                    }
                    else if (vptdir == 315)
                    {
                        vptdir = 45
                        vptspd = 16
                    }
                    else if (vptdir == 180 || vptdir == 0)
                        vptspd = 20
                    else if (vptdir == 135 || vptdir == 45)
                        vptspd = 24
                    else
                        vptspd = 28
                    vptdir = vptdir * 0.5 + 45
                    var r = random_range(-15, 15)
                    vptdir += r
                    var diff = 1 - abs(r) / 15 / 4
                    vptspd *= diff
                    part_type_speed(ptf0, vptspd, (vptspd + random(4)), (-0.2 * diff), 0)
                    part_type_direction(ptf0, vptdir, vptdir, 0, 0)
                    part_type_orientation(ptf0, 0, 360, ((random_range(5, 15)) * (choose(-1, 1))), 0, 1)
                    part_particles_create(ps, (x + (irandom_range(-30, 30))), (y - z + (irandom_range(-30, 30))), ptf0, 1)
                }
            }
        }
        else
        {
            state = 2
            timer = 0
        }
    }
    if (state == 2)
    {
        if (timer < 1)
            timer += (1/3)
        else if (timer < 2)
        {
            timer = 2
            var vpttdist = point_distance(x, (y - z), targx, targy)
            var vpttdir = point_direction(x, (y - z), targx, targy)
            var bellcol = 0
            var i = 0
            while (i < vpttdist)
            {
                var j = i / vpttdist
                var vptsize = 1 + (clamp(((exp(1.6 * (j - 0.8))) * (sin(9.2 * (j - 0.8) - 5.8)) + (exp(4.5 * (j - 1.3))) * (sin(23 * (j - 1.3) - 1.5))), 0, 1)) * 2
                part_type_size(ptt, vptsize, vptsize, -0.02, 0)
                var vx = x + (lengthdir_x(i, vpttdir))
                var vy = y + (lengthdir_y(i, vpttdir))
                part_particles_create(ps, vx, (vy - z), ptt, 1)
                if ((i % 12) == 0)
                {
                    var vpttsdist = point_distance(x, y, targx, targy)
                    var vpttsdir = point_direction(x, y, targx, targy)
                    var vxs = x + (lengthdir_x((j * vpttsdist), vpttsdir))
                    var vys = y + (lengthdir_y((j * vpttsdist), vpttsdir))
                    var vz = 1 - (clamp(((abs(vys - (vy - z))) / 256), 0, 1))
                    part_type_size(ptts, (vz * 0.4), (vz * 0.4), -0.001, 0)
                    part_particles_create(pss, vxs, vys, ptts, 1)
                }
                if (point_distance(vx, vy, objplayer.x, objplayer.y) < 32 && z < 50)
                {
                    targx = vx
                    targy = vy
                    break
                }
                else if (position_meeting(vx, vy, objrm53) && z < 50)
                {
                    targx = vx
                    targy = vy
                    bellcol = 1
                    with (objrm53)
                        hit = 1
                    break
                }
                else
                {
                    i += 4
                    continue
                }
            }
            if (bellcol == 0)
                spd = clamp((vpttdist / 5), 60, 999)
            else
                spd = 0
            dir = point_direction(x, y, targx, targy)
        }
        else
        {
            objplayerview.shaket = 18
            x = targx
            y = targy
            scrsound(snbmobenshoot1, 50, 1, 1)
            part_system_depth(ps, (-y))
            part_system_depth(ps1, ((-y) + 1))
            state = 3
            timer = 0
        }
    }
    if (state == 3)
    {
        if (timer < 1)
        {
            timer += 0.05
            if (((timer * 20) % 2) == 0)
            {
                var vptbsize = 1 - timer
                objplayerview.shaket = 8
                mask_index = smobau3shad
                image_xscale = vptbsize
                image_yscale = vptbsize
                scrshakefx1(1, 1, 10, x, y)
                if (place_meeting(x, y, objplayer) && objplayer.iframe <= 0)
                    scrplayerkd(scrdir(objplayer, objbmoben), 1.5, 16)
                part_type_size(ptb, vptbsize, vptbsize, 0.005, 0)
                part_particles_create(ps, x, y, ptb, 1)
                vptbsize = clamp((vptbsize + 0.3), 0.5, 1)
                part_type_size(ptw, vptbsize, vptbsize, 0.012, 0)
                part_particles_create(ps1, x, y, ptw, 1)
                part_particles_create(ps, x, y, ptf0, (5 * vptbsize))
                scrpttrail1(x, y, 331, 2372, 139, 300, vptbsize, 1)
                x += lengthdir_x(spd, dir)
                y += lengthdir_y(spd, dir)
                spd *= 0.6
                if (spd < 1)
                    timer = 1
            }
        }
        else
        {
            state = 4
            destruct = 1
        }
    }
}
if (type == "delay")
{
    if (state == 0)
    {
        z = 192
        if (timer < 1)
        {
            if (((timer * 10) % 2) == 0)
            {
                s = timer
                dec = (-s) / 3
                part_type_speed(ptc, s, s, dec, 0)
                part_particles_create(ps, x, (y - z), ptc, 1)
                part_type_scale(ptsp, 4, (4 + timer * 4))
                part_type_size(ptsp, 0.6, 1.2, (-((0.1 + timer * 0.1))), 0)
                part_particles_create(ps1, x, (y - z), ptsp, 1)
            }
            if (target != noone)
            {
                targx = target.x + (irandom_range(-128, 128))
                targy = target.y + (irandom_range(-128, 128))
            }
            timer += 0.1
        }
        else if (timer < 2)
            timer += 0.1
        else if (timer < 3)
        {
            if (timer <= 2)
                part_system_clear(ps)
            var pd = point_direction(x, (y - z), targx, targy)
            var vdir = pd
            if (vdir < 180)
                vdir = 360 - vdir
            var vv = (clamp(((y - targy) / 384), -0.5, 1)) * 2
            var vh = clamp(((vdir - 270) * 0.66), -60, 60)
            part_type_scale(ptsh, 4, (2 + vv))
            part_type_speed(ptsh, (4 * (vv / 2 + 1)), (4 * (vv / 2 + 1)), 0.01, 0)
            part_type_direction(ptsh, (pd + 180), (pd + 180), 0, 0)
            part_type_orientation(ptsh, vh, vh, 0, 0, 0)
            part_particles_create(ps1, x, (y - z), ptsh, 1)
            timer += 0.5
        }
        else
        {
            state = 1
            timer = 0
        }
    }
    if (state == 1)
    {
        if (timer < 1)
        {
            if (timer < (1/3))
            {
                scrsound(snbmobenshoot2, 20, 1, random_range(0.8, 1))
                scrsound(snbmobenssplash0, 20, 1, random_range(0.8, 1))
            }
            timer += (1/3)
        }
        else if (timer < 2)
        {
            timer = 2
            vpttdist = point_distance(x, (y - z), targx, targy)
            vpttdir = point_direction(x, (y - z), targx, targy)
            for (i = 0; i < vpttdist; i += 4)
            {
                j = i / vpttdist
                vptsize = 1 + (clamp((0.5 * j * (1 - (sin(-120.63715789784806 * (power(j, 0.14285714285714285)))))), 0, 1))
                part_type_size(ptt, vptsize, vptsize, -0.02, 0)
                part_particles_create(ps, (x + (lengthdir_x(i, vpttdir))), (y - z + (lengthdir_y(i, vpttdir))), ptt, 1)
            }
            spd = clamp((vpttdist / 5), 60, 999)
            dir = point_direction(x, y, targx, targy)
        }
        else
        {
            state = 2
            timer = 0
            ct = 0
            objplayerview.shaket = 18
            x = targx
            y = targy
            z = 0
            part_system_depth(ps, (-y))
            part_system_depth(ps1, ((-y) + 1))
            part_particles_create(ps, x, y, pts0, 1)
            scrsplash(x, y, smobsm2splash, 0)
        }
    }
    if (state == 2)
    {
        if (timer < 1)
        {
            if (timer == 0)
            {
                var vldir = dir
                if (vldir > 180)
                    vldir = 360 - vldir
                vldir = (-((vldir - 90)))
                part_type_orientation(ptl, vldir, vldir, 0, 0, 0)
                part_particles_create(ps, x, y, ptl, 1)
                if (dud == true)
                    instance_destroy()
            }
            ct = 0
            timer += (1/30)
        }
        else if (timer < 2)
        {
            var t = timer - 1
            if (t < ct)
                timer += (1/15)
            else
            {
                ct += (1/3)
                var sori = 0
                var lastx = 0
                var lasty = 0
                repeat (5)
                {
                    var rhdir = irandom(360)
                    var rdist = random_range((0 + ct * 14), (8 + ct * 14))
                    var rx = x + (lengthdir_x(rdist, rhdir))
                    var ry = y + (lengthdir_y((rdist / 2), rhdir))
                    var rori = clamp(((x - rx) * 2), -90, 90)
                    sori = rori
                    part_type_scale(ptl, (1 + ct / 4), (1 + ct / 4))
                    part_type_orientation(ptl, rori, rori, 0, 0, 0)
                    part_particles_create(ps, rx, ry, ptl, 1)
                    lastx = rx
                    lasty = ry
                }
                sori = sori * 1.8
                part_type_scale(ptsp, 6, (4 + ct * 12))
                part_type_size(ptsp, 1, 1, (-((0.1 + ct * 0.1))), 0)
                part_type_orientation(ptsp, sori, sori, 0, 0, 0)
                part_particles_create(ps1, x, (y - z), ptsp, 1)
                scrsplash(lastx, lasty, ssplash0, 0)
                if (!audio_is_playing(snbmobenmetal0))
                    scrsound(snbmobenmetal0, 50, 1, 0.9)
                else if (random(1) < (1/3))
                    scrsound(snbmobenmetal0, 50, 1, (0.9 + t * 0.1))
            }
        }
        else if (timer < 3)
        {
            timer += 0.05
            ct += 0.016666666666666666
        }
        else
        {
            state = 3
            timer = 0
            part_system_clear(ps)
            part_system_clear(ps1)
        }
    }
    if (state == 3)
    {
        objplayerview.shaket = 8
        mask_index = smobau3shad
        scrshakefx1(1, 1, 10, x, y)
        scrsound(snmobau32, 50, 0.6, 1)
        if (place_meeting(x, y, objplayer) && objplayer.iframe <= 0)
        {
            scrplayerkd(scrdir(objplayer, self), 1, 16)
            scrshakefx1(1, 1, 10, x, y)
        }
        part_system_depth(ps16, ((-y) - 16))
        vptbsize = 1 - timer
        part_type_size(ptb, vptbsize, vptbsize, 0.005, 0)
        part_particles_create(ps16, x, y, ptb, 1)
        vptbsize = clamp((vptbsize + 0.3), 0.5, 1)
        part_type_size(ptw, vptbsize, vptbsize, 0.012, 0)
        part_particles_create(ps1, x, y, ptw, 1)
        part_type_speed(ptf0, 24, 32, 0, 0)
        part_particles_create(ps, x, y, ptf0, (5 * vptbsize))
        scrpttrail1(x, y, 331, 2372, 139, 300, vptbsize, 1)
        state = 4
        destruct = 1
    }
}
if (type == "attach")
{
    depth = (-y) - 16
    if (state == 0)
    {
        x = objplayer.x
        y = objplayer.y
        if (ct == 60)
            ct = 0
        var b = 0
        if (z > 0 || zvel > 0)
        {
            z = clamp((z + zvel), 0, 999)
            zvel -= 0.4
        }
        else if (abs(zvel) > 5)
        {
            zvel = abs(zvel) * 0.5
            b = 1
        }
        else
        {
            z = 0
            zvel = 0
        }
        part_system_depth(ps, ((-y) - 16))
        part_system_depth(ps1, ((-y) - 16 + 1))
        if (timer < 1)
        {
            if (timer == 0)
            {
                timer = 0.1
                var d = round((scrdir(objbmoben, self)) / 45)
                if (d == 1 || d == 3 || d == 5 || d == 7)
                    part_type_sprite(ptsh, 2754, 0, 0, 0)
                else if (d == 2 || d == 6)
                    part_type_sprite(ptsh, 2376, 0, 0, 0)
                else
                    part_type_sprite(ptsh, 2699, 0, 0, 0)
                part_type_scale(ptsh, 4, 4)
                part_type_size(ptsh, 0.01, 0.01, 0.03, 0.1)
                part_type_colour1(ptsh, 16777215)
                part_type_alpha3(ptsh, 0.6, 1, 0)
                part_particles_create(ps, x, y, ptsh, 1)
            }
            if (b == 1)
            {
                timer = 1
                ct = 0
            }
        }
        else if (timer < 2)
        {
            t = timer - 1
            if (t > ct)
            {
                ct += (1 / (3 + timer * 6))
                objplayerview.shaket = 4
                repeat (2)
                {
                    part_type_scale(ptsp, 5, (8 + t * 12))
                    part_type_size(ptsp, 0.6, 1.2, (-((0.05 + t * 0.1))), 0)
                    if (random(1) < 0.33)
                        part_type_size(ptsp, 1.2, 1.6, (-((0.2 + t * 0.4))), 0)
                    part_type_orientation(ptsp, -90, 90, 0, 0, 0)
                    part_particles_create(ps1, x, (y - z), ptsp, 1)
                }
                if (!audio_is_playing(snbmobenmetal0))
                    scrsound(snbmobenmetal0, 50, 1, 0.9)
                else if (random(1) < (1/3))
                    scrsound(snbmobenmetal0, 50, 1, (0.9 + t * 0.1))
            }
            timer += 0.025
        }
        else if (timer < 3)
            timer += 0.1
        else
        {
            state = 1
            timer = 0
        }
    }
    if (state == 1)
    {
        if (timer < 1)
        {
            timer = 1
            vptbsize = timer
            part_type_size(ptb, vptbsize, vptbsize, 0.005, 0)
            part_particles_create(ps, x, y, ptb, 1)
            vptbsize = clamp((vptbsize + 0.3), 0.5, 1)
            part_type_size(ptw, vptbsize, vptbsize, 0.012, 0)
            part_particles_create(ps1, x, y, ptw, 1)
            part_particles_create(ps, x, y, ptf0, (5 * vptbsize))
            scrpttrail1(x, y, 331, 2372, 139, 300, vptbsize, 1)
            scrshakefx1(1, 1, 10, x, y)
            if place_meeting(x, y, objplayer)
            {
                scrplayerkd((objbmoben.dir + 180), 1.5, 16)
                scrshakefx1(1, 1, 10, x, y)
            }
            scrsound(snmobau32, 50, 0.8, 1)
        }
        else
        {
            state = 2
            destruct = 1
        }
    }
}
if (type == "jump")
{
    depth = (-y) - 16
    part_system_depth(ps, depth)
    part_system_depth(ps1, (depth + 1))
    if (state == 0)
    {
        if (timer < 1)
        {
            if (ct < 1)
                ct += 0.02
            else
                timer = 1
            part_type_scale(ptsp, 5, (8 + timer * 12))
            part_type_size(ptsp, 0.6, 1.2, (-((0.1 + timer * 0.1))), 0)
            part_particles_create(ps1, x, (y - z), ptsp, 1)
        }
        else if (timer < 2)
        {
            timer += 0.1
            rdir = irandom(360)
            if (timer <= 1.1)
            {
                repeat (2)
                {
                    part_type_scale(ptsp, 12, 25)
                    part_type_size(ptsp, 1, 1, -0.1, 0)
                    part_type_orientation(ptsp, rdir, rdir, 0, 0, 0)
                    part_particles_create(ps1, x, (y - z), ptsp, 1)
                    rdir += 180
                }
            }
        }
        else
        {
            part_system_clear(ps)
            targx = x
            targy = y
            objplayerview.shaket = 12
            state = 1
            timer = 0
        }
    }
    if (state == 1)
    {
        if (timer < 1)
        {
            timer += 0.1
            part_type_scale(ptsh, 4, 2.5)
            part_type_speed(ptsh, 0, 0, 0.6, 0)
            part_type_direction(ptsh, 90, 90, 0, 0)
            part_particles_create(ps1, x, (y - z), ptsh, 1)
            if (timer >= 0.7)
            {
                repeat (3)
                {
                    part_type_speed(ptf0, 24, 32, 0, 0)
                    part_type_direction(ptf0, 20, 140, 0, 0)
                    part_type_orientation(ptf0, 0, 360, ((random_range(5, 15)) * (choose(-1, 1))), 0, 1)
                    part_particles_create(ps, (x + (irandom_range(-30, 30))), (y - z + (irandom_range(-30, 30))), ptf0, 1)
                }
            }
        }
        else
        {
            state = 2
            timer = 0
        }
    }
    if (state == 2)
    {
        if (timer < 1)
            timer += (1/3)
        else if (timer < 2)
        {
            timer = 2
            vpttdist = point_distance(x, (y - z), targx, targy)
            vpttdir = point_direction(x, (y - z), targx, targy)
            for (i = 0; i < vpttdist; i += 4)
            {
                j = i / vpttdist
                vptsize = 1 + (clamp(((exp(1.6 * (j - 0.8))) * (sin(9.2 * (j - 0.8) - 5.8)) + (exp(4.5 * (j - 1.3))) * (sin(23 * (j - 1.3) - 1.5))), 0, 1)) * 2
                part_type_size(ptt, vptsize, vptsize, -0.02, 0)
                part_particles_create(ps, (x + (lengthdir_x(i, vpttdir))), (y - z + (lengthdir_y(i, vpttdir))), ptt, 1)
            }
            spd = 0
            dir = point_direction(x, y, targx, targy)
        }
        else
        {
            objplayerview.shaket = 18
            x = targx
            y = targy
            state = 3
            timer = 0
        }
    }
    if (state == 3)
    {
        mask_index = smobau3shad
        if (timer < 1)
        {
            timer += 0.025
            if (((timer * 20) % 2) == 0)
            {
                var n = 1
                n = ceil(timer * 10)
                var rp = 0
                repeat n
                {
                    r = random_range(0.8, 1.2)
                    var rpx = x + (lengthdir_x((spd * r), (360 / n * rp)))
                    var rpy = y + (lengthdir_y((spd * r / 2), (360 / n * rp)))
                    if ((!(position_meeting(rpx, rpy, objrm53))) && (!(position_meeting(rpx, rpy, objtreecol))))
                    {
                        vptbsize = 1 - timer
                        objplayerview.shaket = 8
                        image_xscale = vptbsize
                        image_yscale = vptbsize
                        scrshakefx1(1, 1, 10, rpx, rpy)
                        if (place_meeting(rpx, rpy, objplayer) && objplayer.iframe <= 0)
                        {
                            scrplayerkd(scrdir(self, objplayer), 1, 16)
                            scrshakefx1(1, 1, 10, rpx, rpy)
                        }
                        part_type_size(ptb, vptbsize, vptbsize, 0.005, 0)
                        part_particles_create(ps, rpx, rpy, ptb, 1)
                        vptbsize = clamp((vptbsize + 0.3), 0.5, 1)
                        part_type_size(ptw, vptbsize, vptbsize, 0.012, 0)
                        part_particles_create(ps1, rpx, rpy, ptw, 1)
                        if (random(1) < 0.2)
                            part_particles_create(ps, rpx, rpy, ptf0, (5 * vptbsize))
                        scrpttrail1(rpx, rpy, 331, 2372, 139, 300, vptbsize, 1)
                    }
                    rp += 1
                }
                spd += (128 * (1 - timer))
            }
        }
        else
        {
            state = 4
            destruct = 1
        }
    }
}
if (type == "throw")
{
    depth = (-y) - 16
    part_system_depth(ps, depth)
    part_system_depth(ps1, (depth + 1))
    if (state == 0)
    {
        if (timer < 1)
        {
            if (ct < 0.5)
                ct += ((0.6 - ct) / 20)
            else
                timer = 1
            part_type_scale(ptsp, 5, (8 + timer * 12))
            part_type_size(ptsp, 0.6, 1.2, (-((0.1 + timer * 0.1))), 0)
            part_particles_create(ps1, x, (y - z), ptsp, 1)
        }
        else if (timer < 2)
        {
            timer += 1
            rdir = irandom(360)
            repeat (2)
            {
                part_type_scale(ptsp, 12, 25)
                part_type_size(ptsp, 1, 1, -0.1, 0)
                part_type_orientation(ptsp, rdir, rdir, 0, 0, 0)
                part_particles_create(ps1, x, (y - z), ptsp, 1)
                rdir += 180
            }
        }
        else
        {
            part_system_clear(ps)
            objplayerview.shaket = 12
            state = 1
            timer = 0
        }
        var zheight = 320
        if (ct < 0.466)
            z = (clamp((1.3 * (power((1 - (power((-1.8 * ct + 1), 3.5))), 0.25)) - 0.3), 0, 1)) * zheight
        else
            z = (clamp((1.5 * (power((1 - (power((1.7 * ct - 0.7), 2.7))), 0.25)) - 0.5), 0, 1)) * zheight
        var zdist = point_distance(prevx, prevy, targx, targy)
        vdir = point_direction(prevx, prevy, targx, targy)
        x = prevx + (lengthdir_x((zdist * ct), vdir))
        y = prevy + (lengthdir_y((zdist * ct), vdir))
    }
    if (state == 1)
    {
        if (timer < 1)
        {
            if (timer < 0.2)
            {
                scrsound(snbmobenshoot0, 50, 1, 1)
                audio_stop_sound(snbmobenthrow2)
            }
            timer += 0.2
            part_type_scale(ptsh, 4, 2.5)
            part_type_speed(ptsh, 0, 0, 0.6, 0)
            part_type_direction(ptsh, 90, 90, 0, 0)
            part_particles_create(ps1, x, (y - z), ptsh, 1)
            if (timer >= 0.7)
            {
                repeat (3)
                {
                    part_type_speed(ptf0, 24, 32, 0, 0)
                    part_type_direction(ptf0, 20, 140, 0, 0)
                    part_type_orientation(ptf0, 0, 360, ((random_range(5, 15)) * (choose(-1, 1))), 0, 1)
                    part_particles_create(ps, (x + (irandom_range(-30, 30))), (y - z + (irandom_range(-30, 30))), ptf0, 1)
                }
            }
        }
        else
        {
            state = 2
            timer = 0
        }
    }
    if (state == 2)
    {
        if (timer < 1)
        {
            repeat (3)
            {
                t = timer * 45
                var rn = floor((pi * (power(100, t))) % 100)
                var tdir = 360 * (rn / 100)
                var tdist = 64 * (t / 6)
                var tx = targx + (lengthdir_x(tdist, tdir))
                var ty = targy + (lengthdir_y((tdist / 2), tdir))
                if ((!(place_meeting(tx, ty, objrm53))) && (!(place_meeting(tx, ty, objtreecol))))
                {
                    objplayerview.shaket = 8
                    vpttdist = point_distance(x, (y - z), tx, ty)
                    vpttdir = point_direction(x, (y - z), tx, ty)
                    for (i = 0; i < vpttdist; i += 4)
                    {
                        j = i / vpttdist
                        vptsize = 1 + (clamp(((exp(1.6 * (j - 0.8))) * (sin(9.2 * (j - 0.8) - 5.8)) + (exp(4.5 * (j - 1.3))) * (sin(23 * (j - 1.3) - 1.5))), 0, 1)) * 2
                        part_type_size(ptt, (vptsize / 2), (vptsize / 2), -0.02, 0)
                        part_type_life(ptt, 20, 20)
                        var tpx = x + (lengthdir_x(i, vpttdir))
                        var tpy = y - z + (lengthdir_y(i, vpttdir))
                        part_particles_create(ps, tpx, tpy, ptt, 1)
                        scrshakefx1(1, 1, 10, tpx, tpy)
                        if (position_meeting(tpx, tpy, objplayer) && objplayer.iframe <= 0)
                            scrplayerkd(scrdir(self, objplayer), 1, 16)
                    }
                    part_particles_create(ps, tx, ty, pts0d, 1)
                    part_particles_create(ps, tx, ty, ptl, 1)
                }
                if (random(1) < 0.2)
                    scrsound(snbmobenshoot2, 20, 1, random_range(0.8, 1))
                if (random(1) < 0.2)
                    scrsound(snbmobenssplash0, 20, 1, random_range(0.8, 1))
                timer += 0.016666666666666666
            }
        }
        else
        {
            state = 3
            destruct = 1
        }
    }
}
if (type == "final")
{
    if (state == 0)
    {
        if (timer < 1)
        {
            if (timer == 0)
            {
                vldir = dir
                if (vldir > 180)
                    vldir = 360 - vldir
                vldir = (-((vldir - 90)))
                part_type_orientation(ptl, vldir, vldir, 0, 0, 0)
                part_particles_create(ps, x, y, ptl, 1)
                if (dud == true)
                    instance_destroy()
            }
            ct = 0
            timer += (1/30)
        }
        else if (timer < 2)
        {
            t = timer - 1
            if (t < ct)
                timer += (1/15)
            else
            {
                ct += (1/3)
                sori = 0
                lastx = 0
                lasty = 0
                repeat (5)
                {
                    rhdir = irandom(360)
                    rdist = random_range((0 + ct * 14), (8 + ct * 14))
                    rx = x + (lengthdir_x(rdist, rhdir))
                    ry = y + (lengthdir_y((rdist / 2), rhdir))
                    rori = clamp(((x - rx) * 2), -90, 90)
                    sori = rori
                    part_type_scale(ptl, (1 + ct / 4), (1 + ct / 4))
                    part_type_orientation(ptl, rori, rori, 0, 0, 0)
                    part_particles_create(ps, rx, ry, ptl, 1)
                    lastx = rx
                    lasty = ry
                }
                sori = sori * 1.8
                part_type_scale(ptsp, 6, (4 + ct * 12))
                part_type_size(ptsp, 1, 1, (-((0.1 + ct * 0.1))), 0)
                part_type_orientation(ptsp, sori, sori, 0, 0, 0)
                part_particles_create(ps1, x, (y - z), ptsp, 1)
                scrsplash(lastx, lasty, ssplash0, 0)
                if (!audio_is_playing(snbmobenmetal0))
                    scrsound(snbmobenmetal0, 50, 1, 0.9)
                else if (random(1) < 0.125)
                    scrsound(snbmobenmetal0, 50, 1, (0.9 + timer * 0.1))
            }
        }
        else if (timer < 3)
        {
            timer += 0.05
            ct += 0.016666666666666666
        }
        else
        {
            state = 1
            timer = 0
        }
    }
    if (state == 1)
    {
        if (timer < 1)
        {
            if (timer == 0)
                scrsound(snbmobenshoot2, 50, random_range(0.4, 0.8), random_range(0.9, 1.2))
            timer += (1/3)
            targx = objbmoben.x
            targy = objbmoben.y
            targz = 320
            part_system_depth(ps, (-targy))
        }
        else if (timer < 2)
        {
            timer = 2
            vpttdist = point_distance(x, (y - z), targx, (targy - targz))
            vpttdir = point_direction(x, (y - z), targx, (targy - targz))
            for (i = 0; i < vpttdist; i += 4)
            {
                j = i / vpttdist
                vptsize = 1 + (clamp((0.5 * j * (1 - (sin(-120.63715789784806 * (power(j, 0.14285714285714285)))))), 0, 1))
                part_type_size(ptt, vptsize, vptsize, -0.02, 0)
                part_particles_create(ps, (x + (lengthdir_x(i, vpttdir))), (y - z + (lengthdir_y(i, vpttdir))), ptt, 1)
            }
        }
        else
        {
            scrsplash(x, y, smobsm2splash, 0)
            state = 2
            destruct = 1
        }
    }
}
if (type == "combine")
{
    depth = (-y)
    if (state == 0)
    {
        if (timer < 1)
        {
            if (ct == 100)
                scrsound(snbmobencharge2, 50, 1, 1)
            if (ct < 1)
                ct += (1/120)
            else
                timer = 1
            part_type_scale(ptsp, 5, (8 + timer * 12))
            part_type_size(ptsp, 0.6, 1.2, (-((0.1 + timer * 0.1))), 0)
            part_particles_create(ps1, x, (y - z), ptsp, 1)
        }
        else if (timer < 2)
        {
            timer += 0.1
            rdir = irandom(360)
            if (timer <= 1.1)
            {
                repeat (2)
                {
                    part_type_scale(ptsp, 12, 25)
                    part_type_size(ptsp, 1, 1, -0.1, 0)
                    part_type_orientation(ptsp, rdir, rdir, 0, 0, 0)
                    part_particles_create(ps1, x, (y - z), ptsp, 1)
                    rdir += 180
                }
            }
        }
        else
        {
            part_system_clear(ps)
            state = 1
            timer = 0
        }
    }
    if (state == 1)
    {
        if (timer < 1)
        {
            z -= zvel
            zvel += 0.05
            with (objbmoben)
            {
                if (state != 13.1)
                {
                    state = 13.1
                    image_index = 1
                }
                else if (image_index >= 3)
                    other.timer += 1
            }
        }
        else if (timer < 2)
        {
            if ((z - zvel) > 0)
            {
                z -= zvel
                zvel += 10
                with (objbmobencrater)
                {
                    var vt = other.z / 320
                    image_alpha = max(image_alpha, (1 - vt))
                }
            }
            else
            {
                state = 2
                timer = 0
                part_system_depth(ps, (-y))
            }
        }
    }
    if (state == 2)
    {
        if (timer < 1)
        {
            if (timer == 0)
                scrsound(snbmobenfinal0, 50, 1, 1)
            timer += 0.025
            if (timer > 0.125)
                ct += (ct / 2)
            with (objplayer)
                blind = other.timer
            if (((timer * 40) % 2) == 0)
            {
                n = 1
                n = ceil(timer * 10)
                rp = 0
                repeat n
                {
                    r = random_range(0.8, 1.2)
                    var rd = random_range(-5, 5)
                    rpx = x + (lengthdir_x((spd * r), (360 / n * rp + rd)))
                    rpy = y + (lengthdir_y((spd * r / 2), (360 / n * rp + rd)))
                    if (!(collision_line(x, y, rpx, rpy, objrm53, true, false)))
                    {
                        vptbsize = 1 - timer / 2
                        objplayerview.shaket = 8
                        image_xscale = vptbsize
                        image_yscale = vptbsize
                        if (place_meeting(rpx, rpy, objplayer) && objplayer.iframe <= 0)
                        {
                            scrplayerkd(scrdir(self, objplayer), 1, 16)
                            scrshakefx1(1, 1, 10, rpx, rpy)
                        }
                        part_type_size(ptb, vptbsize, vptbsize, 0.005, 0)
                        part_particles_create(ps, rpx, rpy, ptb, 1)
                        vptbsize = clamp((vptbsize + 0.3), 0.5, 1)
                        part_type_size(ptw, vptbsize, vptbsize, 0.012, 0)
                        part_particles_create(ps1, rpx, rpy, ptw, 1)
                        if (random(1) < 0.2)
                            part_particles_create(ps, rpx, rpy, ptf0, (5 * vptbsize))
                        scrpttrail1(rpx, rpy, 331, 2372, 139, 300, vptbsize, 1)
                    }
                    rp += 1
                }
                spd += (128 * (1 - timer))
            }
        }
        else
        {
            state = 3
            timer = -1
        }
    }
    if (state == 3)
    {
        if (timer < 0)
        {
            timer = 0
            with (objtree)
                instance_change(objwntree3, 1)
            with (objtree0)
                instance_change(objwntree2, 1)
            with (objplant00)
                instance_destroy()
            with (objplant03)
                sprite_index = ssmplant3b
            with (objplant04)
                sprite_index = ssmplant3b
            with (objplant05)
                sprite_index = ssmplant3b
            with (objplant06)
                sprite_index = ssmplant3b
            with (objplant07)
            {
            }
            with (objplant12)
                sprite_index = ssmplant92b
            with (objplant13)
                instance_destroy()
            with (objplant14)
                instance_destroy()
            with (objbmobencrater)
                state = 1
            ctblur = 1
        }
        else if (timer < 1)
        {
            with (objplayerview)
                target = 86
            with (objplayer)
            {
                caninput = false
                showbosshp = false
                if (other.timer > 0.08333333333333333 && ((other.timer * 120) % 30) == 0)
                {
                    if (!(collision_line(x, y, other.x, other.y, objrm53, 1, 1)))
                    {
                        hp -= 3
                        objplayerview.shaket = 12
                    }
                }
                if (hp > 0)
                    other.timer += (1/120)
            }
        }
        else if (timer < 2)
            timer += 0.005555555555555556
        else if (timer < 3)
        {
            with (objbmoben)
                state = 14
            timer += 0.004166666666666667
            ctfade = 1 - (timer - 2)
        }
        else
        {
            with (objbmoben)
                timer12 = 1
            destruct = 1
        }
    }
}
if (destruct > 0)
{
    if ((part_particles_count(ps) + part_particles_count(pss) + part_particles_count(ps1) + part_particles_count(ps16)) <= 0)
    {
        instance_destroy()
        part_system_destroy(ps)
        part_system_destroy(ps)
        part_system_destroy(pss)
        part_system_destroy(ps1)
        part_system_destroy(ps16)
        part_type_destroy(ptc)
        part_type_destroy(ptsp)
        part_type_destroy(ptsh)
        part_type_destroy(ptf0)
        part_type_destroy(ptf1)
        part_type_destroy(ptt)
        part_type_destroy(ptts)
        part_type_destroy(ptl)
        part_type_destroy(ptb)
        part_type_destroy(ptw)
        part_type_destroy(pts0d)
        part_type_destroy(pts0)
    }
}
