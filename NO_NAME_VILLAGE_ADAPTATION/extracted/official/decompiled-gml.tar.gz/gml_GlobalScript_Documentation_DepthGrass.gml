function Documentation_DepthGrass() //gml_Script_Documentation_DepthGrass
{
}

