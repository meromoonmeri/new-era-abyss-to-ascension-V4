function scrspr4dir2(argument0, argument1, argument2, argument3) //gml_Script_scrspr4dir2
{
    if (argument0 >= 45 && argument0 < 135)
        sprite_index = argument3
    else if (argument0 >= 135 && argument0 < 225)
        sprite_index = argument2
    else if (argument0 >= 225 && argument0 < 315)
        sprite_index = argument1
    else
        sprite_index = argument2
}

