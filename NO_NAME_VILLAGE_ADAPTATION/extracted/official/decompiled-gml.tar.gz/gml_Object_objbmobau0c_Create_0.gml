if layer_exists("watershadows")
    depth = layer_get_depth("watershadows")
else
    depth = layer_get_depth("shadows")
delay = 0
alpha = -1
appear = 0
pcatch = false
largen = -1
size0 = 0
size1 = 0
shakex1 = 0
shakey1 = 0
shakex2 = 0
shakey2 = 0
shakex3 = 0
shakey3 = 0
shaket = 0
ca = 0
ps = part_system_create()
if layer_exists("marsh")
    part_system_depth(ps, (layer_get_depth("marsh") - 4))
else
    part_system_depth(ps, layer_get_depth("shadows"))
pt = part_type_create()
part_type_sprite(pt, 1164, 1, 0, 1)
part_type_size(pt, 0, 0.1, 0.005555555555555556, 0)
part_type_alpha2(pt, 0, 0.5)
part_type_life(pt, 180, 180)
part_particles_create(ps, x, y, pt, 1)
pps = part_system_create()
part_system_depth(pps, (-y))
pt012 = part_type_create()
pt012d = part_type_create()
part_type_sprite(pt012, 2180, 0, 0, 1)
part_type_alpha3(pt012, 1, 1, 0)
part_type_speed(pt012, 4, 12, 0, 0)
part_type_direction(pt012, 50, 130, 0, 0)
part_type_gravity(pt012, 0.4, 270)
part_type_life(pt012, 40, 40)
part_type_death(pt012, 1, pt012d)
part_type_sprite(pt012d, 110, 1, 1, 0)
part_type_alpha3(pt012d, 1, 1, 0)
part_type_life(pt012d, 20, 20)
pt345 = part_type_create()
part_type_sprite(pt345, 2401, 0, 0, 1)
part_type_alpha3(pt345, 1, 1, 0)
part_type_speed(pt345, 4, 12, 0, 0)
part_type_direction(pt345, 50, 130, 0, 0)
part_type_gravity(pt345, 0.4, 270)
part_type_life(pt345, 40, 40)
part_type_death(pt345, 1, pt012d)
pt678 = part_type_create()
part_type_sprite(pt678, 2003, 0, 0, 1)
part_type_alpha3(pt678, 1, 1, 0)
part_type_speed(pt678, 4, 12, 0, 0)
part_type_direction(pt678, 50, 130, 0, 0)
part_type_gravity(pt678, 0.4, 270)
part_type_life(pt678, 40, 40)
part_type_death(pt678, 1, pt012d)
