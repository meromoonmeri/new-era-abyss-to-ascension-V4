function scrhncarry() //gml_Script_scrhncarry
{
    if (room == rm46)
    {
        x = 2760
        y = 1768
    }
    if (room == rmvillage)
    {
        x = 2880
        y = 2560
        dir = 90
    }
    if (room == rm56)
    {
        x = 4448
        y = 1728
    }
    if (room == rm66)
    {
        x = 896
        y = 2752
    }
    if (room == rm53)
    {
        x = 3692
        y = 1444
        dir = 335
    }
    if (room == rm54)
    {
        x = 2530
        y = 2388
        dir = 270
    }
    if (room == rm63)
    {
        x = 2112
        y = 1920
        dir = 315
    }
    if (room == rm65)
    {
        x = 1920
        y = 2400
        dir = 45
    }
    if (room == rm73)
    {
        x = 2960
        y = 2216
        dir = 225
    }
    if (room == rm74)
    {
        x = 2072
        y = 2524
        dir = 225
    }
    if (room == rm75)
    {
        x = 3260
        y = 2276
    }
    if (room == rm83)
    {
        x = 3584
        y = 2752
        dir = 270
    }
    if (room == rm84)
    {
        x = 2828
        y = 2120
        dir = 225
    }
    if (room == rm85)
    {
        x = 3072
        y = 2880
    }
    if (room == rm14)
    {
        x = 2304
        y = 1792
        dir = 45
    }
    if (room == rm23)
    {
        x = 3328
        y = 2112
        dir = 315
    }
    if (room == rm25)
    {
        x = 2432
        y = 1600
        dir = 90
    }
    if (room == rm33)
    {
        x = 2596
        y = 904
        dir = 270
    }
    if (room == rm34)
    {
        x = 3072
        y = 3392
        dir = 90
    }
    if (room == rm36)
    {
        x = 2952
        y = 1564
        dir = 0
    }
    if (room == rm43)
    {
        x = 3904
        y = 2176
        dir = 270
    }
    if (room == rm44)
    {
        x = 1536
        y = 1280
        dir = 340
    }
    if (room == rm45)
    {
        x = 3872
        y = 992
        dir = 90
    }
    if (room == rm58)
    {
        x = 1472
        y = 192
    }
    if (room == rm77)
    {
        x = 896
        y = 4032
    }
}

