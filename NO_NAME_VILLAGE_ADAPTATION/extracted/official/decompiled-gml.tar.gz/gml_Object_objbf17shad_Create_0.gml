startx = x
starty = y
destx = 0
desty = 0
spd = 0
