if (snatch == false)
{
    if (turn == 3)
    {
        dir = scrdir(self, objhunter)
        turn = 2
    }
    else if (turn == 2)
    {
        if (abs(angle_difference(dir, scrdir(self, objhunter))) < 90)
        {
            instance_create_layer(x, y, "shadows", objbmobau0c)
            dir = scrdir(self, objhunter)
            x += lengthdir_x((spd * 2), dir)
            y += lengthdir_y(spd, dir)
        }
        else
        {
            turn = 1
            dir = point_direction(x, y, 2816, 576)
        }
    }
    else if (turn == 1)
    {
        if (abs(angle_difference(dir, point_direction(x, y, 2816, 576))) < 90)
        {
            instance_create_layer(x, y, "shadows", objbmobau0c)
            dir = point_direction(x, y, 2816, 576)
            x += lengthdir_x((spd * 2), dir)
            y += lengthdir_y(spd, dir)
        }
        else
            turn = 0
    }
    else
    {
        with (objbmobau0c)
            appear = 1
        instance_destroy()
    }
}
