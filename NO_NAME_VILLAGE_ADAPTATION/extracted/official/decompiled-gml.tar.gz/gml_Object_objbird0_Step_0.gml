depth = (-y)
if (dir > 90 && dir < 270)
    facing = -1
else
    facing = 1
if (dir > 360)
    dir -= 360
else if (dir < 0)
    dir += 360
if (state == 0)
{
    scrspr4dir(dir, sbird0p1, sbird0p3)
    if (image_index == 0)
        delay = irandom_range(120, 360)
    if (image_index < 1)
        image_speed = 1 / delay
    else if (image_index < (image_number - image_speed))
        image_speed = 0.2
    else
    {
        state = choose(0, 1)
        image_index = 0
        dir = irandom(360)
    }
}
else if (state == 1)
{
    scrspr4dir(dir, sbird0i1, sbird0i3)
    if (image_index == 0)
        delay = irandom_range(30, 60)
    if (image_index < 1)
        spd = 0
    else if (image_index < 2)
        spd = 0.5
    else if (image_index < 3)
        spd = 2
    else
        spd = 0.5
    if (image_index < 1)
        image_speed = (1/30)
    else if (image_index < (image_number - image_speed))
    {
        image_speed = 0.2
        scrmovcol(spd, dir)
    }
    else
    {
        state = choose(0, 1)
        image_index = 0
        dir = irandom(360)
    }
}
if (state == 2)
{
    scrspr4dir(dir, sbird0u1, sbird0u3)
    if (image_index < (image_number - image_speed))
        image_speed = 0.4
    else
    {
        state = 4
        scrsound(snbirdfly, 20, 1, 1)
        image_index = 0
        z = 32
    }
}
else if (state == 4)
{
    scrspr4dir(dir, sbird0f1, sbird0f3)
    x += lengthdir_x(8, dir)
    y += lengthdir_x(8, dir)
    image_speed = 0.4
    z += zaccl
    if (image_index > 1 && image_index < 2)
        zaccl += 1
    if (z > 320)
    {
        if (alpha > 0)
            alpha -= (1/30)
        else
            instance_destroy()
    }
}
else if (scrdist(self, objplayerview.player) < 256)
{
    var rcheck = random(1)
    if (rcheck < 0.3)
    {
        state = 2
        image_index = 1
        dir = scrdir(objplayerview.player, self)
    }
}
