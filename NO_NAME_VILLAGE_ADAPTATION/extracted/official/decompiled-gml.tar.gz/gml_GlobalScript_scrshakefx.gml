function scrshakefx(argument0, argument1, argument2) //gml_Script_scrshakefx
{
    var destroy = argument0
    var shake = argument1
    var leaf = argument2
    if (!instance_exists(objeffect))
        instance_create_layer(0, 0, "instances", objeffect)
    if (!variable_global_exists("plantmap"))
        global.plantmap = ds_map_create()
    var hitlist = ds_list_create()
    var hitnumber = (instance_place_list(x, y, 120, hitlist, false)) + (instance_place_list(x, y, 178, hitlist, false))
    if (hitnumber > 0)
    {
        if (!instance_exists(objeffect))
            instance_create_layer(0, 0, "instances", objeffect)
        var snhit = 0
        for (var i = 0; i < hitnumber; i++)
        {
            var hitid = ds_list_find_value(hitlist, i)
            var idx = hitid.x
            var idy = hitid.y
            var ids = hitid.sprite_index
            var ido = hitid.object_index
            if ds_map_exists(global.plantmap, hitid)
            {
                if ((global.time - (array_get(ds_map_find_value(global.plantmap, hitid), 0))) > 30)
                    ds_map_replace(global.plantmap, hitid, [global.time, shake])
            }
            else
            {
                ds_map_add(global.plantmap, hitid, [global.time, shake])
                if (sprite_get_height(ids) > 64)
                {
                    if (destroy > 0)
                    {
                        if (snhit < 2)
                        {
                            snhit += 1
                            scrsound(snplantshake, 10, 1, 1)
                        }
                    }
                    else
                        scrsound(snplantshake, 10, shake, 1)
                }
            }
            var col = make_color_rgb(35, 133, 60)
            if (global.season == 2)
                make_color_rgb(49, 115, 55)
            var p = hitid.sprite_index
            var nsprite = hitid.sprite_index
            switch p
            {
                case objrmcave02:
                    with (hitid)
                        nsprite = sspplant0b
                    col = make_color_rgb(34, 99, 107)
                    break
                case 772:
                    with (hitid)
                        nsprite = sspplant3b
                    col = make_color_rgb(19, 133, 105)
                    break
                case 343:
                    with (hitid)
                        nsprite = sspplant3
                    col = make_color_rgb(19, 133, 105)
                    break
                case 204:
                    with (hitid)
                        nsprite = sspplant5b
                    leaf = leaf / 2
                    col = make_color_rgb(19, 133, 105)
                    break
                case 2167:
                    with (hitid)
                        nsprite = sspplant5
                    col = make_color_rgb(19, 133, 105)
                    break
                case 450:
                    with (hitid)
                        nsprite = sspplant92b
                    leaf = leaf / 2
                    col = make_color_rgb(199, 203, 186)
                    break
                case 87:
                    break
                case 294:
                    break
                case 2432:
                    with (hitid)
                        nsprite = ssmplant0b
                    break
                case 1228:
                    with (hitid)
                        nsprite = ssmplant1b
                    leaf = leaf / 2
                    col = make_color_rgb(189, 104, 81)
                    break
                case 1195:
                    break
                case 108:
                    with (hitid)
                        nsprite = ssmplant3b
                    break
                case 477:
                    with (hitid)
                        nsprite = ssmplant3
                    break
                case 976:
                    with (hitid)
                        nsprite = ssmplant3b
                    break
                case 227:
                    with (hitid)
                        nsprite = ssmplant5
                    break
                case 648:
                    break
                case 1276:
                    break
                case 1247:
                    with (hitid)
                        nsprite = ssmplant9b
                    col = make_color_rgb(189, 104, 81)
                    break
                case 145:
                    break
                case 1237:
                    break
                case 729:
                    with (hitid)
                        nsprite = ssmplant92b
                    leaf = leaf / 2
                    col = make_color_rgb(243, 208, 64)
                    break
                case 2133:
                    break
                case 2148:
                    break
                case 1104:
                    leaf = leaf / 1.5
                    break
                case 1347:
                    leaf = leaf / 1.5
                    col = make_color_rgb(158, 68, 78)
                    break
                case 712:
                    leaf = leaf / 1.5
                    col = make_color_rgb(243, 208, 64)
                    break
                case 1649:
                    with (hitid)
                        nsprite = sauplant0b
                    col = make_color_rgb(169, 127, 79)
                    break
                case 51:
                    with (hitid)
                        nsprite = sauplant3b
                    break
                case 1705:
                    with (hitid)
                        nsprite = sauplant3
                    break
                case 71:
                    with (hitid)
                        nsprite = sauplant3b
                    break
                case 1959:
                    with (hitid)
                        nsprite = sauplant5
                    break
                case 99:
                    break
                case 1880:
                    break
                case 303:
                    break
                case 175:
                    with (hitid)
                        nsprite = sauplant92b
                    leaf = leaf / 2
                    col = make_color_rgb(61, 79, 144)
                    break
                case 196:
                    break
                case 1463:
                    break
                case 2198:
                    with (hitid)
                        nsprite = swnplant0b
                    col = make_color_rgb(125, 13, 11)
                    break
                case 1013:
                    with (hitid)
                        nsprite = swnplant3b
                    col = make_color_rgb(22, 78, 91)
                    break
                case 581:
                    with (hitid)
                        nsprite = swnplant3
                    col = make_color_rgb(22, 78, 91)
                    break
                case 2434:
                    with (hitid)
                        nsprite = swnplant3
                    col = make_color_rgb(22, 78, 91)
                    break
                case 2337:
                    with (hitid)
                        nsprite = swnplant4
                    col = make_color_rgb(22, 78, 91)
                    break
                case 1677:
                    col = make_color_rgb(35, 66, 107)
                    break
                case 1797:
                    break
                case 1035:
                    col = make_color_rgb(125, 13, 11)
                    break
                case 2455:
                    col = make_color_rgb(35, 66, 107)
                    break
                case 2128:
                    with (hitid)
                        nsprite = swnplant92b
                    leaf = leaf / 2
                    col = make_color_rgb(125, 13, 11)
                    break
                case 739:
                    break
                case 308:
                    break
            }

            if (destroy > 0)
            {
                if (!instance_exists(p))
                    leaf = leaf * 1.25
            }
            var lbx = idx
            var lby = idy - sprite_get_yoffset(ids) + sprite_get_height(ids) / 2
            if (leaf < 1)
                leaf = 1
            if (sprite_get_height(ids) > 64)
            {
                if (destroy > 0 && nsprite != hitid.sprite_index && random(1) < (1/30))
                    instance_create_layer(hitid.x, hitid.y, "instances", objfruit)
                with (objeffect)
                {
                    part_type_color1(ptleaf0, col)
                    part_particles_create(psleaf, lbx, lby, ptleaf0, leaf)
                }
            }
            if (destroy > 0)
            {
                if instance_exists(hitid)
                    hitid.sprite_index = nsprite
            }
        }
    }
    ds_list_destroy(hitlist)
}

