if instance_exists(creator)
{
    depth = creator.depth - 8
    image_index = creator.image_index
    x = creator.x
    y = creator.y
}
else
    instance_destroy()
