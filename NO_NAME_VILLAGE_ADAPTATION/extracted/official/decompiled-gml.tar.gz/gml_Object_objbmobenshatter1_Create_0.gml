z = 0
zmax = irandom_range(32, 128)
