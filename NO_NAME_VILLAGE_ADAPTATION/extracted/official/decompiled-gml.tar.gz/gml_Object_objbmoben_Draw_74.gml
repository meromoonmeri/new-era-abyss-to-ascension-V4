event_inherited()
if (fpy <= 2000)
{
    if (fpy > 0)
        fpy -= ((2001 - fpy) / 4)
    else
        fpy = 0
    fadecontrol = clamp((fpy / 2000), 0, 1)
    draw_sprite_ext(sbmobenend12, 0, 0, fpy, 4, 4, 0, -1, 1)
}
