room_goto(targetRoom)
