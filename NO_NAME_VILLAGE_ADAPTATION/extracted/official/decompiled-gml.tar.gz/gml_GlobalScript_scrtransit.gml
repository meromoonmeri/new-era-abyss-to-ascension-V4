function scrtransit(argument0, argument1, argument2) //gml_Script_scrtransit
{
    room_goto(argument0)
    objplayer.x = argument1
    objplayer.y = argument2
}

