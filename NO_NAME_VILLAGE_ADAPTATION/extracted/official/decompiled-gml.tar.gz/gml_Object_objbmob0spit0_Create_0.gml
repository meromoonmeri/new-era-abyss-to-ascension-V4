event_inherited()
mob = -1
image_speed = 0.1
z = 8
vvel = 8
vaccl = 0.5
spd = 4
dir = 0
