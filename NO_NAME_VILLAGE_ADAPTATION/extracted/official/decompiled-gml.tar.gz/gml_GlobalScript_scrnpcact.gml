function scrnpcact(argument0, argument1, argument2, argument3) //gml_Script_scrnpcact
{
    if instance_exists(argument0)
    {
        if (argument0.sprite_index != argument1)
        {
            if (argument0 == objplayer)
                objplayer.caninput = false
            argument0.state = -1
            argument0.sprite_index = argument1
            argument0.image_index = 0
            argument0.image_speed = argument2
        }
        else if (argument3 >= 0)
        {
            if (argument0.image_index > (sprite_get_number(argument1) - 0.5))
            {
                argument0.image_speed = 0
                if (timertt < argument3)
                    timertt += 1
                else
                {
                    if (argument0 == objplayer)
                        objplayer.caninput = false
                    argument0.state = 0
                    itemuse = -4
                    timertt = 0
                    if variable_instance_exists(id, "timer")
                        timer += 1
                    if variable_instance_exists(id, "act")
                        act += 1
                }
            }
        }
        else if (argument3 == -1)
            argument0.image_speed = argument2
        else if (argument0.image_index > (sprite_get_number(argument1) - 0.5))
            argument0.image_speed = 0
    }
}

