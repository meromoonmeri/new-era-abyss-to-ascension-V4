function scrtimetofadein(argument0, argument1) //gml_Script_scrtimetofadein
{
    objplayer.caninput = false
    if (timertt < argument0)
        timertt += 1
    else if (objplayerview.lat < 1)
    {
        objplayerview.la = 1
        objplayerview.latt = argument1
    }
    else
    {
        timer += 1
        timertt = 0
        objplayerview.latt = 0.025
    }
}

