event_inherited()
depth = (-y) - 32
var rcoordx = 2880
var rcoordy = 2816
if (retreat == 1)
    idir = point_direction(x, y, rcoordx, rcoordy)
if (place_meeting(x, y, objplayer) && objplayer.iframe <= 0 && alpha == 1)
{
    if ((state == 2 && image_index > 5) || state == 3 || (state == 5 && sprite_index == sbmobsm1r))
    {
    }
    else if (hit >= 0)
    {
        with (objplayer)
            scrmovcol(clamp(spd, 4, 10), scrdir(other, self))
    }
}
if (state == 1)
{
    scrspr8dir(dir, sbmobsm1t0, sbmobsm1t1, sbmobsm1t2, sbmobsm1t3, sbmobsm1t4)
    scrmovcol(spd, dir)
    if (image_index < 3)
    {
        image_speed = 0.2
        spd = 0
        if (timer1 != 1)
        {
            timer1 = 1
            scrsound(snbmobsm0, 50, 1, 1)
        }
    }
    else if (image_index < 5)
    {
        if (timer1 != 2)
        {
            timer1 = 2
            objplayerview.shaket = 6
            scrsplash(x, y, sbmobsmsplash0, 2)
            var projectile = (-(sign(angle_difference(idir, dir)))) * 60
            var pset = projectile / 4
            var count = 0
            repeat (8)
            {
                var fdir = idir + projectile + (random_range(-3, 3))
                var fdist = 80
                var ball = instance_create_layer((x + (lengthdir_x((fdist * 1.5), fdir))), (y + (lengthdir_y(fdist, fdir))), "instances", objbmobsmp)
                ball.dir = fdir
                ball.spd = (count + 1) / 3 + (random_range(-2, 2))
                ball.vel = (count + 1) * 5 / 3
                ball.z = 300
                projectile = projectile - pset
                count += 1
            }
            dir = idir
            scrsound(snbmobsm2, 50, 1, 1)
            scrsound(snmobsm21, 50, 1, 1)
        }
        scrmovcol(spd, dir)
        spd += ((-1 - spd) / 4)
    }
    else if (image_index < (image_number - image_speed))
    {
        scrmovcol(spd, dir)
        spd += ((-spd) / 4)
    }
    else
        state = 0
}
else
    timer1 = 0
if (state == 2)
{
    if (dir >= 0 && dir < 60)
    {
        sprite_index = sbmobsm1d3
        dir = 30
    }
    else if (dir >= 60 && dir < 120)
    {
        sprite_index = sbmobsm1d4
        dir = 90
    }
    else if (dir >= 120 && dir < 180)
    {
        sprite_index = sbmobsm1d3
        dir = 150
    }
    else if (dir >= 180 && dir < 240)
    {
        sprite_index = sbmobsm1d1
        dir = 210
    }
    else if (dir >= 240 && dir < 300)
    {
        sprite_index = sbmobsm1d0
        dir = 270
    }
    else
    {
        sprite_index = sbmobsm1d1
        dir = 330
    }
    if (image_index < 3)
        image_speed = 0.2
    else if (image_index < 4)
    {
        if (image_index > 3)
            image_speed = 0.4
        if (timer2 == 0)
        {
            timer2++
            spd = 20
            scrsplash(x, y, sbmobsmsplash0, 0)
        }
        else if (timer2 == 1 && spd < 10)
        {
            timer2++
            scrsplash(x, y, sbmobsmsplash0, 1)
        }
        spd += ((4 - spd) / 4)
        scrmovcol(spd, dir)
    }
    else if (image_index < (image_number - 1))
    {
        image_speed = 0.2
        spd += ((1 - spd) / 12)
        scrmovcol(spd, dir)
    }
    else
        state = 0
}
else
    timer2 = 0
if (state == 3)
{
    image_index = 0
    image_speed = 0
    sprite_index = sempty
    x += lengthdir_x(spd, dir)
    y += lengthdir_y(spd, dir)
    if (!audio_is_playing(snbmobsm3))
        scrsound(snbmobsm3, 50, 1, 1)
    if (timer3 < 1)
    {
        timer3 += (1/30)
        var ad = (angle_difference(dir, idir)) / 3
        dir -= ((min(abs(ad), 3)) * sign(ad))
        spd += ((12 * (1 - ad / 360) - spd) / 4)
        if (((timer3 * 30) % 10) == 0)
            scrripple(x, y, sbmobsmripple0, 1.5, 3)
        if (retreat == 0)
        {
            if (scrdistview(x, y, player.x, player.y) < 192)
                timer3 = 1
        }
        else if (retreat == 1)
        {
            if (scrdistview(x, y, rcoordx, rcoordy) < 192)
                timer3 = 1
        }
    }
    else if (spd > 2)
    {
        image_speed = 0
        spd += ((-spd) / 12)
    }
    else
    {
        timer3 = 0
        state = 0
    }
}
else
{
    timer3 = 0
    if audio_is_playing(snbmobsm3)
        audio_stop_sound(snbmobsm3)
}
if (state == 4)
    state = 0
if (state == 5)
{
    if (timer5 == 0)
    {
        depth = (-y) + 32
        sprite_index = sbmobsm1r
        if (image_index < (image_number - image_speed))
        {
            if (image_speed != 0.2)
            {
                image_speed = 0.2
                scrsound(snbmobsm4, 50, 1, 1)
            }
        }
        else
        {
            timer5 = 1
            image_index = 1
        }
        if (hitout != 1 && event5 == 0)
        {
            spd += ((8 - spd) / 64)
            ad = (angle_difference(dir, idir)) / 60
            dir -= ((min(abs(ad), 2)) * sign(ad))
            x += lengthdir_x(spd, dir)
            y += lengthdir_y(spd, dir)
        }
    }
    else
    {
        if (catch5 == 0)
            scrmovcol(spd, dir)
        if (dir >= 22.5 && dir < 67.5)
        {
            sprite_index = sbmobsm1r3
            dir = 45
        }
        else if (dir >= 67.5 && dir < 112.5)
        {
            sprite_index = sbmobsm1r4
            dir = 90
        }
        else if (dir >= 112.5 && dir < 157.5)
        {
            sprite_index = sbmobsm1r3
            dir = 135
        }
        else if (dir >= 157.5 && dir < 202.5)
        {
            sprite_index = sbmobsm1r2
            dir = 180
        }
        else if (dir >= 202.5 && dir < 247.5)
        {
            sprite_index = sbmobsm1r1
            dir = 225
        }
        else if (dir >= 247.5 && dir < 292.5)
        {
            sprite_index = sbmobsm1r0
            dir = 270
        }
        else if (dir >= 292.5 && dir < 337.5)
        {
            sprite_index = sbmobsm1r1
            dir = 315
        }
        else
        {
            sprite_index = sbmobsm1r2
            dir = 0
        }
        if (image_index < 1)
        {
            image_speed = 0.2
            image_index = 1
            mask_index = sbmobsm1r
        }
        else if (image_index < (image_number - image_speed))
        {
            chit = 0
            if (hitout == 1)
            {
                timer5 = 3
                scrsound(snmobsm21, 50, 1, 1)
                scrsplash(x, y, sbmobsmsplash0, 1)
                scrsplash(x, y, sbmobsmsplash0, 2)
                image_index = 3
            }
            else
            {
                if (timer5 < 2 && hitout != 1)
                {
                    if (event5 == 0)
                    {
                        if (place_meeting(x, y, player) && objplayer.iframe <= 0)
                        {
                            if (player != objft0)
                                catch5 = 1
                        }
                        chit = 2
                    }
                    timer5 = 2
                    objplayerview.shaket = 8
                    scrsplash(x, y, sbmobsmsplash0, 0)
                    scrsplash(x, y, sbmobsmsplash0, 1)
                    scrsplash(x, y, sbmobsmsplash0, 2)
                    for (var i = 0; i < 36; i += 1)
                    {
                        if (random(1) < 0.25)
                        {
                            fdir = i * 10 + random(5)
                            fdist = 30
                            ball = instance_create_layer((x + (lengthdir_x((fdist * 1.5), fdir))), (y + (lengthdir_y(fdist, fdir))), "instances", objbmobsmp)
                            ball.dir = fdir
                            ball.spd = random_range(1, 6)
                            ball.vel = ball.spd * 4
                            ball.z = 360
                            if (event5 > 0)
                                ball.noncol = true
                        }
                    }
                }
                if (image_index < 2)
                    spd += ((20 - spd) / 4)
                else if (image_index < 3)
                    spd += ((-spd) / 12)
                else
                    spd = 0
                if (timer5 == 2 && image_index > 3)
                {
                    timer5 = 3
                    objplayerview.shaket = 4
                    scrsplash(x, y, sbmobsmsplash0, 2)
                    chit = 2
                }
                if (image_index < 3)
                    spd = 8
                else
                    spd += ((-spd) / 4)
                if (event5 == 1)
                    event5 = 2
            }
            mask_index = sbmobsm1shad
            hitout = 0
        }
        else
            state = 0
    }
}
else
    timer5 = 0
if (state == 6)
{
    if (dir >= 22.5 && dir < 67.5)
    {
        sprite_index = sbmobsm1ss3
        dir = 45
    }
    else if (dir >= 67.5 && dir < 112.5)
    {
        sprite_index = sbmobsm1ss4
        dir = 90
    }
    else if (dir >= 112.5 && dir < 157.5)
    {
        sprite_index = sbmobsm1ss3
        dir = 135
    }
    else if (dir >= 157.5 && dir < 202.5)
    {
        sprite_index = sbmobsm1ss2
        dir = 180
    }
    else if (dir >= 202.5 && dir < 247.5)
    {
        sprite_index = sbmobsm1ss1
        dir = 225
    }
    else if (dir >= 247.5 && dir < 292.5)
    {
        sprite_index = sbmobsm1ss0
        dir = 270
    }
    else if (dir >= 292.5 && dir < 337.5)
    {
        sprite_index = sbmobsm1ss1
        dir = 315
    }
    else
    {
        sprite_index = sbmobsm1ss2
        dir = 0
    }
    if (image_index < (image_number - image_speed))
    {
        image_speed = 0.2
        if (image_index > 1 && timer6 == 0)
        {
            timer6 = 1
            scrsound(snbmobsm1, 50, 1, 1)
        }
        else if (image_index > 3 && timer6 == 1)
            timer6 = 2
        else if (image_index > 4 && timer6 == 2)
            timer6 = 3
        else if (image_index > 5 && timer6 == 3)
        {
            timer6 = 4
            objplayerview.shaket = 10
            scrsplash(x, y, sbmobsmsplash0, 1)
            projectile = choose(-1, 1)
            repeat (15)
            {
                fdir = dir + projectile + random(5)
                fdist = 80
                ball = instance_create_layer((x + (lengthdir_x((fdist * 1.5), fdir))), (y + (lengthdir_y(fdist, fdir))), "instances", objbmobsmp)
                ball.dir = fdir
                ball.spd = (irandom_range(4, 8)) + (abs(30 - abs(projectile))) * 0.5
                ball.vel = irandom_range(8, 14)
                projectile = -1.3 * projectile
            }
            scrsound(snmobsm21, 50, 1, 1)
        }
        else if (image_index > 5 && timer6 == 4)
            timer6 = 5
    }
    else
    {
        state = 0
        timer6 = 0
    }
}
else
    timer6 = 0
if (state == 7)
{
    scrspr8dir(dir, sbmobsm1su0, sbmobsm1su1, sbmobsm1su2, sbmobsm1su3, sbmobsm1su4)
    if (image_index < (image_number - image_speed))
    {
        image_speed = 0.2
        if (image_index > 1 && timer7 == 0)
        {
            timer7 = 1
            scrsound(snbmobsm1, 50, 1, 0.8)
        }
        else if (image_index > 3 && timer7 == 1)
        {
            timer7 = 2
            objplayerview.shaket = 8
            scrsplash(x, y, sbmobsmsplash0, 1)
            for (i = 0; i < 72; i += 1)
            {
                if (random(1) < 0.5)
                {
                    fdir = i * 10 + random(5)
                    fdist = 30
                    ball = instance_create_layer((x + (lengthdir_x((fdist * 1.5), fdir))), (y + (lengthdir_y(fdist, fdir))), "instances", objbmobsmp)
                    ball.dir = fdir
                    ball.spd = random_range(1, 6)
                    ball.vel = ball.spd * 4
                    ball.z = 360
                }
            }
            scrsound(snmobsm21, 50, 1, 1)
        }
        else if (image_index > 3 && timer7 == 2)
            timer7 = 3
        else if (image_index > 4 && timer7 == 3)
        {
            timer7 = 4
            scrsplash(x, y, sbmobsmsplash0, 2)
        }
    }
    else
        state = 0
}
else
    timer7 = 0
if (catch5 == 1)
{
    catch5 = 2
    with (player)
    {
        state = -1
        objplayer.caninput = 0
        alpha = 0
        x = other.x
        y = other.y
    }
    var newplayer = instance_create_layer(x, (y - 360), "instances", objempty)
    newplayer.creator = id
    newplayer.depth = (-y) + 4
    if (player == objplayer)
        newplayer.sprite_index = sbmobsm1rplayer
    else
        newplayer.sprite_index = sbmobsm1rreg1
    newplayer.image_speed = 0
    newplayer.image_xscale = 4
    newplayer.image_yscale = 4
    catchyvel = 10
    objplayerview.target = -4
}
else if (catch5 == 2)
{
    with (objempty)
    {
        if (creator == other.id)
        {
            other.catchyvel -= 0.4
            if (y < other.y)
                y -= other.catchyvel
            if (other.catchyvel > 0)
                image_index = 2
            else
                image_index = 3
            if (abs(other.catchyvel) > 4)
            {
                if (other.catchyvel > 0)
                    image_index = 0
                else
                    image_index = 3
            }
            else if (other.catchyvel > 0)
                image_index = 1
            else
                image_index = 2
            objplayerview.targetx = x
            objplayerview.targety = y + 64
        }
    }
    if (state != 5 && state != 8)
    {
        state = 8
        image_index = 0
    }
}
if (event5 == 2)
{
    event5 = 3
    with (objreg)
    {
        state = -1
        objplayer.caninput = false
        alpha = 0
        x = other.x
        y = other.y
    }
    with (objrm82bait)
        image_alpha = 0
    var neweplayer = instance_create_layer(x, (y - 360), "instances", objempty)
    neweplayer.creator = id
    neweplayer.depth = (-y) + 4
    neweplayer.sprite_index = sbmobsm1rreg
    neweplayer.image_speed = 0
    neweplayer.image_xscale = 4
    neweplayer.image_yscale = 4
    catchyvel = 10
    objplayerview.target = -4
}
else if (event5 == 3)
{
    with (objempty)
    {
        if (creator == other.id)
        {
            other.catchyvel -= 0.4
            if (y < other.y)
                y -= other.catchyvel
            if (other.catchyvel > 0)
                image_index = 2
            else
                image_index = 3
            if (abs(other.catchyvel) > 4)
            {
                if (other.catchyvel > 0)
                    image_index = 0
                else
                    image_index = 3
            }
            else if (other.catchyvel > 0)
                image_index = 1
            else
                image_index = 2
            objplayerview.targetx = x
            objplayerview.targety = y + 64
        }
    }
    if (state != 5 && state != 8)
    {
        state = 8
        image_index = 0
    }
}
if (state == 8)
{
    sprite_index = sbmobsm1c0
    if (image_index > 1 && image_index < 2)
        image_speed = 0.08
    else if (image_index > 3 && image_index < 4)
        image_speed = 0.1
    else
        image_speed = 0.2
    if (image_index > 4)
        objplayerview.target = self
    if (image_index > 2 && event5 == 0)
    {
        if (objplayer.hp > 0)
        {
            if ((global.time % 30) == 0)
            {
                if (event5 == 0)
                {
                    objplayer.hp -= 0.5
                    if (frac(objplayer.hp) == 0)
                        objplayerview.shaket = 12
                    else
                        objplayerview.shaket = 6
                }
            }
        }
        if (flash <= 0 && (scrinput("runp") || scrinput("actionp")))
        {
            objplayerview.shaket = 6
            flash = 0.5
            if (timer85 < 5)
                timer85 += 1
            else
            {
                state = 8.5
                image_index = 0
                flash = 1
                timer85 = 0
            }
        }
    }
    if (image_index < 2)
    {
        dir = 270
        if (timer8 != 1)
        {
            timer8 = 1
            scrsound(snbmobsm0, 100, 1, 1)
        }
    }
    else if (image_index < (image_number - 0.8))
    {
        if (timer8 == 1)
        {
            timer8 = 2
            scrsound(snbmobsm5, 100, 1, 1)
            objplayerview.shaket = 20
            with (objempty)
            {
                if (creator == other.id)
                {
                    instance_destroy()
                    other.catch5 = 0
                }
            }
            scrsplash(x, y, sbmobsmsplash0, 1)
        }
        else if (timer8 == 2 && image_index > 5)
        {
            timer8 = 3
            objplayerview.shaket = 6
            scrsplash(x, y, sbmobsmsplash0, 1)
        }
    }
    else
        image_speed = 0
}
else if (state == 8.5)
{
    scrspr8dir(dir, sbmobsm1ss0, sbmobsm1ss1, sbmobsm1ss2, sbmobsm1ss3, sbmobsm1ss4)
    ad = (angle_difference(dir, point_direction(x, y, 2816, 2752))) / 60
    dir -= ((min(abs(ad), 9999)) * sign(ad))
    if (image_index < (image_number - image_speed))
    {
        image_speed = 0.2
        if (image_index < 2)
            objplayerview.target = self
        else if (objplayer.alpha == 0)
        {
            objplayerview.targetx = x
            objplayerview.targety = y + 128
        }
        with (player)
        {
            if (alpha == 0)
            {
                x = other.x
                y = other.y
                state = 0
                caninput = false
                objplayerview.target = -4
            }
            else
                objplayerview.target = self
        }
        if (image_index > 1 && timer85 == 0)
        {
            timer85 = 1
            scrsound(snbmobsm1, 50, 1, 1)
        }
        else if (image_index > 3 && timer85 == 1)
            timer85 = 2
        else if (image_index > 4 && timer85 == 2)
            timer85 = 3
        else if (image_index > 5 && timer85 == 3)
        {
            timer85 = 4
            objplayerview.shaket = 10
            scrsplash(x, y, sbmobsmsplash0, 1)
            projectile = choose(-1, 1)
            repeat (15)
            {
                fdir = dir + projectile + random(5)
                fdist = 80
                ball = instance_create_layer((x + (lengthdir_x((fdist * 1.5), fdir))), (y + (lengthdir_y(fdist, fdir))), "instances", objbmobsmp)
                ball.dir = fdir
                ball.spd = (irandom_range(4, 8)) + (abs(30 - abs(projectile))) * 0.5
                ball.vel = irandom_range(8, 14)
                projectile = -1.3 * projectile
            }
            with (player)
            {
                x = other.x + (lengthdir_x(120, other.dir))
                y = other.y + (lengthdir_y(80, other.dir))
                alpha = 1
                objplayerview.target = self
                state = 6
                iframe = 1
                dir = other.dir - 180
                caninput = false
                image_index = 0
                objplayerview.shaket = 16
            }
            scrsound(snmobsm21, 50, 1, 1)
        }
        else
        {
            objplayerview.target = 100
            with (player)
            {
                if (alpha > 0 && state == 6)
                {
                    var kbspd = 0
                    if (image_index < 1)
                        kbspd = 12
                    else if (image_index < 2)
                        kbspd = 4
                    else if (image_index < 3)
                        kbspd = 8
                    else if (image_index < 4)
                        kbspd = 2
                    else
                        kbspd = 0
                    scrmovcol((-kbspd), dir)
                }
            }
        }
    }
    else
    {
        state = 0
        timer85 = 0
    }
}
else
{
    timer8 = 0
    timer85 = 0
}
if (hit <= 0)
{
    if (state == 9)
        hit = -2
    else if (state == 3 || (state == 2 && image_index > 2) || (state == 5 && image_index < 1))
        hit = -1
    else
        hit = 0
}
if (hit > 0 && state != 9)
{
    if ((state == 2 && image_index > 4) || state == 3 || (state == 5 && sprite_index == sbmobsm1r))
    {
        scrmobhurt(5, 9, 1)
        timer5 = 0
        hitout = 1
    }
    else
        scrmobhurt(-1, 9, 1)
}
if (state == 9)
{
    sprite_index = sbmobsm1de0
    if (image_index < 3)
    {
        image_speed = 0.2
        if (image_index >= 2 && image_index < (2 + image_speed))
        {
            scrsplash(x, y, sbmobsmsplash0, 1)
            scrsound(snbmobsm6, 50, 1, 0.8)
        }
    }
    else if (image_index < 4)
        image_speed = 0.1
    else if (image_index < (image_number - 1))
        image_speed = 0.2
    else if (image_speed != 0)
    {
        image_speed = 0
        if (dead == 0)
            dead = 1
        image_index = image_number - 0.5
        scrsplash(x, y, sbmobsmsplash0, 0)
    }
    if (image_index < 2)
        timer9 = 0
    else if (image_index > 2)
    {
        if (timer9 < 20)
        {
            timer9 += 1
            repeat (3)
            {
                var rdist = 128 + timer9 / 30 * 384 + (irandom_range(-64, 64))
                var rdir = irandom(360)
                var rgtargx = x + (lengthdir_x(rdist, rdir))
                var rgtargy = y + (lengthdir_y(rdist, rdir))
                var rgz = 200 + (random_range(-30, 30))
                var rgzvel = random_range(12, 24)
                var rgzaccl = 0.8
                scrthrowarc(objeventregt, (x + (lengthdir_x(4, rdir))), (y + (lengthdir_y(4, rdir))), rgtargx, rgtargy, rgz, rgzvel, rgzaccl)
            }
        }
        else if (timer9 < 40)
        {
            timer9 = 40
            var rte = instance_create_layer(x, y, "instances", objeventregte)
            var rtedir = scrdir(self, objfollower)
            var rtedist = scrdist(self, objfollower)
            var c = 1.2
            rte.targ = 227
            rte.startx = objfollower.x + (lengthdir_x(((-c) * rtedist), rtedir))
            rte.starty = objfollower.y + (lengthdir_y(((-c) * rtedist), rtedir))
            rte.dist = 1 - 1 / c
        }
    }
}
else
    timer9 = 0
if (state == 0)
{
    objplayer.boss = self
    if (pattern < 0)
    {
        scrspr8dir(dir, sbmobsm1t0, sbmobsm1t1, sbmobsm1t2, sbmobsm1t3, sbmobsm1t4)
        image_index = 0
        image_speed = 0
        pattern += (1/120)
    }
    else if (pattern < 1)
    {
        image_index = 0
        var addir = abs(angle_difference(dir, idir))
        var rchoose = random(1)
        if (addir < 45)
        {
            if (rchoose < 0.8)
                pattern = 2
            else
                pattern = 4
        }
        else if (addir < 90)
        {
            if (rchoose < 0.1)
                pattern = 1
            else if (rchoose < 0.3)
                pattern = 3
            else
                pattern = 4
        }
        else if (addir < 135)
        {
            if (rchoose < 0.3)
                pattern = 1
            else if (rchoose < 0.3)
                pattern = 3
            else
                pattern = 4
        }
        else if (rchoose < 0.5)
            pattern = 1
        else
            pattern = 3
        if (scrdistview(x, y, player.x, player.y) > 576)
        {
            if (rchoose < 0.25)
                pattern = 1
            else
                pattern = 2
        }
        if (retreat == 1)
            pattern = 5
    }
    if (pattern == 1)
    {
        if (timer01 == 0)
        {
            timer01 = 2
            if (awaydist > 0)
                awaydir = (point_direction(x, y, 2880, 2816)) + (choose(-30, -15, 0, 15, 30))
            image_index = 0
            state = 2
        }
        else if (timer01 < 5)
        {
            sprite_index = sempty
            if (awaydist > 0)
            {
                timer01 += 3
                ad = angle_difference(dir, awaydir)
                dir -= ((min(abs(ad), 90)) * sign(ad) * 0.7)
                state = 3
                if (timer01 > 2 && point_distance(x, y, 2880, 2816) > 704)
                {
                    pattern = -1
                    image_index = 0
                    state = 5
                }
            }
            else
            {
                timer01 += 1
                ad = angle_difference(dir, idir)
                dir -= ((min(abs(ad), 90)) * sign(ad) * 0.7)
                state = 3
                if (scrdistview(x, y, player.x, player.y) < 128)
                {
                    pattern = -1
                    image_index = 0
                    state = 5
                }
            }
        }
        else if (timer01 == 5)
        {
            awaydist = 0
            if (hp > (maxhp / 2))
                pattern = -1
            else
                timer01 = 6
            image_index = 0
            state = 5
        }
        else
        {
            if (abs(angle_difference(dir, idir)) < 60)
                state = 6
            else
                state = 1
            image_index = 0
            pattern = -1
        }
    }
    else
        timer01 = 0
    if (pattern == 2)
    {
        if (timer02 == 0)
        {
            timer02 = 1
            dir = idir
            state = 6
            image_index = 0
        }
        else
        {
            if (hp < (maxhp / 2) && scrdistview(x, y, player.x, player.y) < 256)
            {
                if (abs(angle_difference(dir, idir)) < 60)
                {
                    dir = idir
                    state = 6
                }
                else
                    state = 1
            }
            pattern = -1
            image_index = 0
        }
    }
    else
        timer02 = 0
    if (pattern == 3)
    {
        if (timer03 < 2)
        {
            dir += min(angle_difference(idir, dir), 45)
            state = 7
            image_index = 0
            timer7 = 0
            if (scrdistview(x, y, player.x, player.y) < 384 && random(1) < 0.5)
                timer03 += 1
            else
                timer03 = 2
        }
        else if (timer03 == 2)
        {
            timer03 = 3
            if (hp < (maxhp / 2))
            {
                if (scrdistview(x, y, player.x, player.y) < 256)
                {
                    if (abs(angle_difference(dir, idir)) < 60)
                    {
                        dir = idir
                        state = 6
                    }
                    else
                        state = 1
                }
                else
                {
                    dir = idir
                    state = 6
                }
            }
            image_index = 0
        }
        else
        {
            pattern = -1
            image_index = 0
        }
    }
    else
        timer03 = 0
    if (pattern == 4)
    {
        if (timer04 == 0)
        {
            timer04 = 1
            image_index = 0
            state = 1
        }
        else
        {
            pattern = -1
            image_index = 0
            if (hp < (maxhp / 2))
            {
                if (hp < (maxhp / 2) && scrdistview(x, y, player.x, player.y) < 256)
                {
                    if (abs(angle_difference(dir, idir)) < 60)
                    {
                        dir = idir
                        state = 6
                    }
                    else
                        state = 1
                }
                else
                {
                    dir = idir
                    state = 6
                }
            }
        }
    }
    else
        timer04 = 0
    if (pattern == 5)
    {
        if (timer05 == 0)
        {
            timer05 = 1
            dir = idir
            image_index = 0
            state = 2
        }
        else if (timer05 == 1)
        {
            timer05 = 2
            sprite_index = sempty
            state = 3
        }
        else if (timer05 == 2)
        {
            timer05 = 3
            state = 5
            hitout = true
            image_index = 0
        }
        else
        {
            sprite_index = sbmobsm1t0
            image_index = 0
            image_speed = 0
            state = -3
        }
    }
    if (pattern == 15)
    {
        if (timer05 == 0)
        {
            objplayer.caninput = false
            objplayer.dir = scrdir(objplayer, self)
            objplayerview.target = self
            timer05 = 1
            dir = point_direction(x, y, 2880, 2752)
            image_index = 0
            state = 2
        }
        else
        {
            timer05 = 2
            image_index = 0
            state = 9
        }
    }
}
if (state == -1)
{
    scrspr8dir(dir, sbmobsm1t0, sbmobsm1t1, sbmobsm1t2, sbmobsm1t3, sbmobsm1t4)
    image_index = 0
    image_speed = 0
    if (scrdistview(x, y, player.x, player.y) < 384)
    {
        with (objplayer)
            scrmovenpc(self, (x + (lengthdir_x(20, scrdir(other, self)))), (y + (lengthdir_y(20, scrdir(other, self)))))
    }
}
else
    timern1 = 0
if (state == -2)
{
}
if (state == -3)
{
}
if (event0 > 0)
{
    projectile = choose(-1, 1)
    repeat (15)
    {
        fdir = random_range(225, 315)
        fdist = 80
        part_particles_create(part_system, (x + (lengthdir_x((fdist * 1.5), fdir))), (y + (lengthdir_y(fdist, fdir))), part_type2, 1)
        part_type_direction(part_type2, fdir, fdir, 0, 0)
        part_type_speed(part_type2, -4, 4, 0, 0)
        projectile = -1.3 * projectile
    }
    event0 -= 1
}
if (event1 > 0)
{
    if ((global.time % 5) == 0)
    {
        part_particles_create(pssw, x, (y + 32), ptsw, 1)
        if (random(1) < 0.4)
            scrsplash(x, y, sbmobsmsplash0, 4)
        if (random(1) < 0.1)
            scrsplash(x, y, sbmobsmsplash0, 2)
        if (random(1) < 0.1)
        {
            with (objmobsm5)
            {
                if (random(1) < 0.2)
                    timer = 0
            }
        }
    }
}
