function scrstringwrap() //gml_Script_scrstringwrap
{
    var str = argument0
    var maxwidth = argument1
    var strlength = string_length(str)
    var lastspace = 1
    var count = 1
    repeat strlength
    {
        var substr = string_copy(str, 1, count)
        if (string_char_at(str, count) == " ")
            lastspace = count
        if (string_width(substr) > maxwidth)
        {
            str = string_delete(str, lastspace, 1)
            str = string_insert("/n", str, lastspace)
        }
        count += 1
    }
    return str;
}

