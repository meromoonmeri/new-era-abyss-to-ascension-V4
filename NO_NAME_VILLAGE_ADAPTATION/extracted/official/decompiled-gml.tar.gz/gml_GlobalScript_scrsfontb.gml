function scrsfontb(argument0, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9, argument10, argument11, argument12) //gml_Script_scrsfontb
{
    var vsfont = argument0
    var vx = argument1
    var vy = argument2
    var vtext = argument3
    var vcol = argument4
    var vhal = argument5
    var vval = argument6
    var vsep = argument7
    var vw = argument8
    var vxscale = argument9
    var vyscale = argument10
    if (argument12 != -1)
    {
        scrsfont(vsfont, (vx - 4), vy, vtext, argument12, vhal, vval, vsep, vw, (vxscale * argument11), (vyscale * argument11))
        scrsfont(vsfont, (vx + 4), vy, vtext, argument12, vhal, vval, vsep, vw, (vxscale * argument11), (vyscale * argument11))
        scrsfont(vsfont, vx, (vy - 4), vtext, argument12, vhal, vval, vsep, vw, (vxscale * argument11), (vyscale * argument11))
        scrsfont(vsfont, vx, (vy + 4), vtext, argument12, vhal, vval, vsep, vw, (vxscale * argument11), (vyscale * argument11))
    }
    scrsfont(vsfont, vx, vy, vtext, vcol, vhal, vval, vsep, vw, vxscale, vyscale)
}

