function scrrmwintercount() //gml_Script_scrrmwintercount
{
    var wintercount = 0
    if (global.mapgrid[3][7] > 0)
        wintercount += 1
    if (global.mapgrid[3][8] > 0)
        wintercount += 1
    if (global.mapgrid[3][9] > 0)
        wintercount += 1
    if (global.mapgrid[4][10] > 0)
        wintercount += 1
    if (global.mapgrid[4][7] > 0)
        wintercount += 1
    if (global.mapgrid[4][8] > 0)
        wintercount += 1
    if (global.mapgrid[4][9] > 0)
        wintercount += 1
    if (global.mapgrid[5][7] > 0)
        wintercount += 1
    if (global.mapgrid[5][8] > 0)
        wintercount += 1
    if (global.mapgrid[5][9] > 0)
        wintercount += 1
    if (global.mapgrid[6][7] > 0)
        wintercount += 1
    if (global.mapgrid[6][8] > 0)
        wintercount += 1
    if (global.mapgrid[6][9] > 0)
        wintercount += 1
    if (global.mapgrid[7][7] > 0)
        wintercount += 1
    if (global.mapgrid[7][8] > 0)
        wintercount += 1
    return wintercount;
}

