shader_set(shblueforest)
shader_set_uniform_f(unitimer, current_time)
draw_surface(application_surface, 0, 0)
shader_reset()
