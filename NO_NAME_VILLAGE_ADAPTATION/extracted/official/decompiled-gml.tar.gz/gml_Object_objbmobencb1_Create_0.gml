fl = 0
state = 0
creator = 0
cancel = 0
timer = 0
destruct = 0
type = "cb1"
dud = false
pdmg = 0
dx = x
dy = y
dmg = 0
ct = 60
ctfade = 1
ctblur = 0
bstate = -1
z = 20
zvel = 0
spd = 0
dir = 0
prevx = x
prevy = y
target = 100
targx = objplayer.x
targy = objplayer.y
targz = 0
attach = [0, 0, 0]
ps = part_system_create()
part_system_depth(ps, (-y))
pss = part_system_create()
part_system_depth(ps, layer_get_depth("invisible"))
ps1 = part_system_create()
part_system_depth(ps1, ((-y) + 1))
ps16 = part_system_create()
part_system_depth(ps16, ((-y) - 16))
ptc = part_type_create()
part_type_sprite(ptc, 501, 0, 0, 0)
part_type_scale(ptc, 0.8, 0.8)
part_type_direction(ptc, 0, 360, 0, 0)
part_type_orientation(ptc, 0, 360, 0, 0, 1)
part_type_life(ptc, 999, 999)
ptsp = part_type_create()
part_type_sprite(ptsp, 1593, 0, 0, 0)
part_type_orientation(ptsp, 0, 360, 0, 0, 0)
part_type_life(ptsp, 10, 15)
ptsh = part_type_create()
part_type_sprite(ptsh, 2637, 0, 0, 0)
part_type_size(ptsh, 0.02, 0.02, 0.025, 0.1)
part_type_alpha3(ptsh, 0.2, 0.9, 0)
part_type_life(ptsh, 10, 10)
ptf0 = part_type_create()
part_type_sprite(ptf0, 501, 0, 0, 0)
part_type_alpha3(ptf0, 1, 0.8, 0)
part_type_speed(ptf0, 24, 32, 0, 0)
part_type_direction(ptf0, 80, 100, 0, 0)
part_type_gravity(ptf0, 1, 270)
part_type_life(ptf0, 50, 50)
ptf1 = part_type_create()
part_type_sprite(ptf1, 2452, 1, 1, 0)
part_type_life(ptf1, 20, 30)
ptt = part_type_create()
part_type_sprite(ptt, 1608, 0, 0, 0)
part_type_scale(ptt, 2, 2)
part_type_color1(ptt, 16777215)
part_type_alpha3(ptt, 1, 1, 0.4)
part_type_life(ptt, 60, 60)
ptts = part_type_create()
part_type_sprite(ptts, 725, 0, 0, 0)
part_type_size(ptts, 1, 1, -0.01, 0)
part_type_alpha3(ptts, 1, 1, 0)
part_type_life(ptts, 30, 30)
ptl = part_type_create()
part_type_sprite(ptl, 646, 0, 0, 0)
part_type_orientation(ptl, -50, 50, 0, 0, 0)
part_type_alpha3(ptl, 1, 1, 0)
part_type_life(ptl, 60, 120)
ptb = part_type_create()
part_type_sprite(ptb, 641, 1, 1, 0)
part_type_alpha3(ptb, 1, 1, 0)
part_type_life(ptb, 50, 50)
ptw = part_type_create()
part_type_sprite(ptw, 2589, 1, 1, 0)
part_type_scale(ptw, 4, 4)
part_type_colour1(ptw, 0)
part_type_life(ptw, 25, 25)
pts0d = part_type_create()
part_type_sprite(pts0d, 667, 0, 0, 0)
part_type_life(pts0d, 5, 5)
pts0 = part_type_create()
part_type_sprite(pts0, 1949, 1, 1, 0)
part_type_size(pts0, 1, 1, 0.005, 0)
part_type_life(pts0, 45, 45)
part_type_death(pts0d, 1, pts0)
