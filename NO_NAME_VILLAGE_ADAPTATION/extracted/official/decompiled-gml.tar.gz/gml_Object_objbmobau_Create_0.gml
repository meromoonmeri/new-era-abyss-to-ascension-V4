event_inherited()
if (!instance_exists(objbmobauview))
    instance_create_layer(objplayerview.x, objplayerview.y, "instances", objbmobauview)
mobname = "Backward Snail"
mob = 3
level = 4
maxhp = 25
hp = maxhp
state = -1
deflect = true
eventt = 0
balpha = 1
dir = 270
boss = true
aggro = 0
mdir = 0
delay0 = 0
pattern = -1
dist1 = 0
timer2 = 0
splash2 = 0
splash4 = 0
timer6 = 0
mash = 0
masht = 0
shellhp = 0
dip = 0
dipspd = 0
dipy = 0
ball = 0
grabt = 0
grabdelay = 0
undersprite = -4
timer01 = 0
timer02 = 0
timer03 = 0
timer04 = 0
rthitdir = 0
rtmove = 0
shakex1 = 0
shakey1 = 0
shakex2 = 0
shakey2 = 0
shakex3 = 0
shakey3 = 0
shaket = -1
ca = 0
prevx = 0
prevy = 0
overlay = -1
timer5 = -1
worms = 0
wormst = 0
wptt = -1
ps = part_system_create()
part_system_depth(ps, layer_get_depth("belowgrass"))
pt = part_type_create()
pts = part_type_create()
ptd = part_type_create()
part_type_sprite(pt, 1889, 0, 0, 0)
part_type_speed(pt, 1, 8, 0, 0)
part_type_direction(pt, 50, 130, 0, 0)
part_type_gravity(pt, 0.4, 270)
part_type_life(pt, 20, 20)
part_type_step(pt, -2, pts)
part_type_death(pt, 1, ptd)
part_type_sprite(pts, 1889, 1, 1, 0)
part_type_life(pts, 10, 10)
part_type_sprite(ptd, 1302, 1, 1, 0)
part_type_alpha3(ptd, 1, 0.5, 0)
part_type_life(ptd, 10, 10)
ps2 = part_system_create()
part_system_depth(ps2, layer_get_depth("belowgrass"))
pt2 = part_type_create()
pts2 = part_type_create()
ptd2 = part_type_create()
part_type_sprite(pt2, 1747, 0, 0, 0)
part_type_speed(pt2, 0.8, 4, 0, 0)
part_type_direction(pt2, 50, 130, 0, 0)
part_type_gravity(pt2, 0.4, 270)
part_type_life(pt2, 10, 10)
part_type_step(pt2, -2, pts2)
part_type_death(pt2, 1, ptd2)
part_type_sprite(pts2, 1747, 1, 1, 0)
part_type_life(pts2, 10, 10)
part_type_sprite(ptd2, 1302, 1, 1, 0)
part_type_alpha3(ptd2, 1, 0.5, 0)
part_type_life(ptd2, 10, 10)
wpt0 = part_type_create()
wptd0 = part_type_create()
part_type_sprite(wpt0, 228, 1, 1, 1)
part_type_alpha3(wpt0, 1, 1, 0)
part_type_speed(wpt0, 2.5, 10, 0, 0)
part_type_direction(wpt0, 50, 130, 0, 0)
part_type_gravity(wpt0, 0.4, 270)
part_type_life(wpt0, 30, 30)
part_type_death(wpt0, 1, wptd0)
part_type_sprite(wptd0, 110, 1, 1, 0)
part_type_alpha3(wptd0, 1, 1, 0)
part_type_life(wptd0, 20, 20)
wpt1 = part_type_create()
wptd1 = part_type_create()
part_type_sprite(wpt1, 228, 1, 1, 1)
part_type_alpha3(wpt1, 1, 1, 0)
part_type_speed(wpt1, 4, 12, 0, 0)
part_type_direction(wpt1, 50, 130, 0, 0)
part_type_gravity(wpt1, 0.4, 270)
part_type_life(wpt1, 40, 40)
part_type_death(wpt1, 1, wptd1)
part_type_sprite(wptd1, 1295, 1, 1, 0)
part_type_alpha3(wptd1, 1, 1, 0)
part_type_life(wptd1, 20, 20)
psbreak = part_system_create()
part_system_depth(psbreak, ((-y) - 64))
ptbreak = part_type_create()
part_type_sprite(ptbreak, 2583, 0, 0, 1)
part_type_alpha3(ptbreak, 1, 1, 0)
part_type_speed(ptbreak, 4, 12, 0, 0)
part_type_direction(ptbreak, 50, 130, 0, 0)
part_type_gravity(ptbreak, 0.4, 270)
part_type_life(ptbreak, 40, 40)
part_type_death(ptbreak, 1, wptd0)
