if (parttimer < 5)
    parttimer += 1
else if (scrbfmap(room) != 1)
{
    parttimer = 0
    repeat (1)
    {
        var r = choose("o", "y", "r")
        if (r == "o")
            part_type_color1(pt, make_color_rgb(218, 111, 74))
        if (r == "y")
            part_type_color1(pt, make_color_rgb(227, 157, 63))
        if (r == "r")
            part_type_color1(pt, make_color_rgb(196, 66, 75))
        part_particles_create(part_system, irandom(room_width), irandom(room_height), pt, 1)
    }
}
if surface_exists(autumnleaves)
{
    if (draw == false)
    {
        surface_set_target(autumnleaves)
        with (objtree)
        {
            for (var i = 0; i < 2000; i += 1)
            {
                var rdist = exp(random(6.4)) + irandom(192) + irandom(192)
                var rdir = random(360)
                draw_sprite(sleaf, irandom(7), ((x + (lengthdir_x(rdist, rdir))) / 4), ((y + (lengthdir_y((rdist * 2 / 3), rdir))) / 4))
            }
        }
        with (objtree0)
        {
            for (i = 0; i < 2000; i += 1)
            {
                rdist = exp(random(6.4)) + irandom(192) + irandom(192)
                rdir = random(360)
                draw_sprite(sleaf, irandom(7), ((x + (lengthdir_x(rdist, rdir))) / 4), ((y + (lengthdir_y((rdist * 2 / 3), rdir))) / 4))
            }
        }
        with (objautree1)
        {
            for (i = 0; i < 500; i += 1)
            {
                rdist = exp(random(6)) + irandom(192) + irandom(192)
                rdir = random(360)
                draw_sprite(sleaf, irandom(7), ((x + (lengthdir_x(rdist, rdir))) / 4), ((y + (lengthdir_y((rdist * 2 / 3), rdir))) / 4))
            }
        }
        with (objautree2)
        {
            for (i = 0; i < 500; i += 1)
            {
                rdist = exp(random(6)) + irandom(192) + irandom(192)
                rdir = random(360)
                draw_sprite(sleaf, irandom(7), ((x + (lengthdir_x(rdist, rdir))) / 4), ((y + (lengthdir_y((rdist * 2 / 3), rdir))) / 4))
            }
        }
        if (scrbfmap(room) == 0)
        {
            for (i = 0; i < 2000; i += 1)
                draw_sprite(sleaf, irandom(11), (irandom(room_width) / 4), (irandom(room_height) / 4))
        }
        sautumnleaves = sprite_create_from_surface(autumnleaves, 0, 0, (room_width / 4), (room_height / 4), 0, 0, 0, 0)
        surface_reset_target()
        surface_free(autumnleaves)
        draw = true
    }
}
