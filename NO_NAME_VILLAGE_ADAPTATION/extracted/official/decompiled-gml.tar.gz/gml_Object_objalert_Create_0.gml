image_index = 0
image_speed = 0.2
creator = -4
xoffset = 0
yoffset = 0
time = 0.1
