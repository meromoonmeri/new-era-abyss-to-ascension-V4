timer = 0
dir = 90
if (x <= 128)
{
    x = -128
    dir = 0
}
else if (x >= (room_width - 128))
{
    x = room_width + 128
    dir = 180
}
else if (y <= 128)
{
    y = -128
    dir = 270
}
else if (y >= (room_height - 128))
{
    y = room_height + 128
    dir = 90
}
bfx = x
bfy = y
bfmapx = 0
bfmapy = 0
if (room == rm62)
{
    bfx = 3392
    bfy = 4704
}
else if (room == rm72)
{
    bfx = 1896
    bfy = 4764
}
else if (room == rm93)
{
    bfx = 448
    bfy = 4064
}
else if (room == rm94)
{
    bfx = 832
    bfy = 2240
}
else if (room == rm95)
{
    bfx = 384
    bfy = 192
}
else if (room == rm86)
{
    bfx = 3840
    bfy = 928
}
else if (room == rm76)
{
    bfx = 4160
    bfy = 352
}
else if (room == rm04)
{
    bfx = 4032
    bfy = 1184
}
else if (room == rm13)
{
    bfx = 1184
    bfy = 4352
}
else if (room == rm15)
{
    bfx = 4064
    bfy = 3008
}
else if (room == rm22)
{
    bfx = 4064
    bfy = 3936
}
else if (room == rm26)
{
    if (dir == 270)
    {
        bfx = 800
        bfy = 960
    }
    else
    {
        bfx = 4032
        bfy = 2560
    }
}
else if (room == rm42)
{
    bfx = 1568
    bfy = 4032
}
else if (room == rm52)
{
    bfx = 1312
    bfy = 3840
}
else if (room == rm27)
{
    bfx = 4640
    bfy = 1248
}
else if (room == rm410)
{
    bfx = 3904
    bfy = 576
}
else if (room == rm510)
{
    bfx = 1888
    bfy = 1184
}
else if (room == rm78)
{
    bfx = 1024
    bfy = 3520
}
else if (room == rm79)
{
    bfx = 2080
    bfy = 2848
}
