function scrmobhurt(argument0, argument1, argument2) //gml_Script_scrmobhurt
{
    var lvldiff = objplayer.weaponlvl - level
    var stagger = 0
    repeat hit
    {
        hitnumber += 1
        armrbrk = hitnumber / (clamp((1 - lvldiff), 1, 10))
        if ((hitnumber % (clamp((1 - lvldiff), 1, 10))) == 0)
            stagger = 1
        if (stagger == 1)
        {
            hitnumber = 0
            armrbrkt = 1
        }
    }
    with (objphflash)
        sprite_index = spawhit
    if (stagger == 1)
    {
        if (hit == 1)
        {
            with (objphflash)
                sprite_index = spanhit
            scrsound(snpattack1, 50, 0.8, (1 + (random_range(-0.2, 0.2))))
            scrsound(snpattack1s, 50, 1, 1)
        }
        else
        {
            with (objphflash)
                sprite_index = spanhhit
            scrsound(snpattack1w, 50, 1, (1 + (random_range(-0.2, 0.2))))
        }
    }
    var hit_coefficient = hit / (clamp((1 - lvldiff), 1, 10))
    if (lvldiff > 0 || stagger == 1)
        hit_coefficient = hit * (clamp((1 + lvldiff), 1, 10))
    hp -= hit_coefficient
    flash = 0.5
    objplayerview.shaket = 4
    if (hit_coefficient >= 1)
        objplayerview.shaket = 8
    if (hp <= 0)
        objplayerview.shaket = 12
    if (argument2 <= 0 && hit_coefficient >= 1)
        dir = player.dir - 180 + (abs(angle_difference((player.dir - 180), scrdir(self, player)))) / 2
    hit = 0
    if (hp > 0)
    {
        if (argument0 >= 0 && argument1 >= 0 && argument2 <= 0 && stagger == 1)
        {
            image_index = 0
            state = argument0
            flash = 1
            return 1;
        }
    }
    else if (argument1 >= 0)
    {
        objplayerview.shaket = 12
        image_index = 0
        state = argument1
        hit = -2
        return 2;
    }
}

