part_particles_clear(ps)
part_system_destroy(ps)
part_type_destroy(pt)
