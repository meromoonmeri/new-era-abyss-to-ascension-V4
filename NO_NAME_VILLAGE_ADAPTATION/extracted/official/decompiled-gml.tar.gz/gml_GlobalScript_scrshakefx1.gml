function scrshakefx1(argument0, argument1, argument2, argument3, argument4) //gml_Script_scrshakefx1
{
    var destroy = argument0
    var shake = argument1
    var leaf = argument2
    var vx = argument3
    var vy = argument4
    if (!instance_exists(objeffect))
        instance_create_layer(0, 0, "instances", objeffect)
    if (!variable_global_exists("plantmap"))
        global.plantmap = ds_map_create()
    var hitlist = ds_list_create()
    var hitnumber = instance_place_list(vx, vy, 120, hitlist, false)
    if (hitnumber > 0)
    {
        if (!instance_exists(objeffect))
            instance_create_layer(0, 0, "instances", objeffect)
        var snhit = 0
        for (var i = 0; i < hitnumber; i++)
        {
            var hitid = ds_list_find_value(hitlist, i)
            var idx = hitid.x
            var idy = hitid.y
            var ids = hitid.sprite_index
            if ds_map_exists(global.plantmap, hitid)
            {
                if ((global.time - (array_get(ds_map_find_value(global.plantmap, hitid), 0))) > 30)
                    ds_map_replace(global.plantmap, hitid, [global.time, shake])
            }
            else
            {
                ds_map_add(global.plantmap, hitid, [global.time, shake])
                if (sprite_get_height(ids) > 64)
                {
                    if (destroy > 0)
                    {
                        if (snhit < 2)
                        {
                            snhit += 1
                            scrsound(snplantshake, 10, 1, 1)
                        }
                    }
                    else
                        scrsound(snplantshake, 10, shake, 1)
                }
            }
            var col = make_color_rgb(35, 133, 60)
            if (global.season == 2)
                make_color_rgb(49, 115, 55)
            if (global.season >= 3)
                make_color_rgb(22, 78, 91)
            var p = hitid.sprite_index
            var nsprite = hitid.sprite_index
            nsprite = sempty
            if (destroy > 0)
            {
                if (!instance_exists(p))
                    leaf = leaf * 1.25
            }
            var lbx = idx
            var lby = idy - sprite_get_yoffset(ids) + sprite_get_height(ids) / 2
            if (leaf < 1)
                leaf = 1
            if (sprite_get_height(ids) > 64)
            {
                if (destroy > 0 && nsprite != hitid.sprite_index && random(1) < (1/30))
                    instance_create_layer(hitid.x, hitid.y, "instances", objfruit)
                with (objeffect)
                {
                    part_type_color1(ptleaf0, col)
                    part_type_speed(ptleaf0, 3, 15, -0.1, 0)
                    part_particles_create(psleaf, lbx, lby, ptleaf0, leaf)
                }
            }
            if (destroy > 0)
            {
                if instance_exists(hitid)
                    hitid.sprite_index = nsprite
            }
        }
    }
    ds_list_destroy(hitlist)
}

