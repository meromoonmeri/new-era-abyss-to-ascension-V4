function scrremap() //gml_Script_scrremap
{
    var order = [65, 66, 67, 68, 69, 70, 71, 72, 72, 74, 75, 76, 76, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 37, 38, 40, 39, 9, 9, 16, 17, 18, 32]
    for (var i = 0; i < array_length(order); i++)
    {
        if keyboard_check_pressed(order[i])
        {
            if (i == 40)
                i = 41
            return i;
        }
    }
    return -1;
}

