instance_destroy()
