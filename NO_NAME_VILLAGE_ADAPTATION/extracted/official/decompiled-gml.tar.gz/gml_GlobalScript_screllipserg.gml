function screllipserg(argument0, argument1, argument2, argument3, argument4, argument5, argument6, argument7, argument8, argument9) //gml_Script_screllipserg
{
    var _x = argument[0]
    var _y = argument[1]
    var _rx = argument[2]
    var _ry = argument[3]
    var _dx = argument[4]
    var _dy = argument[5]
    var _c1 = argument[6]
    var _c2 = argument[7]
    var _a1 = argument[8]
    var _a2 = argument[9]
    var _q = 32
    var _dir = 0
    draw_primitive_begin(6)
    draw_vertex_color(_x, _y, _c1, _a1)
    repeat (_q + 1)
    {
        draw_vertex_color((_x + (lengthdir_x(_rx, _dir))), (_y + (lengthdir_y(_ry, _dir))), _c1, _a1)
        _dir += (360 / _q)
    }
    draw_primitive_end()
    draw_primitive_begin(5)
    repeat (_q + 1)
    {
        draw_vertex_color((_x + (lengthdir_x(_rx, _dir))), (_y + (lengthdir_y(_ry, _dir))), _c1, _a1)
        draw_vertex_color((_x + (lengthdir_x((_rx + _dx), _dir))), (_y + (lengthdir_y((_ry + _dy), _dir))), _c2, _a2)
        _dir += (360 / _q)
    }
    draw_primitive_end()
}

