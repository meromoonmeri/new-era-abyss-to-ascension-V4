event_inherited()
if (state == 3)
{
    var c = 1 + (clamp((spd / dshspd), 0, 1))
    with (objplayerview)
        bcp += ((c - bcp) / 12)
}
else
{
    with (objplayerview)
        bcp += ((1 - bcp) / 12)
}
if (state == 4)
{
    var diff = abs(y - (objplayer.y + 128))
    var diff0 = diff / 64
    var diff1 = (diff0 - 2) / 4
    var diff2 = diff1 * 0.6 + 0.2
    var diff3 = clamp(diff2, 0.1, 0.8)
    bvy += ((z * diff3 - bvy) / 4)
}
