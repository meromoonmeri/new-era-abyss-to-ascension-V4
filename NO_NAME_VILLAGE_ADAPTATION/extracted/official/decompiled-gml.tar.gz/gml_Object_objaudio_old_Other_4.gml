if (audio_sound_get_gain(snbgtree) <= 0)
    audio_stop_sound(snbgtree)
if (audio_sound_get_gain(snsummer) <= 0)
    audio_stop_sound(snsummer)
if (audio_sound_get_gain(snwinter) <= 0)
    audio_stop_sound(snwinter)
if (audio_sound_get_gain(snbgriver) <= 0)
    audio_stop_sound(snbgriver)
if (audio_sound_get_gain(snwater0) <= 0)
    audio_stop_sound(snwater0)
if (audio_sound_get_gain(snsmmusic00) <= 0 && audio_sound_get_gain(snsmmusic01) <= 0)
{
    audio_stop_sound(snsmmusic00)
    audio_stop_sound(snsmmusic01)
}
music = -1
sound = -1
