function scrinteract(argument0) //gml_Script_scrinteract
{
    if instance_exists(argument0)
    {
        if (objplayer.interactid == argument0.id)
        {
            if scrinput("actionp")
                timer += 1
        }
    }
}

