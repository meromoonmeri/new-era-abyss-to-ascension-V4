event_inherited()
mob = -1
image_speed = 0.1
z = 64
vvel = 8
vaccl = 0.5
spd = 10
dir = 0
dmg = 0.5
fadet = 180
splash = 0
ps = part_system_create()
part_system_depth(ps, (-y))
ptssp = part_type_create()
part_type_sprite(ptssp, 1171, 1, 1, 0)
part_type_size(ptssp, 0.75, 0.75, 0, 0)
part_type_life(ptssp, 35, 35)
