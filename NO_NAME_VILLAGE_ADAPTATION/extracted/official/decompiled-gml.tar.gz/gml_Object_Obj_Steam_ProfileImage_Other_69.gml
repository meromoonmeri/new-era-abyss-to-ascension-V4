if (ds_map_find_value(async_load, "event_type") != "avatar_image_loaded")
    return;
var success = ds_map_find_value(async_load, "success")
if (success == 1)
    avatar_sprite = self.steam_image_create_sprite(ds_map_find_value(async_load, "image"))
else
    show_debug_message("Failed to get user avatar")
