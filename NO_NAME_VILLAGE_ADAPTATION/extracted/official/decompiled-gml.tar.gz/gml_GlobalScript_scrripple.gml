function scrripple(argument0, argument1, argument2, argument3, argument4) //gml_Script_scrripple
{
    if (!layer_exists("watershadows"))
        layer_create((layer_get_depth("shadows") - 4), "watershadows")
    if (depth > layer_get_depth("watershadows"))
        var ripple = instance_create_depth(x, y, (depth + 4), objripples)
    else
        ripple = instance_create_layer(x, y, "watershadows", objripples)
    ripple.x = argument0
    ripple.y = argument1
    ripple.sprite_index = argument2
    ripple.maxsize = argument3 * argument4
    ripple.scale = argument4
    ripple.scale = argument4
}

