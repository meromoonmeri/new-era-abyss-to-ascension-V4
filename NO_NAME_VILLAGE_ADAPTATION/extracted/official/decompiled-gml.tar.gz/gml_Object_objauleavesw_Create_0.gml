if layer_exists("watershadows")
    depth = layer_get_depth("watershadows")
else
    depth = layer_get_depth("shadows") + 6
autumnleaves = surface_create((room_width / 4), (room_height / 4))
sautumnleaves = 667
draw = false
