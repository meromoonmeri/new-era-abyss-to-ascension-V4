if (!instance_exists(objbmobsm))
    instance_destroy()
else
{
    x = objbmobsm.x
    y = objbmobsm.y
    if ((objbmobsm.state == 2 && objbmobsm.image_index > 4) || objbmobsm.state == 3)
    {
        sprite_index = sbmobsm1dshad
        image_xscale = 4
        image_yscale = 4
        alpha = 0.6
    }
    else if (objbmobsm.sprite_index == sbmobsm1r)
    {
        sprite_index = sbmobsm1rshad
        image_xscale = 4
        image_yscale = 4
        image_index = objbmobsm.image_index
        alpha = 1
    }
    else
    {
        sprite_index = sbmobsm1shad
        image_xscale = 1
        image_yscale = 1
        alpha = 0.6
    }
}
