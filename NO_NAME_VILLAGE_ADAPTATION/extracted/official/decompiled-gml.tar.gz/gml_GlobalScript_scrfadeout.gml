function scrfadeout(argument0) //gml_Script_scrfadeout
{
    objplayer.caninput = false
    if (objplayerview.lat > 0)
    {
        objplayerview.la = 0
        objplayerview.latt = argument0
    }
    else
    {
        objplayerview.latt = 0.025
        return 1;
    }
}

