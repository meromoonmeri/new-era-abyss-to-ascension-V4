function scrtimetotalk1(argument0, argument1, argument2, argument3) //gml_Script_scrtimetotalk1
{
    if (timertt < argument0)
    {
        with (objplayer)
        {
            caninput = false
            if (state != -1 && kdpause != 1)
                state = 0
        }
        if instance_exists(objfollower)
            objfollower.caninput = false
        timertt += 1
    }
    else if (timertt == argument0)
    {
        if instance_exists(objplayer)
            objplayer.caninput = false
        if instance_exists(objfollower)
            objfollower.caninput = false
        if (!instance_exists(objtextbox))
        {
            var textboxcreate = instance_create_depth(objplayerview.x, objplayerview.y, 0, objtextbox)
            with (objplayer)
                dodget = 0
            with (objfollower)
                dodget = 0
            if (argument2 == 0)
                textboxcreate.afterinput = false
            with (textboxcreate)
            {
                if (argument1 == -1)
                    tbox = 1847
                else if (argument1 == 0)
                    tbox = 1206
                else if (argument1 == 1)
                    tbox = 342
                else
                    tbox = 1206
                text = argument3
            }
        }
        else
            timertt += 1
    }
    else if (!instance_exists(objtextbox))
    {
        if instance_exists(objplayer)
            objplayer.stage += 0.01
        else
            timer += 1
        timertt = 0
    }
}

