if (start >= 3)
    draw_sprite_ext(sbmobauspshad, 0, x, y, shadsize, shadsize, 0, -1, shadsize)
draw_sprite_ext(sprite_index, image_index, x, (y - z), 1, 1, 0, -1, alpha)
