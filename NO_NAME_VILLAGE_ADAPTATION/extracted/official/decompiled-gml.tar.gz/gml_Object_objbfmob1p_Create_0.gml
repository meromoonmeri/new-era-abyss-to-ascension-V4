state = 0
spd = 0
dir = 0
z = 0
zvel = 1
