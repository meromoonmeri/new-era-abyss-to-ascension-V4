if (timer < 120)
    timer += 1
else if (alpha > 0)
    alpha -= 0.05
else
    instance_destroy()
