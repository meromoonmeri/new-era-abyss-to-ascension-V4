if (!variable_global_exists("srev"))
    global.srev = -1
else if (global.srev == -1)
{
    var sw = surface_get_width(application_surface)
    var sh = surface_get_height(application_surface)
    global.srev = sprite_create_from_surface(application_surface, 0, 0, sw, sh, 0, 1, 0, 0)
}
else if (revframe > 0)
{
    var vx = camera_get_view_x(view_camera[0])
    var vy = camera_get_view_y(view_camera[0])
    var scale = 1.34
    shader_set(shrewind)
    var rr = 1 - (revframe + timer * 10) / rev
    var d = 3.8
    var c = 2.8
    var b = 0.4
    var a = -0.2
    if (rr < (-a))
        var ww = d * (tan(c * (power((rr + a), 2)))) - b
    else
        ww = d * (tan(c / 3 * (power((rr + a), 2)))) - b
    var time = shader_get_uniform(shrewind, "iTime")
    shader_set_uniform_f(time, ww)
    draw_sprite_ext(global.srev, revframe, vx, vy, scale, scale, 0, -1, 1)
    shader_reset()
}
