if (state == 7)
{
    draw_sprite_ext(sbdsave01, 0, 0, b71y, 4, 4, 0, -1, 1)
    draw_sprite_ext(sbdsave02, 0, 0, b72y, 4, 4, 0, -1, 1)
    draw_sprite_ext(sbdsave03, 0, 0, b73y, 4, 4, 0, -1, 1)
    draw_sprite_ext(sbdsave04, 0, 0, b74y, 4, 4, 0, -1, 1)
    for (var i = 0; i <= 3; i += 1)
    {
        ini_open("NoNameVillage.ini")
        var sstage = ini_read_real(("save" + string(i)), "stage", -1)
        if (sstage < 2)
            var season = 0
        else if (sstage < 3)
            season = 1
        else if (sstage < 4)
            season = 2
        else if (sstage < 8)
            season = 3
        else
            season = 4
        if (i == 0 || i == 2)
            var flip = 1
        else
            flip = -1
        if (sstage >= 0)
        {
            if (i == 0)
                draw_sprite_ext(sbdsave20, season, (display_get_gui_width() / 2), (180 * i + b71y), (flip * 4), 4, 0, -1, 1)
            else if (i == 1)
                draw_sprite_ext(sbdsave20, season, (display_get_gui_width() / 2), (180 * i + b72y), (flip * 4), 4, 0, -1, 1)
            else if (i == 2)
                draw_sprite_ext(sbdsave20, season, (display_get_gui_width() / 2), (180 * i + b73y), (flip * 4), 4, 0, -1, 1)
            else
                draw_sprite_ext(sbdsave20, season, (display_get_gui_width() / 2), (180 * i + b74y), (flip * 4), 4, 0, -1, 1)
        }
        ini_close()
    }
    if (row7 == 0 || row7 == 2)
        var sflip = 1
    else
        sflip = -1
    if (row7 == 0)
        draw_sprite_ext(sbdsave10, 0, (display_get_gui_width() / 2), (row7 * 180 + b71y), (sflip * 4), 4, 0, -1, 1)
    else if (row7 == 1)
        draw_sprite_ext(sbdsave10, 0, (display_get_gui_width() / 2), (row7 * 180 + b72y), (sflip * 4), 4, 0, -1, 1)
    else if (row7 == 2)
        draw_sprite_ext(sbdsave10, 0, (display_get_gui_width() / 2), (row7 * 180 + b73y), (sflip * 4), 4, 0, -1, 1)
    else
        draw_sprite_ext(sbdsave10, 0, (display_get_gui_width() / 2), (row7 * 180 + b74y), (sflip * 4), 4, 0, -1, 1)
    for (var j = 0; j <= 3; j += 1)
    {
        ini_open("NoNameVillage.ini")
        var sav = "save" + string(j)
        if ini_key_exists(sav, "stage")
        {
            if (j == 0)
                var ymove = b71y
            else if (j == 1)
                ymove = b72y
            else if (j == 2)
                ymove = b73y
            else
                ymove = b74y
            draw_set_halign(fa_left)
            draw_set_font(fnt0)
            draw_set_color(c_black)
            var hours = string(ini_read_real(sav, "hours", 0))
            if (ini_read_real(sav, "minutes", 0) < 10)
                var minutes = "0" + (string(ini_read_real(sav, "minutes", 0)))
            else
                minutes = string(ini_read_real(sav, "minutes", 0))
            if (ini_read_real(sav, "seconds", 0) < 10)
                var seconds = "0" + (string(round(ini_read_real(sav, "seconds", 0))))
            else
                seconds = string(round(ini_read_real(sav, "seconds", 0)))
            draw_text(640, (228 + 180 * j + ymove), (hours + ":" + minutes + ":" + seconds))
            draw_text(636, (232 + 180 * j + ymove), (hours + ":" + minutes + ":" + seconds))
            draw_text(640, (236 + 180 * j + ymove), (hours + ":" + minutes + ":" + seconds))
            draw_text(644, (232 + 180 * j + ymove), (hours + ":" + minutes + ":" + seconds))
            draw_set_color(c_white)
            draw_text(640, (232 + 180 * j + ymove), (hours + ":" + minutes + ":" + seconds))
            for (var shp = 0; shp < (3 + (ini_read_real(sav, "clotheslvl", 0))); shp++)
                draw_sprite_ext(sbdsave30, 0, (640 + 36 * shp), (292 + 180 * j + ymove), 4, 4, 0, -1, 1)
            for (var sdmg = 0; sdmg < ini_read_real(sav, "weaponlvl", 0); sdmg++)
                draw_sprite_ext(sbdsave30, 1, (864 + 36 * sdmg), (232 + 180 * j + ymove), 4, 4, 0, -1, 1)
            for (var shl = 0; shl < ini_read_real(sav, "heallvl", 0); shl++)
                draw_sprite_ext(sbdsave30, 2, (864 + 36 * shl), (292 + 180 * j + ymove), 4, 4, 0, -1, 1)
        }
        ini_close()
    }
    if (select7 >= 0)
    {
        draw_sprite_ext(sbedmenu1, 0, 0, 0, 4, 4, 0, -1, 1)
        draw_sprite_ext(sbedmenu11, confirm7, 624, 488, 4, 4, 0, -1, 1)
    }
}
