depth = (-y)
var player = objplayerview.player
var timedelay = global.time
var zaccl = 0.6
if (z > 0)
{
    vel -= zaccl
    z += vel
    if ((timedelay % 2) == 0)
    {
        if (random(1) < 0.5)
            part_particles_create(global.ptwater0, x, (y - z), pt0, 1)
        if (random(1) < 0.5)
            part_particles_create(global.ptwater1, x, (y - z), pt1, 1)
        if (random(1) < 0.5)
            part_particles_create(global.ptwater0, x, (y - z), pt2, 1)
    }
    x += lengthdir_x(spd, dir)
    y += lengthdir_y(spd, dir)
    if (place_meeting(x, y, player) && player.iframe <= 0 && z < 120)
        z = 0
}
else
{
    mask_index = smobsm2splash
    scrsplash(x, y, smobsm2splash, 0)
    var pcol = instance_place(x, y, player)
    if (pcol != noone && pcol.iframe <= 0 && noncol == false)
    {
        if (player != 374)
            objplayer.hp -= 1
        else
            objft0.hp -= 1
        pcol.iframe = 1
        pcol.state = 6
        pcol.dir = scrdir(pcol, self)
        pcol.caninput = false
        pcol.image_index = 0
        objplayerview.shaket = 16
    }
    instance_destroy()
}
var grad = 1 - z / 150
shalpha = clamp(grad, 0.1, 1)
size = clamp((1.5 + grad / 2), 1.5, 2)
