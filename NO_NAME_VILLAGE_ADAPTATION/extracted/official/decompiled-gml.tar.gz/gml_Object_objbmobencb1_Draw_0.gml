if (type == "cby")
{
    if (state == 0)
    {
        var vshadtime = (floor((clamp(timer, 0, 1)) * 10)) / 10
        var shadheight = clamp((1 - (abs(z - 20)) / 330), 0, 1)
        draw_sprite_ext(sbmobenptshad, 0, x, y, (vshadtime * shadheight), (vshadtime * shadheight), 0, -1, 1)
    }
}
if (type == "delay")
{
    if (state == 2)
    {
        var tct = (floor(ct * 6)) / 6
        draw_sprite_ext(sbmobenptshad, 0, x, y, tct, tct, 0, -1, 1)
    }
}
if (type == "attach")
{
    var rot = dir + 180
    if (rot >= 360)
        rot -= 360
    rot = rot - 90
    for (var a = 0; a <= floor(ct * 5); a += 1)
    {
        if (a == 0)
            draw_sprite_ext(sbmobenpt, 0, x, (y - z), 1, 1, rot, -1, 1)
        if (a == 1)
            draw_sprite_ext(sbmobenpt, 0, x, (y - z), 1.2, 1.2, (rot - 60), -1, 1)
        if (a == 2)
            draw_sprite_ext(sbmobenpt, 0, x, (y - z), 1.4, 1.4, (rot + 50), -1, 1)
        if (a == 3)
            draw_sprite_ext(sbmobenpt, 0, x, (y - z), 1.6, 1.6, (rot - 30), -1, 1)
        if (a == 4)
            draw_sprite_ext(sbmobenpt, 0, x, (y - z), 1.8, 1.8, (rot + 20), -1, 1)
    }
}
if (type == "jump")
{
    if (state == 0)
    {
        if (ct >= 60)
            ct = 0
        for (a = 0; a <= floor(ct * 15); a += 1)
        {
            var rn = floor((pi * (power(10, a))) % 10)
            var cdir = 360 * (rn / 10)
            rot = cdir - 90
            var scale = 1 + a / 15 / 1.5 + ct / 2
            draw_sprite_ext(sbmobenpt, 0, (x + (lengthdir_x(a, cdir))), (y - z + (lengthdir_y(a, cdir))), scale, scale, rot, -1, 1)
        }
    }
}
if (type == "throw")
{
    var s = 0
    a = 1
    if (state == 0)
        s = clamp(((1 - (z / 64 - 0.5) / 5.5) * 1 + 0), 0, 1)
    else if (state == 1)
    {
        s = 4 * (1 - timer)
        a = 0.2 + (1 - timer)
    }
    draw_sprite_ext(sbmobenptshad, 0, x, y, s, s, 0, -1, a)
    if (state == 0)
    {
        if (ct >= 60)
            ct = 0
        a = 6
        while ((a - 6) <= floor(ct * 50))
        {
            rn = floor((pi * (power(100, a))) % 100)
            cdir = 360 * (rn / 100)
            rot = cdir - 90
            scale = 1 + a / 50 * 0.25 + ct * 0.5
            draw_sprite_ext(sbmobenpt, 0, (x + (lengthdir_x((a / 2), cdir))), (y - z + (lengthdir_y((a / 2), cdir))), scale, scale, (rot + ct * 20), -1, 1)
            a += 1
        }
    }
}
if (type == "final")
{
    if (state == 0)
    {
        tct = (floor(ct * 6)) / 6
        draw_sprite_ext(sbmobenptshad, 0, x, y, tct, tct, 0, -1, 1)
    }
}
if (type == "combine")
{
    if (state == 0 || state == 1)
    {
        if (ct >= 60)
            ct = 0
        for (a = 0; a <= floor(ct * 30); a += 1)
        {
            rn = floor((pi * (power(10, a))) % 10)
            cdir = 360 * (rn / 10)
            rot = cdir - 90
            scale = 1 + a / 30 / 1.5 + ct / 2
            draw_sprite_ext(sbmobenpt, 0, (x + (lengthdir_x(a, cdir))), (y - z + (lengthdir_y(a, cdir))), scale, scale, rot, -1, 1)
        }
    }
}
