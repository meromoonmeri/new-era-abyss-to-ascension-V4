draw_sprite_ext(sautumnleaves, 0, 0, 0, 4, 4, 0, -1, 1)
