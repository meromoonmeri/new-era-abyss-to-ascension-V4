depth = (-y)
z = 640
zvel = 30
image_alpha = 0
