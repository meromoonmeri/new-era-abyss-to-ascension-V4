-- Candidat PMU→PMDO; routes prouvées uniquement.
require 'origin.common'
local M={}
function M.Init(map)
end
function M.Enter(map) end
function M.Exit(map) end
function M.Update(map) end
function M.Warp_4_5_to_s1545_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1545', 'PMU_Entry_10_3')
end
function M.Warp_4_17_to_s1184_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1184', 'PMU_Entry_29_8')
end
function M.Warp_4_33_to_s1262_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1262', 'PMU_Entry_29_3')
end
function M.Warp_4_45_to_s801_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s801', 'PMU_Entry_12_42')
end
function M.Warp_14_5_to_s919_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s919', 'PMU_Entry_23_43')
end
function M.Warp_14_45_to_s1260_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1260', 'PMU_Entry_41_16')
end
function M.Warp_25_5_to_s1285_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1285', 'PMU_Entry_25_26')
end
function M.Warp_25_28_to_s1432_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1432', 'PMU_Entry_24_3')
end
function M.Warp_25_45_to_s1226_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1226', 'PMU_Entry_17_17')
end
function M.Warp_36_5_to_s947_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s947', 'PMU_Entry_43_27')
end
function M.Warp_36_45_to_s1216_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1216', 'PMU_Entry_21_37')
end
function M.Warp_46_5_to_s947_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s947', 'PMU_Entry_15_9')
end
function M.Warp_46_17_to_s1016_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1016', 'PMU_Entry_11_13')
end
function M.Warp_46_33_to_s1222_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1222', 'PMU_Entry_17_12')
end
function M.Warp_46_45_to_s1018_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1018', 'PMU_Entry_24_7')
end
function M.GameSave(map) end
function M.GameLoad(map) end
return M
