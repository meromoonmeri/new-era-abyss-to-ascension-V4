-- Candidat PMU→PMDO; routes prouvées uniquement.
require 'origin.common'
local M={}
function M.Init(map)
end
function M.Enter(map) end
function M.Exit(map) end
function M.Update(map) end
function M.Cardinal_up_to_s444_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s444', 'PMU_Entry_0_0')
end
function M.Cardinal_left_to_s880_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s880', 'PMU_Entry_0_0')
end
function M.GameSave(map) end
function M.GameLoad(map) end
return M
