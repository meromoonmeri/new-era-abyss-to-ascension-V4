-- Candidat PMU→PMDO; routes prouvées uniquement.
require 'origin.common'
local M={}
function M.Init(map)
end
function M.Enter(map) end
function M.Exit(map) end
function M.Update(map) end
function M.Warp_15_26_to_s321_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s321', 'PMU_Entry_9_11')
end
function M.Warp_19_35_to_s56_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s56', 'PMU_Entry_9_9')
end
function M.Warp_25_14_to_s1334_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1334', 'PMU_Entry_9_29')
end
function M.Warp_31_36_to_s319_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s319', 'PMU_Entry_9_11')
end
function M.Warp_35_31_to_s1333_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1333', 'PMU_Entry_9_11')
end
function M.Warp_37_7_to_s278_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s278', 'PMU_Entry_10_13')
end
function M.Cardinal_up_to_s1642_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1642', 'PMU_Entry_0_0')
end
function M.Cardinal_down_to_s921_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s921', 'PMU_Entry_0_0')
end
function M.Cardinal_left_to_s1391_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1391', 'PMU_Entry_0_0')
end
function M.Cardinal_right_to_s1640_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1640', 'PMU_Entry_0_0')
end
function M.GameSave(map) end
function M.GameLoad(map) end
return M
