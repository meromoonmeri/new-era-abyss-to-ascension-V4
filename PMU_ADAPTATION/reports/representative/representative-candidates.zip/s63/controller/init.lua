-- Candidat PMU→PMDO; routes prouvées uniquement.
require 'origin.common'
local M={}
function M.Init(map)
end
function M.Enter(map) end
function M.Exit(map) end
function M.Update(map) end
function M.Warp_8_5_to_s175_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s175', 'PMU_Entry_9_11')
end
function M.Warp_16_2_to_s1730_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1730', 'PMU_Entry_9_14')
end
function M.Warp_17_2_to_s1730_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1730', 'PMU_Entry_9_14')
end
function M.Cardinal_down_to_s61_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s61', 'PMU_Entry_0_0')
end
function M.GameSave(map) end
function M.GameLoad(map) end
return M
