-- Candidat PMU→PMDO; routes prouvées uniquement.
require 'origin.common'
local M={}
function M.Init(map)
end
function M.Enter(map) end
function M.Exit(map) end
function M.Update(map) end
function M.Warp_2_11_to_s121_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s121', 'PMU_Entry_9_7')
end
function M.Warp_2_12_to_s121_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s121', 'PMU_Entry_9_7')
end
function M.Warp_2_23_to_s126_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s126', 'PMU_Entry_9_7')
end
function M.Warp_2_24_to_s126_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s126', 'PMU_Entry_9_7')
end
function M.Warp_3_17_to_s125_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s125', 'PMU_Entry_9_7')
end
function M.Warp_3_18_to_s125_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s125', 'PMU_Entry_9_7')
end
function M.Warp_9_3_to_s120_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s120', 'PMU_Entry_9_7')
end
function M.Warp_10_3_to_s120_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s120', 'PMU_Entry_9_7')
end
function M.Warp_16_17_to_s124_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s124', 'PMU_Entry_9_7')
end
function M.Warp_16_18_to_s124_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s124', 'PMU_Entry_9_7')
end
function M.Warp_17_11_to_s122_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s122', 'PMU_Entry_9_7')
end
function M.Warp_17_12_to_s122_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s122', 'PMU_Entry_9_7')
end
function M.Warp_17_23_to_s123_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s123', 'PMU_Entry_9_7')
end
function M.Warp_17_24_to_s123_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s123', 'PMU_Entry_9_7')
end
function M.GameSave(map) end
function M.GameLoad(map) end
return M
