-- Candidat PMU→PMDO; routes prouvées uniquement.
require 'origin.common'
local M={}
function M.Init(map)
end
function M.Enter(map) end
function M.Exit(map) end
function M.Update(map) end
function M.Warp_6_2_to_s128_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s128', 'PMU_Entry_5_5')
end
function M.Cardinal_up_to_s6_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s6', 'PMU_Entry_0_0')
end
function M.Cardinal_down_to_s36_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s36', 'PMU_Entry_0_0')
end
function M.Cardinal_left_to_s1_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1', 'PMU_Entry_0_0')
end
function M.Cardinal_right_to_s11_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s11', 'PMU_Entry_0_0')
end
function M.GameSave(map) end
function M.GameLoad(map) end
return M
