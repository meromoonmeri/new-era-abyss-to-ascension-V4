-- Candidat PMU→PMDO; routes prouvées uniquement.
require 'origin.common'
local M={}
function M.Init(map)
  -- Conditional_MobileBlock_18_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_18_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_18_31: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_18_32: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_19_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_19_24: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_19_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_19_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_19_31: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_19_32: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_19_33: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_19_34: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_20_22: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_20_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_20_24: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_20_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_20_31: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_20_33: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_20_34: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_20_35: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_21_22: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_21_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_21_24: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_21_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_21_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_21_31: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_21_32: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_21_33: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_21_35: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_21: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_22: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_31: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_32: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_33: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_34: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_35: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_22_36: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_21: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_22: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_24: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_32: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_33: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_34: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_35: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_23_36: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_21: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_22: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_24: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_32: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_33: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_34: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_35: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_27_36: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_21: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_22: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_31: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_33: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_34: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_35: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_28_36: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_29_22: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_29_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_29_24: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_29_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_29_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_29_32: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_29_35: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_30_22: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_30_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_30_24: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_30_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_30_31: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_30_33: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_30_34: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_30_35: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_31_23: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_31_24: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_31_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_31_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_31_31: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_31_32: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_31_33: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_31_34: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_32_25: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_32_26: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_32_31: PMU MobileBlock payload 2/0/0; adapter requis
  -- Conditional_MobileBlock_32_32: PMU MobileBlock payload 2/0/0; adapter requis
end
function M.Enter(map) end
function M.Exit(map) end
function M.Update(map) end
function M.Warp_2_9_to_s1777_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1777', 'PMU_Entry_16_21')
end
function M.Warp_3_32_to_s1244_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1244', 'PMU_Entry_10_12')
end
function M.Warp_6_17_to_s793_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s793', 'PMU_Entry_9_3')
end
function M.Warp_7_6_to_s50_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s50', 'PMU_Entry_9_13')
end
function M.Warp_7_17_to_s793_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s793', 'PMU_Entry_9_3')
end
function M.Warp_15_8_to_s1146_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1146', 'PMU_Entry_10_11')
end
function M.Warp_20_6_to_s1144_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1144', 'PMU_Entry_9_11')
end
function M.Warp_32_6_to_s1143_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1143', 'PMU_Entry_10_11')
end
function M.Warp_37_8_to_s1145_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1145', 'PMU_Entry_10_11')
end
function M.Warp_42_21_to_s1142_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1142', 'PMU_Entry_10_11')
end
function M.Warp_43_16_to_s1000_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1000', 'PMU_Entry_10_13')
end
function M.Warp_45_36_to_s412_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s412', 'PMU_Entry_10_13')
end
function M.Cardinal_up_to_s799_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s799', 'PMU_Entry_0_0')
end
function M.Cardinal_down_to_s1015_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1015', 'PMU_Entry_0_0')
end
function M.Cardinal_left_to_s943_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s943', 'PMU_Entry_0_0')
end
function M.Cardinal_right_to_s1022_Touch(obj, activator)
  GAME:FadeOut(false, 20)
  GAME:EnterGroundMap('pmu_s1022', 'PMU_Entry_0_0')
end
function M.GameSave(map) end
function M.GameLoad(map) end
return M
